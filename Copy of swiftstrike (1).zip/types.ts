

export interface FlagDef {
  flag: string;
  label: string;
  description: string;
  hasInput?: boolean;
  placeholder?: string;
  category: string; // Used to group in UI
}

export interface ScriptDef {
  name: string;
  description: string;
  category: string;
}

export interface PresetDef {
  id: string;
  label: string;
  description: string;
  icon: string;
  flags: string[]; // List of flag strings e.g. "-sV", "--top-ports"
  values: Record<string, string>; // Map of flag -> value
  scripts?: string[]; // List of script categories or names
}

export interface Command {
  label: string;
  code: string;
}

export interface ServiceTool {
  name: string;
  description?: string;
  commands: Command[];
}

export interface ServiceItem {
  port: number;
  protocol: string;
  name: string;
  description: string;
  tools: ServiceTool[];
  whatToLookFor: string[];
}

export interface OsintTool {
  name: string;
  description?: string;
  commands: Command[];
}

export interface OsintTopic {
  id: string;
  name: string;
  icon: string;
  description: string;
  tools: OsintTool[];
  whatToLookFor: string[];
}

export interface WebEnumTool {
  name: string;
  description?: string;
  commands: Command[];
}

export interface WebEnumTopic {
  id: string;
  name: string;
  icon: string;
  description: string;
  tools: WebEnumTool[];
  whatToLookFor: string[];
}

export interface AdEnumTool {
  name: string;
  description?: string;
  commands: Command[];
}

export interface AdEnumTopic {
  id: string;
  name: string;
  icon: string;
  description: string;
  tools: AdEnumTool[];
  whatToLookFor: string[];
}

export interface AdReconTool {
  name: string;
  description?: string;
  commands: Command[];
}

export interface AdReconTopic {
  id: string;
  name: string;
  icon: string;
  description: string;
  tools: AdReconTool[];
  whatToLookFor: string[];
}

export interface AdAttackTool {
  name: string;
  description?: string;
  commands: Command[];
}

export interface AdAttackTopic {
  id: string;
  name: string;
  icon: string;
  description: string;
  tools: AdAttackTool[];
  whatToLookFor: string[];
}

export interface ExploitTool {
  name: string;
  description?: string;
  commands: Command[];
}

export interface ExploitTopic {
  id: string;
  name: string;
  icon: string;
  description: string;
  tools: ExploitTool[];
  whatToLookFor: string[];
}

export interface InfiltrationTool {
  name: string;
  description?: string;
  commands: Command[];
}

export interface InfiltrationTopic {
  id: string;
  name: string;
  icon: string;
  description: string;
  tools: InfiltrationTool[];
  whatToLookFor: string[];
}

export interface WebShellTool {
  name: string;
  description?: string;
  commands: Command[];
}

export interface WebShellTopic {
  id: string;
  name: string;
  icon: string;
  description: string;
  tools: WebShellTool[];
  whatToLookFor: string[];
}

export interface ShellTool {
  name: string;
  description?: string;
  commands: Command[];
}

export interface ShellTopic {
  id: string;
  name: string;
  icon: string;
  description: string;
  tools: ShellTool[];
  whatToLookFor: string[];
}

export interface OsFingerprintTool {
  name: string;
  description?: string;
  commands: Command[];
}

export interface OsFingerprintTopic {
  id: string;
  name: string;
  icon: string;
  description: string;
  tools: OsFingerprintTool[];
  whatToLookFor: string[];
}

// Case Builder Types
export interface CaseNote {
  id: string;
  content: string;
  timestamp: number;
}

export interface CaseArtifact {
  id: string;
  type: 'IP' | 'Domain' | 'Email' | 'User' | 'Phone' | 'Hash' | 'Other';
  value: string;
  description: string;
  timestamp: number;
}

export interface CaseTask {
  id: string;
  title: string;
  completed: boolean;
}

export interface Case {
  id: string;
  title: string;
  description: string;
  status: 'Active' | 'Closed' | 'Archived';
  priority: 'High' | 'Medium' | 'Low';
  created: number;
  updated: number;
  notes: CaseNote[];
  artifacts: CaseArtifact[];
  tasks: CaseTask[];
}

export type FlagState = Record<string, { active: boolean; value: string }>;
export type TabType = 'presets' | 'basic' | 'discovery' | 'scan' | 'timing' | 'evasion' | 'scripts' | 'output' | 'custom';
