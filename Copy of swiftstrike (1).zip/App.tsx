

import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import NmapBuilder from './components/NmapBuilder';
import EnumerationModule from './components/EnumerationModule';
import OsintModule from './components/OsintModule';
import WebEnumModule from './components/WebEnumModule';
import AdEnumModule from './components/AdEnumModule';
import AdReconModule from './components/AdReconModule';
import ExploitationModule from './components/ExploitationModule';
import InfiltrationModule from './components/InfiltrationModule';
import AdAttacksModule from './components/AdAttacksModule';
import WebShellsModule from './components/WebShellsModule';
import ShellsModule from './components/ShellsModule';
import OsFingerprintingModule from './components/OsFingerprintingModule';
import CaseBuilderModule from './components/CaseBuilderModule';
import SettingsModule from './components/SettingsModule';
import HackTricksModule from './components/HackTricksModule';

const App: React.FC = () => {
  const [activePage, setActivePage] = useState('nmap');

  return (
    <div className="flex min-h-screen">
      <Sidebar activePage={activePage} setPage={setActivePage} />
      
      <main className="flex-1 ml-[260px] p-8 max-w-[1600px]">
        {activePage === 'nmap' ? (
          <NmapBuilder />
        ) : activePage === 'enum' ? (
          <EnumerationModule />
        ) : activePage === 'osint' ? (
          <OsintModule />
        ) : activePage === 'casebuilder' ? (
          <CaseBuilderModule />
        ) : activePage === 'settings' ? (
          <SettingsModule />
        ) : activePage === 'hacktricks' ? (
          <HackTricksModule setPage={setActivePage} />
        ) : activePage === 'webenum' ? (
          <WebEnumModule />
        ) : activePage === 'ad' ? (
          <AdEnumModule />
        ) : activePage === 'adrecon' ? (
          <AdReconModule />
        ) : activePage === 'adattacks' ? (
          <AdAttacksModule />
        ) : activePage === 'exploitation' ? (
          <ExploitationModule />
        ) : activePage === 'infiltration' ? (
          <InfiltrationModule />
        ) : activePage === 'webshells' ? (
          <WebShellsModule />
        ) : activePage === 'shells' ? (
          <ShellsModule />
        ) : activePage === 'osfingerprint' ? (
          <OsFingerprintingModule />
        ) : (
          <div className="flex flex-col items-center justify-center h-[70vh] text-center">
            <i className="fas fa-hammer text-6xl text-[var(--text-muted)] mb-6 opacity-30"></i>
            <h2 className="text-2xl font-bold text-[var(--text-secondary)] mb-2">Work in Progress</h2>
            <p className="text-[var(--text-muted)]">The {activePage} module is currently under development.</p>
            <button 
                onClick={() => setActivePage('nmap')}
                className="mt-6 px-6 py-2 bg-[var(--accent-primary)] text-[var(--bg-primary)] rounded-lg font-medium hover:opacity-90 transition-all"
            >
                Return to Nmap Builder
            </button>
          </div>
        )}
      </main>
    </div>
  );
};

export default App;
