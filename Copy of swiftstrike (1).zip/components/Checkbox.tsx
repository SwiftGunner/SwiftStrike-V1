import React from 'react';

interface CheckboxProps {
  checked: boolean;
  onChange: () => void;
}

const Checkbox: React.FC<CheckboxProps> = ({ checked, onChange }) => {
  return (
    <div
      onClick={onChange}
      className={`
        w-[18px] h-[18px] min-w-[18px] 
        border-2 border-[var(--border-color)] rounded-[4px] 
        bg-[var(--bg-secondary)] 
        flex items-center justify-center 
        transition-all duration-150 cursor-pointer 
        hover:border-[var(--accent-primary)] mt-[2px]
        ${checked ? 'bg-[var(--accent-primary)] border-[var(--accent-primary)]' : ''}
      `}
    >
      {checked && <span className="text-[var(--bg-primary)] text-[11px] font-bold">✓</span>}
    </div>
  );
};

export default Checkbox;
