
import React, { useState, useMemo } from 'react';
import { SCRIPTS } from '../constants';
import { ScriptDef } from '../types';
import Checkbox from './Checkbox';

interface ScriptSelectorProps {
  selectedScripts: Set<string>;
  onToggleScript: (name: string) => void;
  onSelectCategory: (category: string) => void;
  onClearScripts: () => void;
}

const CATEGORIES = [
  { id: 'vuln', label: 'All Vuln', icon: 'fa-bug' },
  { id: 'safe', label: 'All Safe', icon: 'fa-shield-alt' },
  { id: 'smb', label: 'All SMB', icon: 'fa-server' },
  { id: 'http', label: 'All HTTP', icon: 'fa-globe' },
  { id: 'ssl', label: 'All SSL', icon: 'fa-lock' },
  { id: 'brute', label: 'All Brute', icon: 'fa-key' },
];

const ScriptSelector: React.FC<ScriptSelectorProps> = ({ selectedScripts, onToggleScript, onSelectCategory, onClearScripts }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [expandedCategories, setExpandedCategories] = useState<Set<string>>(new Set());

  const toggleCategory = (cat: string) => {
    const newExpanded = new Set(expandedCategories);
    if (newExpanded.has(cat)) {
      newExpanded.delete(cat);
    } else {
      newExpanded.add(cat);
    }
    setExpandedCategories(newExpanded);
  };

  const filteredScripts = useMemo(() => {
    if (!searchTerm) return SCRIPTS;
    return SCRIPTS.filter(
      (s) => s.name.toLowerCase().includes(searchTerm.toLowerCase()) || s.description.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [searchTerm]);

  const groupedScripts = useMemo(() => {
    const groups: Record<string, typeof SCRIPTS> = {};
    filteredScripts.forEach(script => {
      if (!groups[script.category]) groups[script.category] = [];
      groups[script.category].push(script);
    });
    return groups;
  }, [filteredScripts]);

  const categoryNames = {
    vuln: 'Vulnerability',
    smb: 'SMB/NetBIOS',
    http: 'HTTP/Web',
    ssl: 'SSL/TLS',
    brute: 'Auth/Brute',
    dns: 'DNS',
  };

  const getIcon = (cat: string) => {
     const icons: Record<string, string> = {
        vuln: 'fa-bug', smb: 'fa-server', http: 'fa-globe', ssl: 'fa-lock', brute: 'fa-key', dns: 'fa-globe-americas'
     };
     return icons[cat] || 'fa-code';
  };

  return (
    <div>
      <div className="bg-[var(--bg-card)] border border-[var(--border-color)] rounded-xl p-6 mb-6">
        <div className="relative mb-4">
            <i className="fas fa-search absolute left-4 top-1/2 -translate-y-1/2 text-[var(--text-muted)]"></i>
            <input 
                type="text" 
                className="w-full pl-10 p-3 bg-[var(--bg-tertiary)] border border-[var(--border-color)] rounded-lg text-[var(--text-primary)] font-mono focus:outline-none focus:border-[var(--accent-primary)] focus:shadow-[0_0_0_3px_var(--accent-primary-dim)] transition-all"
                placeholder="Search 400+ NSE scripts..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
            />
        </div>
        <div className="flex flex-wrap gap-2">
            {CATEGORIES.map(cat => (
                 <button 
                    key={cat.id}
                    onClick={() => onSelectCategory(cat.id)}
                    className="px-4 py-2 bg-[var(--bg-tertiary)] text-[var(--text-secondary)] border border-[var(--border-color)] rounded-lg text-xs font-medium hover:text-[var(--text-primary)] hover:border-[var(--accent-primary)] hover:bg-[var(--bg-hover)] transition-all flex items-center gap-2 uppercase tracking-wide"
                 >
                    <i className={`fas ${cat.icon}`}></i> {cat.label}
                 </button>
            ))}
            <button 
                onClick={onClearScripts}
                className="px-4 py-2 bg-[rgba(255,71,87,0.1)] text-[var(--accent-danger)] border border-[var(--accent-danger)] rounded-lg text-xs font-medium hover:bg-[var(--accent-danger)] hover:text-white transition-all flex items-center gap-2 uppercase tracking-wide ml-auto"
            >
                <i className="fas fa-times"></i> Clear
            </button>
        </div>
      </div>

      <div className="space-y-4">
        {Object.entries(groupedScripts).map(([cat, scripts]) => {
          const s = scripts as ScriptDef[];
          const isExpanded = searchTerm.length > 0 || expandedCategories.has(cat);
          
          return (
            <div 
                key={cat} 
                className={`
                    border rounded-xl overflow-hidden transition-all duration-300
                    ${isExpanded ? 'bg-[var(--bg-tertiary)] border-[var(--accent-primary-dim)]' : 'bg-[var(--bg-card)] border-[var(--border-color)] hover:border-[rgba(0,255,136,0.3)]'}
                `}
            >
                <div 
                    onClick={() => toggleCategory(cat)}
                    className="p-5 flex justify-between items-center cursor-pointer select-none group"
                >
                    <div className="flex items-center gap-4">
                        <div className={`
                            w-10 h-10 rounded-lg flex items-center justify-center text-lg transition-colors
                            ${isExpanded ? 'bg-[var(--accent-primary-dim)] text-[var(--accent-primary)]' : 'bg-[var(--bg-secondary)] text-[var(--text-muted)] group-hover:text-[var(--text-primary)]'}
                        `}>
                            <i className={`fas ${getIcon(cat)}`}></i>
                        </div>
                        <span className={`text-base font-bold transition-colors ${isExpanded ? 'text-[var(--accent-primary)]' : 'text-[var(--text-primary)]'}`}>
                            {categoryNames[cat as keyof typeof categoryNames] || cat.toUpperCase()}
                        </span>
                    </div>
                    
                    <span className="text-xs font-mono text-[var(--text-muted)] bg-[var(--bg-primary)] border border-[var(--border-color)] px-3 py-1 rounded-full">
                        {s.length}+
                    </span>
                </div>
                
                {/* Script List */}
                <div className={`
                    transition-all duration-300 ease-in-out overflow-hidden
                    ${isExpanded ? 'max-h-[800px] opacity-100 border-t border-[var(--border-color)]' : 'max-h-0 opacity-0'}
                `}>
                    <div className="p-4 grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
                        {s.map(script => {
                             const isSelected = selectedScripts.has(script.name);
                             return (
                                <div 
                                    key={script.name} 
                                    onClick={() => onToggleScript(script.name)}
                                    className={`
                                        flex items-start gap-3 p-3 rounded-lg cursor-pointer transition-all border relative
                                        ${isSelected 
                                            ? 'bg-[rgba(0,255,136,0.05)] border-[var(--accent-primary-dim)]' 
                                            : 'bg-[var(--bg-secondary)] border-transparent hover:bg-[var(--bg-primary)] hover:border-[var(--border-color)]'}
                                    `}
                                >
                                    <Checkbox checked={isSelected} onChange={() => {}} />
                                    <div className="min-w-0 flex-1">
                                        <div className={`font-mono text-xs font-bold truncate mb-1 ${isSelected ? 'text-[var(--accent-primary)]' : 'text-[var(--text-primary)]'}`}>
                                            {script.name}
                                        </div>
                                        <div className="text-[0.65rem] text-[var(--text-muted)] truncate" title={script.description}>
                                            {script.description}
                                        </div>
                                    </div>
                                    {isSelected && (
                                        <div className="absolute right-2 top-2 w-1.5 h-1.5 rounded-full bg-[var(--accent-primary)] shadow-[0_0_8px_var(--accent-primary)]"></div>
                                    )}
                                </div>
                             );
                        })}
                    </div>
                </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ScriptSelector;
