

import React, { useState, useEffect } from 'react';
import Toast from './Toast';

interface HackTricksModuleProps {
  setPage: (page: string) => void;
}

const HackTricksModule: React.FC<HackTricksModuleProps> = ({ setPage }) => {
  const [lastUpdate, setLastUpdate] = useState<string>('Checking...');
  const [lastCommitMsg, setLastCommitMsg] = useState<string>('');
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const [toast, setToast] = useState({ show: false, message: '' });

  useEffect(() => {
    // Fetch latest commit from HackTricks main repo
    fetch('https://api.github.com/repos/carlospolop/hacktricks/commits?per_page=1')
      .then(res => res.json())
      .then(data => {
        if (data && Array.isArray(data) && data.length > 0) {
          const date = new Date(data[0].commit.author.date);
          setLastUpdate(date.toLocaleString());
          setLastCommitMsg(data[0].commit.message);
        } else {
          setLastUpdate('Unknown');
        }
        setLoading(false);
      })
      .catch(() => {
        setLastUpdate('Offline / API Limit Exceeded');
        setLoading(false);
      });
  }, []);

  const handleSearch = (term: string) => {
    if (!term.trim()) return;
    const query = `site:book.hacktricks.xyz ${term}`;
    window.open(`https://www.google.com/search?q=${encodeURIComponent(query)}`, '_blank');
    setToast({ show: true, message: 'Opening HackTricks...' });
  };

  const handleNavigate = (page: string, hash?: string) => {
    setPage(page);
    if (hash) {
      setTimeout(() => {
        window.location.hash = hash;
      }, 100);
    }
  };

  const quickLinks = [
    { title: 'Linux PrivEsc', icon: 'fa-linux', term: 'linux privilege escalation', page: 'infiltration', hash: 'infiltration-linux-recon' },
    { title: 'Windows PrivEsc', icon: 'fa-windows', term: 'windows privilege escalation', page: 'infiltration', hash: 'infiltration-windows-recon' },
    { title: 'Active Directory', icon: 'fa-network-wired', term: 'active directory methodology', page: 'ad', hash: 'ad-domain-discovery' },
    { title: 'SQL Injection', icon: 'fa-database', term: 'sql injection', page: 'exploitation', hash: 'exploit-exploit-http' },
    { title: 'XSS', icon: 'fa-code', term: 'xss cross site scripting', page: 'exploitation', hash: 'exploit-exploit-http' },
    { title: 'SSRF', icon: 'fa-server', term: 'ssrf server side request forgery', page: 'exploitation', hash: 'exploit-exploit-http' },
    { title: 'Kerberos', icon: 'fa-key', term: 'kerberos attacks', page: 'adattacks', hash: 'adattacks-kerberoasting' },
    { title: 'File Transfers', icon: 'fa-exchange-alt', term: 'file transfer cheatsheet', page: 'exploitation', hash: 'exploit-exploit-ftp' },
    { title: 'Reverse Shells', icon: 'fa-terminal', term: 'shells reverse tcp', page: 'shells', hash: 'shells-tty-spawning' },
    { title: 'Web Shells', icon: 'fa-skull', term: 'web shells', page: 'webshells', hash: 'webshells-laudanum' },
  ];

  return (
    <div className="h-full flex flex-col pb-20">
      {/* Header */}
      <div className="flex justify-between items-end mb-8">
        <div>
          <h1 className="font-[Orbitron] text-3xl font-bold flex items-center gap-3 mb-2 text-[var(--accent-danger)] drop-shadow-[0_0_15px_rgba(255,71,87,0.3)]">
            HackTricks Integration
          </h1>
          <p className="text-[var(--text-secondary)] text-[0.95rem]">
            The ultimate penetration testing methodology, synchronized.
          </p>
        </div>
        
        {/* Status Badge */}
        <div className="bg-[var(--bg-card)] border border-[var(--border-color)] rounded-xl p-4 flex items-center gap-4 shadow-lg">
            <div className={`w-3 h-3 rounded-full ${loading ? 'bg-yellow-500 animate-pulse' : 'bg-[var(--accent-primary)] shadow-[0_0_10px_var(--accent-primary)]'}`}></div>
            <div>
                <div className="text-[0.65rem] font-bold text-[var(--text-muted)] uppercase tracking-wider">Knowledge Base Status</div>
                <div className="text-sm font-mono text-[var(--text-primary)]">
                    {loading ? 'Syncing...' : `Updated: ${lastUpdate}`}
                </div>
            </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Search Section */}
        <div className="lg:col-span-2 space-y-8">
            <div className="bg-[var(--bg-card)] border border-[var(--border-color)] rounded-xl p-8 shadow-lg">
                <h2 className="text-xl font-bold text-[var(--text-primary)] mb-6 flex items-center gap-3">
                    <i className="fas fa-search text-[var(--accent-primary)]"></i> Deep Search
                </h2>
                <div className="relative">
                    <input 
                        type="text" 
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleSearch(searchTerm)}
                        placeholder="Search for protocols, CVEs, or techniques..."
                        className="w-full pl-12 pr-4 py-4 bg-[var(--bg-secondary)] border border-[var(--border-color)] rounded-lg text-[var(--text-primary)] font-mono text-lg focus:outline-none focus:border-[var(--accent-primary)] focus:shadow-[0_0_0_4px_var(--accent-primary-dim)] transition-all"
                    />
                    <i className="fas fa-search absolute left-4 top-1/2 -translate-y-1/2 text-[var(--text-muted)] text-xl"></i>
                    <button 
                        onClick={() => handleSearch(searchTerm)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 px-4 py-2 bg-[var(--accent-primary)] text-[var(--bg-primary)] rounded font-bold hover:opacity-90 transition-all"
                    >
                        GO
                    </button>
                </div>
                <div className="mt-4 text-xs text-[var(--text-muted)]">
                    * Searches directly within book.hacktricks.xyz
                </div>
            </div>

            <div className="bg-[var(--bg-tertiary)] border border-[var(--border-color)] rounded-xl p-6">
                <h3 className="text-sm font-bold text-[var(--text-secondary)] uppercase tracking-wider mb-4">Quick Access</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {quickLinks.map((link, idx) => (
                        <div key={idx} className="flex flex-col gap-1">
                            <button
                                onClick={() => link.page ? handleNavigate(link.page, link.hash) : handleSearch(link.term)}
                                className="flex items-center gap-3 p-4 bg-[var(--bg-card)] border border-[var(--border-color)] rounded-lg hover:border-[var(--accent-primary)] hover:bg-[var(--bg-hover)] transition-all group text-left h-full"
                            >
                                <i className={`fas ${link.icon} text-[var(--text-muted)] group-hover:text-[var(--accent-primary)] transition-colors text-lg`}></i>
                                <span className="text-sm font-medium text-[var(--text-primary)]">{link.title}</span>
                            </button>
                            <button 
                                onClick={(e) => { e.stopPropagation(); handleSearch(link.term); }}
                                className="text-[0.65rem] text-[var(--text-muted)] hover:text-[var(--accent-secondary)] text-right pr-1"
                            >
                                Search External <i className="fas fa-external-link-alt ml-1"></i>
                            </button>
                        </div>
                    ))}
                </div>
            </div>
        </div>

        {/* Info Column */}
        <div className="space-y-6">
            <div className="bg-[var(--bg-card)] border border-[var(--border-color)] rounded-xl p-6">
                <h3 className="text-sm font-bold text-[var(--text-secondary)] uppercase tracking-wider mb-4 border-b border-[var(--border-color)] pb-2">
                    Latest Contribution
                </h3>
                <div className="bg-[var(--bg-secondary)] rounded p-4 font-mono text-xs text-[var(--text-muted)] border border-[var(--border-color)]">
                    {loading ? 'Fetching...' : lastCommitMsg || 'No commit message available.'}
                </div>
            </div>

            <div className="bg-[var(--bg-card)] border border-[var(--border-color)] rounded-xl p-6 bg-gradient-to-br from-[var(--bg-card)] to-[rgba(255,71,87,0.05)]">
                <div className="flex items-center gap-3 mb-4">
                    <i className="fab fa-github text-2xl text-[var(--text-primary)]"></i>
                    <div>
                        <div className="font-bold text-[var(--text-primary)]">HackTricks Repo</div>
                        <div className="text-xs text-[var(--text-muted)]">carlospolop/hacktricks</div>
                    </div>
                </div>
                <p className="text-sm text-[var(--text-secondary)] mb-4">
                    Welcome to the page where you will find each hacking trick/technique/whatever I have learnt from CTFs, real life apps, and reading researches and news.
                </p>
                <a 
                    href="https://book.hacktricks.xyz/" 
                    target="_blank" 
                    rel="noreferrer"
                    className="block w-full py-2 bg-[var(--bg-tertiary)] border border-[var(--border-color)] text-center text-[var(--accent-primary)] rounded font-bold hover:bg-[var(--accent-primary)] hover:text-[var(--bg-primary)] transition-all"
                >
                    Visit Book
                </a>
            </div>
        </div>

      </div>

      <Toast message={toast.message} isVisible={toast.show} onClose={() => setToast({ ...toast, show: false })} />
    </div>
  );
};

export default HackTricksModule;
