import React from 'react';
import { FlagDef, FlagState } from '../types';
import Checkbox from './Checkbox';

interface FlagCategoryProps {
  title: string;
  icon: string;
  flags: FlagDef[];
  flagState: FlagState;
  onToggle: (flag: string) => void;
  onInputChange: (flag: string, value: string) => void;
}

const FlagCategory: React.FC<FlagCategoryProps> = ({ title, icon, flags, flagState, onToggle, onInputChange }) => {
  return (
    <div className="bg-[var(--bg-tertiary)] border border-[var(--border-color)] rounded-lg p-4 h-full">
      <h3 className="text-[0.8rem] font-semibold text-[var(--accent-primary)] mb-4 uppercase tracking-widest flex items-center gap-2 sticky top-0 bg-[var(--bg-tertiary)] pb-2 z-10">
        <i className={`fas ${icon}`}></i> {title}
      </h3>
      <div className="space-y-3">
        {flags.map((flag) => {
          const isActive = flagState[flag.flag]?.active || false;
          return (
            <div key={flag.flag} className="group">
              <div className="flex items-start gap-2 cursor-pointer" onClick={() => onToggle(flag.flag)}>
                <Checkbox checked={isActive} onChange={() => {}} />
                <div className="flex-1">
                  <div className={`text-[0.85rem] transition-colors ${isActive ? 'text-[var(--accent-primary)]' : 'text-[var(--text-secondary)] group-hover:text-[var(--accent-primary)]'}`}>
                    {flag.label}
                  </div>
                  <div className="text-[0.7rem] text-[var(--text-muted)]">{flag.description}</div>
                </div>
              </div>
              {flag.hasInput && isActive && (
                <input
                  type="text"
                  className="w-full mt-2 p-2 bg-[var(--bg-secondary)] border border-[var(--border-color)] rounded text-[var(--text-primary)] font-mono text-xs focus:outline-none focus:border-[var(--accent-primary)]"
                  placeholder={flag.placeholder}
                  value={flagState[flag.flag]?.value || ''}
                  onChange={(e) => onInputChange(flag.flag, e.target.value)}
                />
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default FlagCategory;