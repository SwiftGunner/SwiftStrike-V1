

import React, { useState, useEffect } from 'react';
import Toast from './Toast';
import { AD_ENUM_TOPICS } from '../constants';
import { AdEnumTopic, AdEnumTool } from '../types';

// Reusable Input Component
const ControlInput: React.FC<{
  label: string;
  value: string;
  onChange: (val: string) => void;
  placeholder: string;
  className?: string;
  type?: string;
}> = ({ label, value, onChange, placeholder, className = '', type = 'text' }) => (
  <div className={`relative ${className}`}>
    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
      <span className="text-[var(--text-muted)] text-[0.65rem] font-bold tracking-wider uppercase">{label}:</span>
    </div>
    <input
      type={type}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="w-full pl-[4.5rem] pr-3 py-2.5 bg-[var(--bg-secondary)] border border-[var(--border-color)] rounded-lg text-[var(--text-primary)] font-mono text-xs focus:outline-none focus:border-[var(--accent-primary)] transition-all placeholder-[var(--text-muted)]"
      placeholder={placeholder}
    />
  </div>
);

// Tool Card Component
const ToolCard: React.FC<{
  tool: AdEnumTool;
  topicId: string;
  onCopy: (text: string) => void;
  formatCommand: (text: string) => string;
}> = ({ tool, topicId, onCopy, formatCommand }) => {
  const toolId = `ad-${topicId}-tool-${tool.name.replace(/\s+/g, '-').toLowerCase()}`;
  
  return (
    <div id={toolId} className="space-y-4 scroll-mt-24 rounded-lg transition-all duration-300">
      <div className="flex items-center gap-2 text-[var(--accent-secondary)] text-sm font-bold uppercase tracking-wider opacity-80 mb-2">
        <i className="fas fa-toolbox"></i> {tool.name}
      </div>
      {tool.description && (
        <p className="text-[0.7rem] text-[var(--text-muted)] mb-3 italic">{tool.description}</p>
      )}
      {tool.commands.map((cmd, cIdx) => (
        <div
          key={cIdx}
          className="bg-[var(--bg-card)] border border-[var(--border-color)] rounded-xl overflow-hidden group hover:border-[var(--accent-primary-dim)] transition-all"
        >
          <div className="p-3 border-b border-[var(--border-color)] bg-[var(--bg-secondary)] flex justify-between items-start">
            <div>
              <h3 className="font-semibold text-[var(--text-primary)] text-sm">{cmd.label}</h3>
              <p className="text-[0.65rem] text-[var(--text-muted)] mt-0.5">Execute command</p>
            </div>
            <button
              onClick={() => onCopy(cmd.code)}
              className="text-[var(--text-muted)] hover:text-[var(--accent-primary)] transition-colors p-1"
              title="Copy Command"
            >
              <i className="far fa-copy"></i>
            </button>
          </div>
          <div className="p-4 bg-[#0d0d12] relative overflow-x-auto">
            <code className="font-mono text-sm text-[var(--accent-primary)] whitespace-pre-wrap break-all">
              {formatCommand(cmd.code)}
            </code>
          </div>
        </div>
      ))}
    </div>
  );
};

// Methodology Component
const MethodologyChecklist: React.FC<{ items: string[] }> = ({ items }) => (
  <div className="sticky top-6">
    <div className="bg-[var(--bg-tertiary)] border border-[var(--border-color)] rounded-xl p-5 shadow-lg">
      <h3 className="text-sm font-bold text-[var(--text-primary)] mb-4 flex items-center gap-2 uppercase tracking-wider border-b border-[var(--border-color)] pb-3">
        <i className="fas fa-search-plus text-[var(--accent-primary)]"></i> Checkpoints
      </h3>
      <ul className="space-y-3">
        {items.map((item, idx) => (
          <li key={idx} className="flex items-start gap-3 group">
            <span className="w-5 h-5 min-w-[20px] rounded border border-[var(--border-color)] bg-[var(--bg-secondary)] flex items-center justify-center text-[var(--accent-primary)] text-xs mt-0.5 group-hover:border-[var(--accent-primary)] transition-colors">
              {idx + 1}
            </span>
            <span className="text-[0.85rem] text-[var(--text-secondary)] leading-relaxed group-hover:text-[var(--text-primary)] transition-colors">
              {item}
            </span>
          </li>
        ))}
      </ul>
      <div className="mt-6 pt-4 border-t border-[var(--border-color)]">
        <div className="flex items-center gap-2 text-[var(--text-muted)] text-xs">
          <i className="fas fa-info-circle"></i>
          <span>Source: HackTricks / Active Directory</span>
        </div>
      </div>
    </div>
  </div>
);

const AdEnumModule: React.FC = () => {
  const [selectedTopicId, setSelectedTopicId] = useState<string>('domain-discovery');
  const [domain, setDomain] = useState('');
  const [dcIp, setDcIp] = useState('');
  const [user, setUser] = useState('');
  const [password, setPassword] = useState('');
  const [userList, setUserList] = useState('');
  const [toast, setToast] = useState({ show: false, message: '' });

  // Handle hash navigation
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash;
      if (hash && hash.startsWith('#ad-')) {
        const parts = hash.replace('#ad-', '').split('-');
        const topicId = parts[0] + (parts[1] && !parts[1].startsWith('tool') ? '-' + parts[1] : ''); 

        // Fix potential parsing issue if topic ID has hyphens and hash includes tool
        // Simplified: Loop through topics to match prefix
        const foundTopic = AD_ENUM_TOPICS.find(t => hash.replace('#ad-', '').startsWith(t.id));
        
        if (foundTopic) {
          setSelectedTopicId(foundTopic.id);
          setTimeout(() => {
            const el = document.getElementById(hash.replace('#', ''));
            if (el) {
              el.scrollIntoView({ behavior: 'smooth', block: 'center' });
              el.classList.add('border-[var(--accent-primary)]');
              setTimeout(() => el.classList.remove('border-[var(--accent-primary)]'), 1000);
            } else {
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }
          }, 100);
        }
      }
    };

    handleHashChange();
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const activeTopic: AdEnumTopic | undefined = AD_ENUM_TOPICS.find(t => t.id === selectedTopicId);

  const formatCommand = (cmd: string) => {
    const replacements: Record<string, string> = {
      '<DOMAIN>': domain || 'domain.local',
      '<DC_IP>': dcIp || 'DC_IP',
      '<USER>': user || 'user',
      '<PASS>': password || 'password',
      '<PASSWORD>': password || 'password',
      '<TARGET_USER>': 'TargetUser',
      '<ENCRYPTED_PASS>': 'EncryptedString',
      '<CA_NAME>': 'CA-NAME',
      '<TEMPLATE>': 'User',
      '<USER_LIST>': userList || 'users.txt'
    };

    return Object.entries(replacements).reduce((acc, [key, val]) => acc.split(key).join(val), cmd);
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(formatCommand(text));
    setToast({ show: true, message: 'Copied to clipboard!' });
  };

  return (
    <div className="h-full flex flex-col pb-20">
      {/* Header */}
      <div className="flex justify-between items-end mb-8">
        <div>
          <h1 className="font-[Orbitron] text-3xl font-bold flex items-center gap-3 mb-2">
            Active Directory Enumeration
          </h1>
          <p className="text-[var(--text-secondary)] text-[0.95rem]">
            Active Directory reconnaissance, attack vectors, and tools.
          </p>
        </div>
      </div>

      {/* Control Bar */}
      <div className="bg-[var(--bg-card)] border border-[var(--border-color)] rounded-xl p-6 mb-8 shadow-lg">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4 items-end">
          {/* Topic Selector */}
          <div className="min-w-[200px]">
            <div className="relative group">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none z-10">
                <span className="text-[var(--text-muted)] text-[0.65rem] font-bold tracking-wider uppercase">TOPIC:</span>
              </div>
              <select
                value={selectedTopicId}
                onChange={(e) => setSelectedTopicId(e.target.value)}
                className="appearance-none w-full pl-[4.5rem] pr-8 py-2.5 bg-[var(--bg-secondary)] border border-[var(--border-color)] rounded-lg text-[var(--accent-primary)] font-mono text-xs focus:outline-none focus:border-[var(--accent-primary)] transition-all cursor-pointer hover:bg-[var(--bg-hover)]"
              >
                {AD_ENUM_TOPICS.map(t => (
                  <option key={t.id} value={t.id}>{t.name}</option>
                ))}
              </select>
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-[var(--text-muted)]">
                <i className="fas fa-chevron-down text-xs"></i>
              </div>
            </div>
          </div>

          <ControlInput label="DOMAIN" value={domain} onChange={setDomain} placeholder="megacorp.local" />
          <ControlInput label="DC IP" value={dcIp} onChange={setDcIp} placeholder="10.10.10.10" />
          <ControlInput label="USER" value={user} onChange={setUser} placeholder="username" />
          <ControlInput label="PASS" value={password} onChange={setPassword} placeholder="password" type="text" />
          <ControlInput label="USER LIST" value={userList} onChange={setUserList} placeholder="users.txt" />
        </div>
      </div>

      {/* Main Content */}
      {activeTopic ? (
        <div className="animate-fade-in flex flex-col xl:flex-row gap-6">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-3 mb-6 pb-4 border-b border-[var(--border-color)]">
              <div className="w-10 h-10 rounded-lg bg-[var(--bg-tertiary)] flex items-center justify-center text-[var(--accent-primary)] text-xl border border-[var(--border-color)]">
                <i className={`fas ${activeTopic.icon}`}></i>
              </div>
              <div>
                <h2 className="text-2xl font-bold text-[var(--text-primary)]">
                    {activeTopic.name}
                </h2>
                <p className="text-xs text-[var(--text-muted)]">{activeTopic.description}</p>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-1 xl:grid-cols-2 gap-6">
              {activeTopic.tools.map((tool, tIdx) => (
                <ToolCard 
                  key={tIdx} 
                  tool={tool} 
                  topicId={activeTopic.id} 
                  onCopy={handleCopy} 
                  formatCommand={formatCommand} 
                />
              ))}
            </div>
          </div>

          <div className="w-full xl:w-[320px] shrink-0">
            <MethodologyChecklist items={activeTopic.whatToLookFor} />
          </div>
        </div>
      ) : (
        <div className="flex-1 flex flex-col items-center justify-center text-[var(--text-muted)]">
          <i className="fas fa-network-wired text-4xl mb-4 opacity-20"></i>
          <p>Select a topic to begin AD Enumeration</p>
        </div>
      )}

      <Toast message={toast.message} isVisible={toast.show} onClose={() => setToast({ ...toast, show: false })} />
    </div>
  );
};

export default AdEnumModule;