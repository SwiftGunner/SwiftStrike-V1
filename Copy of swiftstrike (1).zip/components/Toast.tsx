import React, { useEffect, useState } from 'react';

interface ToastProps {
  message: string;
  isVisible: boolean;
  onClose: () => void;
}

const Toast: React.FC<ToastProps> = ({ message, isVisible, onClose }) => {
  const [show, setShow] = useState(false);

  useEffect(() => {
    if (isVisible) {
      setShow(true);
      const timer = setTimeout(() => {
        setShow(false);
        setTimeout(onClose, 300); // Wait for animation
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [isVisible, onClose]);

  if (!isVisible && !show) return null;

  return (
    <div
      className={`
        fixed bottom-8 right-8 
        padding px-6 py-4 
        bg-[var(--bg-card)] border border-[var(--accent-primary)] rounded-lg 
        text-[var(--text-primary)] text-sm 
        shadow-[0_8px_24px_rgba(0,0,0,0.5)] z-[1000] 
        flex items-center gap-3
        transition-all duration-300 transform
        ${show ? 'translate-x-0 opacity-100' : 'translate-x-full opacity-0'}
      `}
    >
      <i className="fas fa-check-circle text-[var(--accent-primary)]"></i>
      <span>{message}</span>
    </div>
  );
};

export default Toast;
