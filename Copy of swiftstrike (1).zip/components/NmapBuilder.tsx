
import React, { useState, useMemo } from 'react';
import { FLAGS, PRESETS, SCRIPTS } from '../constants';
import { FlagState, FlagDef } from '../types';
import FlagCategory from './FlagCategory';
import ScriptSelector from './ScriptSelector';
import CommandOutput from './CommandOutput';
import Toast from './Toast';

// Component for a group of flags
const FlagGroup: React.FC<{
  categoryPrefix: string;
  title: string;
  icon: string;
  flagState: FlagState;
  onToggle: (flag: string) => void;
  onInputChange: (flag: string, value: string) => void;
}> = ({ categoryPrefix, title, icon, flagState, onToggle, onInputChange }) => {
  const groupFlags = useMemo(
    () => FLAGS.filter(f => f.category.startsWith(categoryPrefix)),
    [categoryPrefix]
  );

  if (groupFlags.length === 0) return null;

  return (
    <FlagCategory
      title={title}
      icon={icon}
      flags={groupFlags}
      flagState={flagState}
      onToggle={onToggle}
      onInputChange={onInputChange}
    />
  );
};

// Section Header Component
const SectionHeader: React.FC<{ title: string; icon: string }> = ({ title, icon }) => (
  <h2 className="text-sm font-bold text-[var(--text-secondary)] uppercase tracking-wider mb-4 border-b border-[var(--border-color)] pb-2 flex items-center gap-2 mt-8 first:mt-0">
    <i className={`fas ${icon} text-[var(--accent-primary)]`}></i> {title}
  </h2>
);

const NmapBuilder: React.FC = () => {
  const [target, setTarget] = useState('');
  const [flagState, setFlagState] = useState<FlagState>({});
  const [selectedScripts, setSelectedScripts] = useState<Set<string>>(new Set());
  const [customCommand, setCustomCommand] = useState('');
  const [toast, setToast] = useState({ show: false, message: '' });

  // Compute command
  const generatedCommand = useMemo(() => {
    let parts = ['sudo nmap'];
    parts.push(target || '{{IP}}');

    Object.entries(flagState).forEach(([flag, state]) => {
      const typedState = state as { active: boolean; value: string };
      if (typedState.active) {
        if (typedState.value) {
          parts.push(flag.includes('=') ? `${flag}${typedState.value}` : `${flag} ${typedState.value}`);
        } else {
          parts.push(flag);
        }
      }
    });

    if (selectedScripts.size > 0) {
      parts.push(`--script=${Array.from(selectedScripts).join(',')}`);
    }

    if (customCommand) {
      parts.push(customCommand.replace(/\n/g, ' '));
    }

    return parts.join(' ');
  }, [target, flagState, selectedScripts, customCommand]);

  const toggleFlag = (flag: string) => {
    setFlagState(prev => {
      const current = prev[flag];
      if (current?.active) {
        const newState = { ...prev };
        delete newState[flag];
        return newState;
      }
      return { ...prev, [flag]: { active: true, value: current?.value || '' } };
    });
  };

  const updateFlagValue = (flag: string, value: string) => {
    setFlagState(prev => ({
      ...prev,
      [flag]: { active: true, value }
    }));
  };

  const applyPreset = (presetId: string) => {
    const preset = PRESETS.find(p => p.id === presetId);
    if (!preset) return;

    setFlagState({});
    setSelectedScripts(new Set());

    const newState: FlagState = {};
    preset.flags.forEach(f => {
      newState[f] = { active: true, value: preset.values[f] || '' };
    });
    setFlagState(newState);

    if (preset.scripts) {
      const newScripts = new Set<string>();
      preset.scripts.forEach(cat => {
        SCRIPTS.filter(s => s.category === cat).forEach(s => newScripts.add(s.name));
      });
      setSelectedScripts(newScripts);
    }

    showToast(`Preset applied: ${preset.label}`);
  };

  const clearAll = () => {
    setFlagState({});
    setSelectedScripts(new Set());
    setCustomCommand('');
    showToast('Configuration reset');
  };

  const showToast = (msg: string) => setToast({ show: true, message: msg });

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedCommand);
    showToast('Copied to clipboard!');
  };

  const StatBadge = ({ value, label }: { value: number | string; label: string }) => (
    <div className="bg-[var(--bg-tertiary)] px-4 py-2 rounded-lg border border-[var(--border-color)] flex items-center gap-3">
      <span className="text-[var(--accent-primary)] font-bold font-mono text-lg">{value}</span>
      <span className="text-xs text-[var(--text-muted)] uppercase tracking-wider">{label}</span>
    </div>
  );

  return (
    <div className="flex flex-col h-full relative pb-10">
      {/* Header */}
      <div className="flex justify-between items-end mb-6">
        <div>
          <h1 className="font-[Orbitron] text-3xl font-bold flex items-center gap-3 mb-2">
            Nmap Scans
          </h1>
          <p className="text-[var(--text-secondary)] text-[0.95rem]">
            Advanced network discovery and security auditing.
          </p>
        </div>
        <div className="flex gap-3">
          <StatBadge value={Object.keys(flagState).length} label="Flags" />
          <StatBadge value={selectedScripts.size} label="Scripts" />
        </div>
      </div>

      {/* Control Bar */}
      <div className="bg-[var(--bg-card)] border border-[var(--border-color)] rounded-xl p-6 mb-8 shadow-lg">
        <div className="flex flex-wrap gap-6 items-end">
          <div className="flex-1 min-w-[300px]">
            <div className="relative group">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <span className="text-[var(--text-muted)] text-xs font-bold tracking-wider uppercase">TARGET:</span>
              </div>
              <input
                type="text"
                value={target}
                onChange={(e) => setTarget(e.target.value)}
                className="w-full pl-[4.5rem] pr-10 py-3 bg-[var(--bg-secondary)] border border-[var(--border-color)] rounded-lg text-[var(--text-primary)] font-mono text-sm focus:outline-none focus:border-[var(--accent-primary)] transition-all placeholder-[var(--text-muted)]"
                placeholder="10.10.10.10, 192.168.1.0/24"
              />
              {target && (
                <button
                  onClick={() => setTarget('')}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center text-[var(--text-muted)] hover:text-[var(--accent-danger)]"
                >
                  <i className="fas fa-times"></i>
                </button>
              )}
            </div>
          </div>
          <button
            onClick={clearAll}
            className="px-4 py-3 bg-[var(--bg-tertiary)] text-[var(--text-secondary)] border border-[var(--border-color)] rounded-lg font-medium text-sm hover:text-[var(--accent-danger)] hover:border-[var(--accent-danger)] transition-all flex items-center gap-2"
          >
            <i className="fas fa-trash-alt"></i> Reset
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="animate-fade-in">
        
        {/* Presets */}
        <section className="mb-8">
          <SectionHeader title="Quick Presets" icon="fa-bolt" />
          <div className="grid grid-cols-[repeat(auto-fill,minmax(200px,1fr))] gap-3">
            {PRESETS.map(preset => (
              <button
                key={preset.id}
                onClick={() => applyPreset(preset.id)}
                className="flex items-center gap-3 p-3 bg-[var(--bg-card)] border border-[var(--border-color)] rounded-lg text-left hover:bg-[var(--bg-hover)] hover:border-[var(--accent-primary)] hover:shadow-[0_0_15px_rgba(0,255,136,0.1)] transition-all group"
              >
                <div className="w-8 h-8 rounded bg-[var(--bg-tertiary)] flex items-center justify-center text-[var(--accent-primary)] group-hover:bg-[var(--accent-primary)] group-hover:text-[var(--bg-primary)] transition-colors">
                  <i className={`fas ${preset.icon} text-sm`}></i>
                </div>
                <div className="min-w-0">
                  <div className="font-bold text-[var(--text-primary)] text-xs mb-0.5">{preset.label}</div>
                  <div className="text-[0.65rem] text-[var(--text-secondary)] truncate">{preset.description}</div>
                </div>
              </button>
            ))}
          </div>
        </section>

        {/* Discovery Section */}
        <section className="mb-8">
          <SectionHeader title="Target & Discovery" icon="fa-satellite-dish" />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <FlagGroup categoryPrefix="basic_port" title="Port Specification" icon="fa-plug" flagState={flagState} onToggle={toggleFlag} onInputChange={updateFlagValue} />
            <FlagGroup categoryPrefix="discovery_host" title="Host Discovery" icon="fa-network-wired" flagState={flagState} onToggle={toggleFlag} onInputChange={updateFlagValue} />
            <FlagGroup categoryPrefix="discovery_dns" title="DNS Options" icon="fa-globe" flagState={flagState} onToggle={toggleFlag} onInputChange={updateFlagValue} />
          </div>
        </section>

        {/* Scan Techniques Section */}
        <section className="mb-8">
          <SectionHeader title="Scan Techniques" icon="fa-search" />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <FlagGroup categoryPrefix="basic_detect" title="Detection & Version" icon="fa-fingerprint" flagState={flagState} onToggle={toggleFlag} onInputChange={updateFlagValue} />
            <FlagGroup categoryPrefix="scan_tcp" title="TCP Scan Types" icon="fa-exchange-alt" flagState={flagState} onToggle={toggleFlag} onInputChange={updateFlagValue} />
            <FlagGroup categoryPrefix="scan_other" title="Other Scans" icon="fa-project-diagram" flagState={flagState} onToggle={toggleFlag} onInputChange={updateFlagValue} />
          </div>
        </section>

        {/* Timing Section */}
        <section className="mb-8">
          <SectionHeader title="Timing & Performance" icon="fa-stopwatch" />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <FlagGroup categoryPrefix="basic_timing" title="Timing Templates" icon="fa-clock" flagState={flagState} onToggle={toggleFlag} onInputChange={updateFlagValue} />
            <FlagGroup categoryPrefix="timing_rate" title="Rate Control" icon="fa-tachometer-alt" flagState={flagState} onToggle={toggleFlag} onInputChange={updateFlagValue} />
            <FlagGroup categoryPrefix="timing_timeout" title="Timeouts" icon="fa-hourglass" flagState={flagState} onToggle={toggleFlag} onInputChange={updateFlagValue} />
            <FlagGroup categoryPrefix="timing_group" title="Host Groups" icon="fa-layer-group" flagState={flagState} onToggle={toggleFlag} onInputChange={updateFlagValue} />
          </div>
        </section>

        {/* Evasion Section */}
        <section className="mb-8">
          <SectionHeader title="Evasion & Spoofing" icon="fa-user-ninja" />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <FlagGroup categoryPrefix="evasion_frag" title="Fragmentation" icon="fa-puzzle-piece" flagState={flagState} onToggle={toggleFlag} onInputChange={updateFlagValue} />
            <FlagGroup categoryPrefix="evasion_spoof" title="Source Spoofing" icon="fa-mask" flagState={flagState} onToggle={toggleFlag} onInputChange={updateFlagValue} />
            <FlagGroup categoryPrefix="evasion_route" title="Routing" icon="fa-route" flagState={flagState} onToggle={toggleFlag} onInputChange={updateFlagValue} />
          </div>
        </section>

        {/* Output Section */}
        <section className="mb-8">
          <SectionHeader title="Output & Verbosity" icon="fa-file-alt" />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <FlagGroup categoryPrefix="output_fmt" title="Output Formats" icon="fa-file-export" flagState={flagState} onToggle={toggleFlag} onInputChange={updateFlagValue} />
            <FlagGroup categoryPrefix="output_verb" title="Verbosity & Debug" icon="fa-bug" flagState={flagState} onToggle={toggleFlag} onInputChange={updateFlagValue} />
          </div>
        </section>

        {/* Scripts Section */}
        <section className="mb-8">
          <SectionHeader title="NSE Scripts" icon="fa-code" />
          <ScriptSelector
            selectedScripts={selectedScripts}
            onToggleScript={(name) => {
              const newSet = new Set(selectedScripts);
              if (newSet.has(name)) newSet.delete(name);
              else newSet.add(name);
              setSelectedScripts(newSet);
            }}
            onSelectCategory={(cat) => {
              const newSet = new Set(selectedScripts);
              SCRIPTS.filter(s => s.category === cat).forEach(s => newSet.add(s.name));
              setSelectedScripts(newSet);
              showToast(`Added all ${cat} scripts`);
            }}
            onClearScripts={() => setSelectedScripts(new Set())}
          />
        </section>

        {/* Custom Command Section */}
        <section className="mb-8">
          <div className="bg-[var(--bg-card)] border border-[var(--border-color)] rounded-xl p-6">
            <div className="flex justify-between items-center mb-4 pb-4 border-b border-[var(--border-color)]">
              <h2 className="text-base font-semibold flex items-center gap-2">
                <i className="fas fa-terminal text-[var(--accent-primary)]"></i> Custom Command Addition
              </h2>
            </div>
            <p className="text-[var(--text-secondary)] mb-4 text-sm">
              Add any custom flags or options not available in the UI. These will be appended to the generated command.
            </p>
            <textarea
              value={customCommand}
              onChange={(e) => setCustomCommand(e.target.value)}
              className="w-full h-[100px] p-4 bg-[var(--bg-tertiary)] border border-[var(--border-color)] rounded-lg text-[var(--text-primary)] font-mono text-sm focus:outline-none focus:border-[var(--accent-primary)] focus:shadow-[0_0_0_3px_var(--accent-primary-dim)] resize-y"
              placeholder="--script-args userdb=users.txt,passdb=passwords.txt&#10;--min-rate 500&#10;--script http-enum.basepath=/admin/"
            ></textarea>
          </div>
        </section>
      </div>

      <CommandOutput command={generatedCommand} onCopy={copyToClipboard} />
      <Toast message={toast.message} isVisible={toast.show} onClose={() => setToast({ ...toast, show: false })} />
    </div>
  );
};

export default NmapBuilder;
