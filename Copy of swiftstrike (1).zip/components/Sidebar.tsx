
import React, { useState } from 'react';
import { SERVICES, OSINT_TOPICS, WEB_ENUM_TOPICS, AD_ENUM_TOPICS, SERVICE_EXPLOITS, AD_RECON_TOPICS, INFILTRATION_TOPICS, AD_ATTACK_TOPICS, WEB_SHELL_TOPICS, SHELL_TOPICS, OS_FINGERPRINT_TOPICS } from '../constants';

interface SidebarProps {
  activePage: string;
  setPage: (page: string) => void;
}

interface NavItemDef {
  id: string;
  label: string;
  icon?: string;
  group?: string;
  children?: NavItemDef[];
  port?: number;
}

interface SidebarItemProps {
  item: NavItemDef;
  level?: number;
  activePage: string;
  expandedItems: Set<string>;
  onToggle: (id: string, e: React.MouseEvent) => void;
  onClick: (item: NavItemDef) => void;
  onSetPage: (page: string) => void;
}

const SidebarItem: React.FC<SidebarItemProps> = ({ 
  item, 
  level = 0, 
  activePage, 
  expandedItems, 
  onToggle, 
  onClick,
  onSetPage 
}) => {
  const hasChildren = item.children && item.children.length > 0;
  const isExpanded = expandedItems.has(item.id);
  const isActivePage = activePage === item.id || 
                       (activePage === 'enum' && item.id.startsWith('service-')) ||
                       (activePage === 'osint' && item.id.startsWith('osint-')) ||
                       (activePage === 'exploitation' && item.id.startsWith('exploit-')) ||
                       (activePage === 'webenum' && item.id.startsWith('webenum-')) ||
                       (activePage === 'adrecon' && item.id.startsWith('adrecon-')) ||
                       (activePage === 'adattacks' && item.id.startsWith('adattacks-')) ||
                       (activePage === 'infiltration' && item.id.startsWith('infiltration-')) ||
                       (activePage === 'webshells' && item.id.startsWith('webshells-')) ||
                       (activePage === 'shells' && item.id.startsWith('shells-')) ||
                       (activePage === 'osfingerprint' && item.id.startsWith('osfingerprint-')) ||
                       (activePage === 'ad' && item.id.startsWith('ad-'));

  const paddingLeft = level === 0 ? 'pl-4' : level === 1 ? 'pl-4' : 'pl-3';
  const textSize = level === 0 ? 'text-[0.9rem]' : 'text-xs';
  const textColor = level === 0
    ? 'text-[var(--text-secondary)]'
    : 'text-[var(--text-muted)]';

  const activeClasses = 'bg-[var(--accent-primary-dim)] text-[var(--accent-primary)] border-l-[3px] border-[var(--accent-primary)]';
  const inactiveClasses = level === 0
    ? `hover:bg-[var(--bg-hover)] hover:text-[var(--text-primary)] border-l-[3px] border-transparent ${textColor}`
    : `hover:text-[var(--accent-primary)] hover:bg-[var(--bg-hover)] ${textColor}`;

  return (
    <div className="mb-[1px]">
      <button
        onClick={(e) => {
          if (hasChildren) onToggle(item.id, e);
          if (level === 0 && hasChildren) onSetPage(item.id);
          if (!hasChildren || level === 0) onClick(item);
        }}
        className={`flex items-center gap-3 w-full p-2 ${paddingLeft} rounded-lg transition-all duration-150 text-left relative group ${isActivePage && level === 0 ? activeClasses : inactiveClasses}`}
      >
        {level === 0 && item.icon && <i className={`fas ${item.icon} w-5 text-center`}></i>}
        {level === 0 && !item.icon && <span className="w-5"></span>}
        <span className={`flex-1 ${textSize}`}>{item.label}</span>
        {hasChildren && (
          <div
            className={`p-1 mr-1 rounded hover:bg-[rgba(255,255,255,0.1)] transition-colors ${isExpanded ? 'text-[var(--text-primary)]' : 'text-[var(--text-muted)]'}`}
          >
            <i className={`fas fa-chevron-down text-xs transition-transform duration-200 ${isExpanded ? 'rotate-180' : ''}`}></i>
          </div>
        )}
      </button>

      {hasChildren && isExpanded && (
        <div className={`mt-1 ml-4 border-l border-[var(--border-color)] ${level === 0 ? 'pl-2' : 'pl-2'} space-y-[1px]`}>
          {item.children!.map(child => (
            <SidebarItem 
              key={child.id} 
              item={child} 
              level={level + 1} 
              activePage={activePage}
              expandedItems={expandedItems}
              onToggle={onToggle}
              onClick={onClick}
              onSetPage={onSetPage}
            />
          ))}
        </div>
      )}
    </div>
  );
};

const Sidebar: React.FC<SidebarProps> = ({ activePage, setPage }) => {
  const [expandedItems, setExpandedItems] = useState<Set<string>>(new Set());

  const navItems: NavItemDef[] = [
    { id: 'dashboard', label: 'Dashboard', icon: 'fa-home', group: 'Main' },
    {
      id: 'casebuilder',
      label: 'Case Builder',
      icon: 'fa-briefcase',
      group: 'Main'
    },
    {
      id: 'hacktricks',
      label: 'HackTricks',
      icon: 'fa-book-dead',
      group: 'Main'
    },
    {
      id: 'settings',
      label: 'Settings & Keys',
      icon: 'fa-cog',
      group: 'Main'
    },
    {
      id: 'osint',
      label: 'OSINT',
      icon: 'fa-search',
      group: 'Main',
      children: OSINT_TOPICS.map(t => ({
        id: `osint-${t.id}`,
        label: t.name,
        children: t.tools.map(tool => ({
          id: `osint-${t.id}-tool-${tool.name.replace(/\s+/g, '-').toLowerCase()}`,
          label: tool.name
        }))
      }))
    },
    {
      id: 'nmap',
      label: 'Nmap Scans',
      icon: 'fa-radar',
      group: 'Main',
    },
    {
      id: 'enum',
      label: 'Service Enumeration',
      icon: 'fa-network-wired',
      group: 'Main',
      children: SERVICES.map(s => ({
        id: `service-${s.port}`,
        label: `${s.name} (${s.port})`,
        port: s.port,
        children: s.tools.map(t => ({
          id: `service-${s.port}-tool-${t.name.replace(/\s+/g, '-').toLowerCase()}`,
          label: t.name
        }))
      }))
    },
    {
      id: 'exploitation',
      label: 'Service Exploitation',
      icon: 'fa-bomb',
      group: 'Main',
      children: SERVICE_EXPLOITS.map(t => ({
        id: `exploit-${t.id}`,
        label: t.name,
        children: t.tools.map(tool => ({
          id: `exploit-${t.id}-tool-${tool.name.replace(/\s+/g, '-').toLowerCase()}`,
          label: tool.name
        }))
      }))
    },
    {
      id: 'infiltration',
      label: 'Infiltration',
      icon: 'fa-user-secret',
      group: 'Main',
      children: INFILTRATION_TOPICS.map(t => ({
        id: `infiltration-${t.id}`,
        label: t.name,
        children: t.tools.map(tool => ({
          id: `infiltration-${t.id}-tool-${tool.name.replace(/\s+/g, '-').toLowerCase()}`,
          label: tool.name
        }))
      }))
    },
    {
      id: 'osfingerprint',
      label: 'OS Fingerprinting',
      icon: 'fa-fingerprint',
      group: 'Main',
      children: OS_FINGERPRINT_TOPICS.map(t => ({
        id: `osfingerprint-${t.id}`,
        label: t.name,
        children: t.tools.map(tool => ({
          id: `osfingerprint-${t.id}-tool-${tool.name.replace(/\s+/g, '-').toLowerCase()}`,
          label: tool.name
        }))
      }))
    },
    {
      id: 'shells',
      label: 'Spawning Shells',
      icon: 'fa-terminal',
      group: 'Main',
      children: SHELL_TOPICS.map(t => ({
        id: `shells-${t.id}`,
        label: t.name,
        children: t.tools.map(tool => ({
          id: `shells-${t.id}-tool-${tool.name.replace(/\s+/g, '-').toLowerCase()}`,
          label: tool.name
        }))
      }))
    },
    {
      id: 'webshells',
      label: 'Web Shells',
      icon: 'fa-code',
      group: 'Main',
      children: WEB_SHELL_TOPICS.map(t => ({
        id: `webshells-${t.id}`,
        label: t.name,
        children: t.tools.map(tool => ({
          id: `webshells-${t.id}-tool-${tool.name.replace(/\s+/g, '-').toLowerCase()}`,
          label: tool.name
        }))
      }))
    },
    {
      id: 'webenum',
      label: 'Web Enumeration',
      icon: 'fa-spider',
      group: 'Main',
      children: WEB_ENUM_TOPICS.map(t => ({
        id: `webenum-${t.id}`,
        label: t.name,
        children: t.tools.map(tool => ({
          id: `webenum-${t.id}-tool-${tool.name.replace(/\s+/g, '-').toLowerCase()}`,
          label: tool.name
        }))
      }))
    },
    {
      id: 'adrecon',
      label: 'Active Directory Recon',
      group: 'Main',
      icon: 'fa-low-vision',
      children: AD_RECON_TOPICS.map(t => ({
        id: `adrecon-${t.id}`,
        label: t.name,
        children: t.tools.map(tool => ({
          id: `adrecon-${t.id}-tool-${tool.name.replace(/\s+/g, '-').toLowerCase()}`,
          label: tool.name
        }))
      }))
    },
    {
      id: 'ad',
      label: 'Active Directory Enum',
      group: 'Main',
      icon: 'fa-sitemap',
      children: AD_ENUM_TOPICS.map(t => ({
        id: `ad-${t.id}`,
        label: t.name,
        children: t.tools.map(tool => ({
          id: `ad-${t.id}-tool-${tool.name.replace(/\s+/g, '-').toLowerCase()}`,
          label: tool.name
        }))
      }))
    },
    {
      id: 'adattacks',
      label: 'Active Directory Attacks',
      group: 'Main',
      icon: 'fa-skull',
      children: AD_ATTACK_TOPICS.map(t => ({
        id: `adattacks-${t.id}`,
        label: t.name,
        children: t.tools.map(tool => ({
          id: `adattacks-${t.id}-tool-${tool.name.replace(/\s+/g, '-').toLowerCase()}`,
          label: tool.name
        }))
      }))
    }
  ];

  const toggleExpand = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setExpandedItems(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const handleItemClick = (item: NavItemDef) => {
    let targetPage = item.id;
    let targetHash = '';

    if (item.id.startsWith('service-')) {
      targetPage = 'enum';
      targetHash = item.id;
    } else if (item.id.startsWith('osint-')) {
      targetPage = 'osint';
      targetHash = item.id;
    } else if (item.id.startsWith('exploit-')) {
      targetPage = 'exploitation';
      targetHash = item.id;
    } else if (item.id.startsWith('webenum-')) {
      targetPage = 'webenum';
      targetHash = item.id;
    } else if (item.id.startsWith('adrecon-')) {
      targetPage = 'adrecon';
      targetHash = item.id;
    } else if (item.id.startsWith('ad-')) {
      targetPage = 'ad';
      targetHash = item.id;
    } else if (item.id.startsWith('adattacks-')) {
      targetPage = 'adattacks';
      targetHash = item.id;
    } else if (item.id.startsWith('infiltration-')) {
      targetPage = 'infiltration';
      targetHash = item.id;
    } else if (item.id.startsWith('webshells-')) {
      targetPage = 'webshells';
      targetHash = item.id;
    } else if (item.id.startsWith('shells-')) {
      targetPage = 'shells';
      targetHash = item.id;
    } else if (item.id.startsWith('osfingerprint-')) {
      targetPage = 'osfingerprint';
      targetHash = item.id;
    } else if (['nmap', 'enum', 'dashboard', 'osint', 'webenum', 'ad', 'adrecon', 'exploitation', 'infiltration', 'adattacks', 'webshells', 'shells', 'osfingerprint', 'casebuilder', 'settings', 'hacktricks'].includes(item.id)) {
      targetPage = item.id;
    }

    setPage(targetPage);

    if (targetHash) {
      window.location.hash = targetHash;
      setTimeout(() => {
        const el = document.getElementById(targetHash.replace('#', ''));
        if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 100);
    }
  };

  return (
    <nav className="w-[260px] bg-[var(--bg-secondary)] border-r border-[var(--border-color)] flex flex-col fixed h-screen z-50">
      <div className="p-6 border-b border-[var(--border-color)] text-center">
        <span className="text-4xl mb-2 block">⚡</span>
        <div className="font-[Orbitron] text-2xl font-bold text-[var(--accent-primary)] tracking-[3px] uppercase drop-shadow-[0_0_20px_rgba(0,255,136,0.4)]">
          SwiftStrike
        </div>
        <div className="text-[0.65rem] text-[var(--text-muted)] uppercase tracking-wider mt-1">
          Intimidate those who intimidate others
        </div>
      </div>

      <div className="flex-1 p-4 overflow-y-auto">
        {['Main'].map(group => (
          <div key={group} className="mb-6">
            <div className="text-[0.65rem] font-semibold text-[var(--text-muted)] uppercase tracking-[1.5px] px-4 py-2">
              {group}
            </div>
            {navItems.filter(item => item.group === group).map(item => (
              <React.Fragment key={item.id}>
                <SidebarItem 
                  item={item} 
                  activePage={activePage} 
                  expandedItems={expandedItems}
                  onToggle={toggleExpand}
                  onClick={handleItemClick}
                  onSetPage={setPage}
                />
                {item.id === 'dashboard' && (
                  <div className="h-px bg-[var(--border-color)] mx-4 my-3 opacity-40 mb-6" />
                )}
              </React.Fragment>
            ))}
          </div>
        ))}
      </div>

      <div className="p-4 border-t border-[var(--border-color)] text-center text-[0.7rem] text-[var(--text-muted)]">
        SwiftStrike Control Center
      </div>
    </nav>
  );
};

export default Sidebar;
