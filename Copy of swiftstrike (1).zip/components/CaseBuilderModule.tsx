
import React, { useState, useEffect } from 'react';
import Toast from './Toast';
import { Case, CaseNote, CaseArtifact, CaseTask } from '../types';

const CaseBuilderModule: React.FC = () => {
  const [cases, setCases] = useState<Case[]>([]);
  const [selectedCase, setSelectedCase] = useState<Case | null>(null);
  const [activeTab, setActiveTab] = useState<'notes' | 'artifacts' | 'tasks'>('tasks');
  const [toast, setToast] = useState({ show: false, message: '' });

  // Input states
  const [newCaseTitle, setNewCaseTitle] = useState('');
  const [newCasePriority, setNewCasePriority] = useState<Case['priority']>('Medium');
  
  const [newNote, setNewNote] = useState('');
  const [newArtifactType, setNewArtifactType] = useState<CaseArtifact['type']>('IP');
  const [newArtifactValue, setNewArtifactValue] = useState('');
  const [newArtifactDesc, setNewArtifactDesc] = useState('');
  const [newTask, setNewTask] = useState('');

  useEffect(() => {
    const storedCases = localStorage.getItem('swiftstrike_cases');
    if (storedCases) {
      setCases(JSON.parse(storedCases));
    }
  }, []);

  useEffect(() => {
    if (cases.length > 0) {
      localStorage.setItem('swiftstrike_cases', JSON.stringify(cases));
    }
  }, [cases]);

  const handleCreateCase = () => {
    if (!newCaseTitle.trim()) return;
    const newCase: Case = {
      id: crypto.randomUUID(),
      title: newCaseTitle,
      description: '',
      status: 'Active',
      priority: newCasePriority,
      created: Date.now(),
      updated: Date.now(),
      notes: [],
      artifacts: [],
      tasks: []
    };
    setCases([newCase, ...cases]);
    setNewCaseTitle('');
    setToast({ show: true, message: 'Case created successfully' });
  };

  const handleDeleteCase = (id: string) => {
    if (confirm('Are you sure you want to delete this case?')) {
      const updated = cases.filter(c => c.id !== id);
      setCases(updated);
      if (selectedCase?.id === id) setSelectedCase(null);
      localStorage.setItem('swiftstrike_cases', JSON.stringify(updated));
      setToast({ show: true, message: 'Case deleted' });
    }
  };

  const updateCase = (updatedCase: Case) => {
    const updatedCases = cases.map(c => c.id === updatedCase.id ? updatedCase : c);
    setCases(updatedCases);
    setSelectedCase(updatedCase);
  };

  // Notes Logic
  const handleAddNote = () => {
    if (!selectedCase || !newNote.trim()) return;
    const note: CaseNote = {
      id: crypto.randomUUID(),
      content: newNote,
      timestamp: Date.now()
    };
    const updatedCase = {
      ...selectedCase,
      notes: [note, ...selectedCase.notes],
      updated: Date.now()
    };
    updateCase(updatedCase);
    setNewNote('');
  };

  // Artifacts Logic
  const handleAddArtifact = () => {
    if (!selectedCase || !newArtifactValue.trim()) return;
    const artifact: CaseArtifact = {
      id: crypto.randomUUID(),
      type: newArtifactType,
      value: newArtifactValue,
      description: newArtifactDesc,
      timestamp: Date.now()
    };
    const updatedCase = {
      ...selectedCase,
      artifacts: [artifact, ...selectedCase.artifacts],
      updated: Date.now()
    };
    updateCase(updatedCase);
    setNewArtifactValue('');
    setNewArtifactDesc('');
  };

  // Tasks Logic
  const handleAddTask = () => {
    if (!selectedCase || !newTask.trim()) return;
    const task: CaseTask = {
      id: crypto.randomUUID(),
      title: newTask,
      completed: false
    };
    // Ensure tasks array exists (migration support)
    const currentTasks = selectedCase.tasks || [];
    const updatedCase = {
      ...selectedCase,
      tasks: [...currentTasks, task],
      updated: Date.now()
    };
    updateCase(updatedCase);
    setNewTask('');
  };

  const toggleTask = (taskId: string) => {
    if (!selectedCase) return;
    const currentTasks = selectedCase.tasks || [];
    const updatedTasks = currentTasks.map(t => 
      t.id === taskId ? { ...t, completed: !t.completed } : t
    );
    updateCase({ ...selectedCase, tasks: updatedTasks });
  };

  const deleteTask = (taskId: string) => {
    if (!selectedCase) return;
    const currentTasks = selectedCase.tasks || [];
    const updatedTasks = currentTasks.filter(t => t.id !== taskId);
    updateCase({ ...selectedCase, tasks: updatedTasks });
  };

  // Export Logic (Markdown)
  const handleExport = () => {
    if (!selectedCase) return;
    
    const { title, status, priority, created, tasks, artifacts, notes } = selectedCase;
    const date = new Date(created).toLocaleDateString();
    
    let md = `# Case Report: ${title}\n\n`;
    md += `**Status:** ${status} | **Priority:** ${priority || 'Medium'} | **Created:** ${date}\n\n`;
    
    md += `## Tasks\n`;
    (tasks || []).forEach(t => {
      md += `- [${t.completed ? 'x' : ' '}] ${t.title}\n`;
    });
    md += `\n`;

    md += `## Artifacts\n`;
    artifacts.forEach(a => {
      md += `- **${a.type}**: ${a.value} ${a.description ? `(${a.description})` : ''}\n`;
    });
    md += `\n`;

    md += `## Notes\n`;
    notes.forEach(n => {
      md += `- [${new Date(n.timestamp).toLocaleTimeString()}] ${n.content.replace(/\n/g, ' ')}\n`;
    });

    const blob = new Blob([md], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Case_${title.replace(/\s+/g, '_')}_Report.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setToast({ show: true, message: 'Markdown report downloaded' });
  };

  // Export PDF Logic
  const handleExportPdf = () => {
    if (!selectedCase) return;
    
    // Create a temporary element for the PDF content with inline styles for PDF generation
    const element = document.createElement('div');
    element.innerHTML = `
      <div style="font-family: Helvetica, Arial, sans-serif; color: #333; padding: 40px; max-width: 800px;">
        <h1 style="border-bottom: 2px solid #333; padding-bottom: 10px; margin-bottom: 20px; font-size: 24px;">${selectedCase.title}</h1>
        <p style="margin-bottom: 30px; color: #555; font-size: 14px;">
          <strong>Status:</strong> ${selectedCase.status} &nbsp;|&nbsp; 
          <strong>Priority:</strong> ${selectedCase.priority || 'Medium'} &nbsp;|&nbsp; 
          <strong>Created:</strong> ${new Date(selectedCase.created).toLocaleDateString()}
        </p>
        
        ${(selectedCase.tasks || []).length > 0 ? `
        <h2 style="margin-top: 30px; margin-bottom: 15px; border-bottom: 1px solid #ccc; font-size: 18px; padding-bottom: 5px; color: #222;">Tasks</h2>
        <ul style="list-style: none; padding: 0;">
          ${(selectedCase.tasks || []).map(t => `
            <li style="margin-bottom: 8px; font-size: 14px;">
              <span style="font-family: monospace;">[${t.completed ? 'X' : '&nbsp;'}]</span> ${t.title}
            </li>
          `).join('')}
        </ul>
        ` : ''}

        ${selectedCase.artifacts.length > 0 ? `
        <h2 style="margin-top: 30px; margin-bottom: 15px; border-bottom: 1px solid #ccc; font-size: 18px; padding-bottom: 5px; color: #222;">Artifacts</h2>
        <div style="display: grid; gap: 10px;">
          ${selectedCase.artifacts.map(a => `
            <div style="background: #f9f9f9; padding: 10px; border: 1px solid #eee; border-radius: 4px;">
              <div style="font-weight: bold; font-size: 14px; margin-bottom: 4px;">${a.type}: ${a.value}</div>
              ${a.description ? `<div style="font-size: 12px; color: #666;">${a.description}</div>` : ''}
            </div>
          `).join('')}
        </div>
        ` : ''}

        ${selectedCase.notes.length > 0 ? `
        <h2 style="margin-top: 30px; margin-bottom: 15px; border-bottom: 1px solid #ccc; font-size: 18px; padding-bottom: 5px; color: #222;">Notes</h2>
        <div>
          ${selectedCase.notes.map(n => `
            <div style="margin-bottom: 15px; padding-left: 15px; border-left: 3px solid #ddd;">
              <div style="color: #888; font-size: 11px; margin-bottom: 4px;">${new Date(n.timestamp).toLocaleString()}</div>
              <div style="font-size: 13px; line-height: 1.5;">${n.content.replace(/\n/g, '<br/>')}</div>
            </div>
          `).join('')}
        </div>
        ` : ''}
        
        <div style="margin-top: 50px; font-size: 10px; color: #aaa; text-align: center; border-top: 1px solid #eee; padding-top: 10px;">
          Generated by SwiftStrike Case Builder
        </div>
      </div>
    `;

    const opt = {
      margin: 0,
      filename: `Case_${selectedCase.title.replace(/[^a-z0-9]/gi, '_')}_Report.pdf`,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2, useCORS: true },
      jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
    };

    if ((window as any).html2pdf) {
      (window as any).html2pdf().set(opt).from(element).save();
      setToast({ show: true, message: 'Downloading PDF report...' });
    } else {
      setToast({ show: true, message: 'PDF library loading... Try again in a moment.' });
    }
  };

  const getPriorityColor = (p: string) => {
    switch (p) {
        case 'High': return 'text-[var(--accent-danger)] border-[var(--accent-danger)]';
        case 'Low': return 'text-[var(--accent-primary)] border-[var(--accent-primary)]';
        default: return 'text-[var(--accent-secondary)] border-[var(--accent-secondary)]';
    }
  };

  return (
    <div className="h-full flex flex-col pb-20">
      {/* Header */}
      <div className="flex justify-between items-end mb-8">
        <div>
          <h1 className="font-[Orbitron] text-3xl font-bold flex items-center gap-3 mb-2">
            Case Builder
          </h1>
          <p className="text-[var(--text-secondary)] text-[0.95rem]">
            Manage investigations, track artifacts, and document findings.
          </p>
        </div>
      </div>

      <div className="flex gap-6 h-[calc(100vh-200px)]">
        {/* Sidebar List */}
        <div className="w-[300px] flex flex-col bg-[var(--bg-card)] border border-[var(--border-color)] rounded-xl overflow-hidden">
          <div className="p-4 border-b border-[var(--border-color)] space-y-2">
            <input
              type="text"
              value={newCaseTitle}
              onChange={(e) => setNewCaseTitle(e.target.value)}
              placeholder="New Case Name..."
              className="w-full px-3 py-2 bg-[var(--bg-tertiary)] border border-[var(--border-color)] rounded text-sm text-[var(--text-primary)] focus:outline-none focus:border-[var(--accent-primary)]"
            />
            <div className="flex gap-2">
                <select 
                    value={newCasePriority}
                    onChange={(e) => setNewCasePriority(e.target.value as any)}
                    className="flex-1 bg-[var(--bg-tertiary)] border border-[var(--border-color)] rounded text-xs text-[var(--text-secondary)] px-2 focus:outline-none"
                >
                    <option value="High">High Priority</option>
                    <option value="Medium">Medium</option>
                    <option value="Low">Low Priority</option>
                </select>
                <button 
                    onClick={handleCreateCase}
                    className="px-4 py-2 bg-[var(--accent-primary)] text-[var(--bg-primary)] rounded font-bold text-xs hover:opacity-90 uppercase tracking-wider"
                >
                    Create
                </button>
            </div>
          </div>
          <div className="flex-1 overflow-y-auto p-2 space-y-1">
            {cases.length === 0 && (
                <div className="text-center text-[var(--text-muted)] text-sm py-8">No active cases</div>
            )}
            {cases.map(c => (
              <div
                key={c.id}
                onClick={() => setSelectedCase(c)}
                className={`p-3 rounded-lg cursor-pointer transition-all border relative group ${
                  selectedCase?.id === c.id 
                    ? 'bg-[var(--bg-tertiary)] border-[var(--accent-primary)]' 
                    : 'bg-transparent border-transparent hover:bg-[var(--bg-hover)]'
                }`}
              >
                <div className="flex justify-between items-start mb-1">
                  <span className={`font-bold text-sm truncate pr-6 ${selectedCase?.id === c.id ? 'text-[var(--accent-primary)]' : 'text-[var(--text-primary)]'}`}>
                    {c.title}
                  </span>
                  <button 
                    onClick={(e) => { e.stopPropagation(); handleDeleteCase(c.id); }}
                    className="text-[var(--text-muted)] hover:text-[var(--accent-danger)] text-xs absolute right-3 top-3 opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <i className="fas fa-trash"></i>
                  </button>
                </div>
                <div className="flex justify-between items-center text-[0.65rem] text-[var(--text-muted)]">
                  <span>{new Date(c.updated).toLocaleDateString()}</span>
                  <span className={`px-1.5 py-0.5 rounded border text-[0.6rem] font-bold uppercase ${getPriorityColor(c.priority || 'Medium')}`}>
                    {c.priority || 'Medium'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Detail View */}
        <div className="flex-1 bg-[var(--bg-card)] border border-[var(--border-color)] rounded-xl overflow-hidden flex flex-col">
          {selectedCase ? (
            <>
              <div className="p-6 border-b border-[var(--border-color)] flex justify-between items-center bg-[var(--bg-secondary)]">
                <div>
                  <div className="flex items-center gap-3">
                      <h2 className="text-xl font-bold text-[var(--text-primary)]">{selectedCase.title}</h2>
                      <span className={`px-2 py-0.5 rounded border text-[0.65rem] font-bold uppercase ${getPriorityColor(selectedCase.priority || 'Medium')}`}>
                        {selectedCase.priority || 'Medium'}
                      </span>
                  </div>
                  <div className="text-xs text-[var(--text-muted)] mt-1">
                    Created: {new Date(selectedCase.created).toLocaleString()}
                  </div>
                </div>
                <div className="flex gap-4 items-center">
                    <div className="flex bg-[var(--bg-tertiary)] rounded-lg p-1 border border-[var(--border-color)]">
                        {(['tasks', 'notes', 'artifacts'] as const).map(tab => (
                            <button
                                key={tab}
                                onClick={() => setActiveTab(tab)}
                                className={`px-4 py-1.5 rounded text-xs font-bold uppercase tracking-wider transition-all ${
                                    activeTab === tab 
                                    ? 'bg-[var(--accent-primary)] text-[var(--bg-primary)] shadow-sm' 
                                    : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
                                }`}
                            >
                                {tab}
                            </button>
                        ))}
                    </div>
                    
                    {/* Export Toolbar */}
                    <div className="flex gap-1 bg-[var(--bg-primary)] border border-[var(--border-color)] rounded-lg p-1">
                        <button 
                            onClick={handleExport}
                            className="px-3 py-1.5 rounded text-[var(--text-secondary)] hover:text-[var(--accent-primary)] hover:bg-[var(--bg-hover)] transition-all"
                            title="Export Markdown"
                        >
                            <i className="fab fa-markdown"></i>
                        </button>
                        <div className="w-px bg-[var(--border-color)] my-1"></div>
                        <button 
                            onClick={handleExportPdf}
                            className="px-3 py-1.5 rounded text-[var(--text-secondary)] hover:text-[var(--accent-danger)] hover:bg-[var(--bg-hover)] transition-all"
                            title="Export PDF"
                        >
                            <i className="fas fa-file-pdf"></i>
                        </button>
                    </div>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto p-6 bg-[var(--bg-tertiary)]">
                
                {/* TASKS TAB */}
                {activeTab === 'tasks' && (
                    <div className="space-y-4 max-w-3xl mx-auto">
                        <div className="flex gap-2 mb-6">
                            <input
                                type="text"
                                value={newTask}
                                onChange={(e) => setNewTask(e.target.value)}
                                placeholder="Add a new task..."
                                className="flex-1 px-4 py-3 bg-[var(--bg-card)] border border-[var(--border-color)] rounded-lg text-sm text-[var(--text-primary)] focus:outline-none focus:border-[var(--accent-primary)]"
                                onKeyDown={(e) => e.key === 'Enter' && handleAddTask()}
                            />
                            <button 
                                onClick={handleAddTask}
                                className="px-6 bg-[var(--accent-primary-dim)] border border-[var(--accent-primary)] text-[var(--accent-primary)] rounded-lg hover:bg-[var(--accent-primary)] hover:text-[var(--bg-primary)] transition-all font-bold"
                            >
                                Add
                            </button>
                        </div>
                        <div className="space-y-2">
                            {(selectedCase.tasks || []).length === 0 && (
                                <div className="text-center text-[var(--text-muted)] py-8">No tasks yet.</div>
                            )}
                            {(selectedCase.tasks || []).map(task => (
                                <div key={task.id} className="flex items-center gap-3 p-3 bg-[var(--bg-card)] border border-[var(--border-color)] rounded-lg group hover:border-[var(--border-color)] transition-all">
                                    <div 
                                        onClick={() => toggleTask(task.id)}
                                        className={`w-5 h-5 rounded border flex items-center justify-center cursor-pointer transition-all ${
                                            task.completed 
                                            ? 'bg-[var(--accent-primary)] border-[var(--accent-primary)]' 
                                            : 'border-[var(--text-muted)] hover:border-[var(--accent-primary)]'
                                        }`}
                                    >
                                        {task.completed && <i className="fas fa-check text-[var(--bg-primary)] text-xs"></i>}
                                    </div>
                                    <span className={`flex-1 text-sm ${task.completed ? 'text-[var(--text-muted)] line-through' : 'text-[var(--text-primary)]'}`}>
                                        {task.title}
                                    </span>
                                    <button 
                                        onClick={() => deleteTask(task.id)}
                                        className="text-[var(--text-muted)] hover:text-[var(--accent-danger)] opacity-0 group-hover:opacity-100 transition-all px-2"
                                    >
                                        <i className="fas fa-times"></i>
                                    </button>
                                </div>
                            ))}
                        </div>
                    </div>
                )}

                {/* NOTES TAB */}
                {activeTab === 'notes' && (
                  <div className="space-y-4 max-w-3xl mx-auto">
                    <div className="flex gap-2 mb-6">
                        <textarea
                            value={newNote}
                            onChange={(e) => setNewNote(e.target.value)}
                            placeholder="Add a new finding or note..."
                            className="flex-1 p-3 bg-[var(--bg-card)] border border-[var(--border-color)] rounded-lg text-sm text-[var(--text-primary)] focus:outline-none focus:border-[var(--accent-primary)] min-h-[80px] resize-none"
                            onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), handleAddNote())}
                        />
                        <button 
                            onClick={handleAddNote}
                            className="w-20 bg-[var(--accent-primary-dim)] border border-[var(--accent-primary)] text-[var(--accent-primary)] rounded-lg hover:bg-[var(--accent-primary)] hover:text-[var(--bg-primary)] transition-all font-bold"
                        >
                            Add
                        </button>
                    </div>
                    {selectedCase.notes.map(note => (
                        <div key={note.id} className="bg-[var(--bg-card)] border border-[var(--border-color)] rounded-lg p-4 animate-fade-in">
                            <div className="text-[0.65rem] text-[var(--text-muted)] mb-2 flex justify-between">
                                <span>{new Date(note.timestamp).toLocaleString()}</span>
                            </div>
                            <div className="text-sm text-[var(--text-primary)] whitespace-pre-wrap">{note.content}</div>
                        </div>
                    ))}
                  </div>
                )}

                {/* ARTIFACTS TAB */}
                {activeTab === 'artifacts' && (
                  <div className="space-y-4 max-w-3xl mx-auto">
                    <div className="bg-[var(--bg-card)] border border-[var(--border-color)] rounded-lg p-4 mb-6 shadow-sm">
                        <div className="grid grid-cols-12 gap-3 mb-3">
                            <div className="col-span-3">
                                <select 
                                    value={newArtifactType}
                                    onChange={(e) => setNewArtifactType(e.target.value as any)}
                                    className="w-full p-2.5 bg-[var(--bg-secondary)] border border-[var(--border-color)] rounded text-sm text-[var(--text-primary)] focus:border-[var(--accent-primary)] outline-none"
                                >
                                    <option value="IP">IP Address</option>
                                    <option value="Domain">Domain</option>
                                    <option value="Email">Email</option>
                                    <option value="User">Username</option>
                                    <option value="Phone">Phone</option>
                                    <option value="Hash">File Hash</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                            <div className="col-span-9">
                                <input
                                    type="text"
                                    value={newArtifactValue}
                                    onChange={(e) => setNewArtifactValue(e.target.value)}
                                    placeholder="Value (e.g., 1.2.3.4)"
                                    className="w-full p-2.5 bg-[var(--bg-secondary)] border border-[var(--border-color)] rounded text-sm text-[var(--text-primary)] focus:border-[var(--accent-primary)] outline-none"
                                />
                            </div>
                        </div>
                        <div className="flex gap-3">
                            <input
                                type="text"
                                value={newArtifactDesc}
                                onChange={(e) => setNewArtifactDesc(e.target.value)}
                                placeholder="Description / Context..."
                                className="flex-1 p-2.5 bg-[var(--bg-secondary)] border border-[var(--border-color)] rounded text-sm text-[var(--text-primary)] focus:border-[var(--accent-primary)] outline-none"
                                onKeyDown={(e) => e.key === 'Enter' && handleAddArtifact()}
                            />
                            <button 
                                onClick={handleAddArtifact}
                                className="px-6 bg-[var(--accent-primary-dim)] border border-[var(--accent-primary)] text-[var(--accent-primary)] rounded hover:bg-[var(--accent-primary)] hover:text-[var(--bg-primary)] transition-all font-bold text-sm"
                            >
                                Add Artifact
                            </button>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 gap-3">
                        {selectedCase.artifacts.map(art => (
                            <div key={art.id} className="bg-[var(--bg-card)] border border-[var(--border-color)] rounded-lg p-3 flex items-center gap-4 animate-fade-in hover:border-[var(--accent-primary-dim)] transition-colors group">
                                <div className="w-10 h-10 rounded bg-[var(--bg-secondary)] flex items-center justify-center text-[var(--accent-primary)] border border-[var(--border-color)] font-bold text-xs shrink-0">
                                    {art.type}
                                </div>
                                <div className="flex-1 min-w-0">
                                    <div className="font-mono text-sm text-[var(--text-primary)] truncate font-bold">{art.value}</div>
                                    <div className="text-xs text-[var(--text-muted)] truncate">{art.description}</div>
                                </div>
                                <div className="text-[0.65rem] text-[var(--text-muted)] whitespace-nowrap">
                                    {new Date(art.timestamp).toLocaleDateString()}
                                </div>
                            </div>
                        ))}
                    </div>
                  </div>
                )}
              </div>
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-[var(--text-muted)]">
                <i className="fas fa-folder-open text-6xl mb-4 opacity-20"></i>
                <p>Select a case or create a new one to begin.</p>
            </div>
          )}
        </div>
      </div>

      <Toast message={toast.message} isVisible={toast.show} onClose={() => setToast({ ...toast, show: false })} />
    </div>
  );
};

export default CaseBuilderModule;
