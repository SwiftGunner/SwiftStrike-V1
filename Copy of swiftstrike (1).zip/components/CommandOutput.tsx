import React from 'react';

interface CommandOutputProps {
  command: string;
  onCopy: () => void;
}

const CommandOutput: React.FC<CommandOutputProps> = ({ command, onCopy }) => {
  return (
    <div className="mt-8 border border-[var(--border-color)] bg-[var(--bg-card)] rounded-lg shadow-sm">
      <div className="flex justify-between items-center px-4 py-3 border-b border-[var(--border-color)] bg-[var(--bg-secondary)] rounded-t-lg">
        <h2 className="text-sm font-semibold flex items-center gap-2 text-[var(--text-secondary)]">
          <i className="fas fa-terminal text-[var(--accent-primary)]"></i> Generated Command
        </h2>
        <div className="flex gap-2">
            <button className="px-3 py-1.5 bg-[var(--bg-tertiary)] text-[var(--text-secondary)] border border-[var(--border-color)] rounded text-xs font-medium hover:text-[var(--text-primary)] hover:border-[var(--text-secondary)] transition-all flex items-center gap-2">
                <i className="fas fa-star"></i> Save
            </button>
            <button 
                onClick={onCopy}
                className="px-3 py-1.5 bg-[var(--accent-primary)] text-[var(--bg-primary)] border-none rounded text-xs font-bold uppercase tracking-wider hover:opacity-90 transition-all flex items-center gap-2"
            >
                <i className="fas fa-copy"></i> Copy
            </button>
        </div>
      </div>
      <div className="p-4 bg-[var(--bg-primary)] rounded-b-lg font-mono text-sm text-[var(--text-primary)] break-all whitespace-pre-wrap leading-relaxed">
        {command}
      </div>
    </div>
  );
};

export default CommandOutput;