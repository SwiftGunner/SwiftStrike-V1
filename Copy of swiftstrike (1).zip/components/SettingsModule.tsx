
import React, { useState, useEffect } from 'react';
import Toast from './Toast';

const API_KEYS = [
  { key: 'SHODAN_API_KEY', label: 'Shodan API Key' },
  { key: 'CENSYS_API_ID', label: 'Censys API ID' },
  { key: 'CENSYS_API_SECRET', label: 'Censys API Secret' },
  { key: 'VIRUSTOTAL_API_KEY', label: 'VirusTotal API Key' },
  { key: 'HUNTER_API_KEY', label: 'Hunter.io API Key' },
  { key: 'H8MAIL_API_KEY', label: 'h8mail API Key' },
  { key: 'GOOGLE_API_KEY', label: 'Google API Key' },
];

const SettingsModule: React.FC = () => {
  const [keys, setKeys] = useState<Record<string, string>>({});
  const [toast, setToast] = useState({ show: false, message: '' });

  useEffect(() => {
    const storedKeys = localStorage.getItem('swiftstrike_api_keys');
    if (storedKeys) {
      setKeys(JSON.parse(storedKeys));
    }
  }, []);

  const handleSave = () => {
    localStorage.setItem('swiftstrike_api_keys', JSON.stringify(keys));
    setToast({ show: true, message: 'Settings saved successfully!' });
  };

  const handleChange = (key: string, value: string) => {
    setKeys(prev => ({ ...prev, [key]: value }));
  };

  const handleClear = () => {
    if (confirm('Are you sure you want to clear all stored API keys?')) {
        setKeys({});
        localStorage.removeItem('swiftstrike_api_keys');
        setToast({ show: true, message: 'All keys cleared.' });
    }
  };

  return (
    <div className="h-full flex flex-col pb-20 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex justify-between items-end mb-8">
        <div>
          <h1 className="font-[Orbitron] text-3xl font-bold flex items-center gap-3 mb-2">
            Settings & Keys
          </h1>
          <p className="text-[var(--text-secondary)] text-[0.95rem]">
            Manage your API keys for OSINT tools. Keys are stored locally in your browser.
          </p>
        </div>
      </div>

      <div className="bg-[var(--bg-card)] border border-[var(--border-color)] rounded-xl p-8 shadow-lg">
        <div className="space-y-6">
          {API_KEYS.map((apiKey) => (
            <div key={apiKey.key} className="flex flex-col gap-2">
              <label className="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider">
                {apiKey.label}
              </label>
              <div className="relative">
                <input
                  type="password"
                  value={keys[apiKey.key] || ''}
                  onChange={(e) => handleChange(apiKey.key, e.target.value)}
                  className="w-full p-3 bg-[var(--bg-secondary)] border border-[var(--border-color)] rounded-lg text-[var(--text-primary)] font-mono text-sm focus:outline-none focus:border-[var(--accent-primary)] transition-all"
                  placeholder={`Enter ${apiKey.label}...`}
                />
                {keys[apiKey.key] && (
                    <i className="fas fa-check-circle absolute right-4 top-1/2 -translate-y-1/2 text-[var(--accent-primary)]"></i>
                )}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-8 flex gap-4 pt-6 border-t border-[var(--border-color)]">
          <button
            onClick={handleSave}
            className="px-6 py-2.5 bg-[var(--accent-primary)] text-[var(--bg-primary)] rounded-lg font-bold text-sm hover:opacity-90 transition-all flex items-center gap-2"
          >
            <i className="fas fa-save"></i> Save Settings
          </button>
          <button
            onClick={handleClear}
            className="px-6 py-2.5 bg-[rgba(255,71,87,0.1)] text-[var(--accent-danger)] border border-[var(--accent-danger)] rounded-lg font-bold text-sm hover:bg-[var(--accent-danger)] hover:text-white transition-all flex items-center gap-2 ml-auto"
          >
            <i className="fas fa-trash-alt"></i> Clear All Keys
          </button>
        </div>
      </div>

      <Toast message={toast.message} isVisible={toast.show} onClose={() => setToast({ ...toast, show: false })} />
    </div>
  );
};

export default SettingsModule;
